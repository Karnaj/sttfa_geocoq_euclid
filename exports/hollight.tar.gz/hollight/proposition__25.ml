(*proposition__25 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. ((((triangle A) B) C) ==> ((((triangle D) E) F) ==> (((((cong A) B) D) E) ==> (((((cong A) C) D) F) ==> (((((lt E) F) B) C) ==> ((((((ltA E) D) F) B) A) C)))))))))))`*)
let proposition__25 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
          (DISCH `(((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
               (MP  
                (CONV_CONV_rule `(((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                 (DISCH `mat_not ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                  (MP  
                   (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                    (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                       (DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (CONV_CONV_rule `(((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                          (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                             (DISCH `mat_not (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                              (MP  
                               (CONV_CONV_rule `(((((((congA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                (DISCH `mat_not ((((((congA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (DISCH `(((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                   (ASSUME `(((((ltA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(F : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (lemma__angletrichotomy2))))))
                                        ) (MP  
                                           (SPEC `(F : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (nCol__notCol)))
                                           ) (ASSUME `mat_not (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                           ))
                                       ) (MP  
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (nCol__notCol)))
                                          ) (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                          ))
                                      ) (ASSUME `mat_not ((((((congA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                      )
                                     ) (ASSUME `mat_not ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                     ))))
                               ) (DISCH `(((((congA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (DISCH `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                              (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                              )
                                             ) (MP  
                                                (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (not__nCol__Col))))
                                                ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                     (ASSUME `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                     )
                                                    ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )))))
                                           ) (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (lemma__trichotomy2))))
                                              ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(F : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (lemma__lessthancongruence2
                                                   ))))))
                                             ) (ASSUME `(((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            )))
                                       ) (MP  
                                          (SPEC `(F : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (lemma__congruencesymmetric))))
                                          ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                          )))
                                     ) (MP  
                                        (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(F : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                                  ))))))
                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                            )
                                           ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                           )
                                          ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                          ))
                                        ) (GEN `(A0 : mat_Point)` 
                                           (GEN `(B0 : mat_Point)` 
                                            (GEN `(C0 : mat_Point)` 
                                             (GEN `(a : mat_Point)` 
                                              (GEN `(b : mat_Point)` 
                                               (GEN `(c : mat_Point)` 
                                                (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                 (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                  (DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                      (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                       (SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                        (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                         (ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(c : mat_Point)` 
                                                          (SPEC `(b : mat_Point)` 
                                                           (SPEC `(a : mat_Point)` 
                                                            (SPEC `(C0 : mat_Point)` 
                                                             (SPEC `(B0 : mat_Point)` 
                                                              (SPEC `(A0 : mat_Point)` 
                                                               (proposition__04
                                                               ))))))
                                                         ) (ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                       ))))))))))))))
                                   ) (MP  
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(F : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (lemma__equalanglessymmetric)))))
                                       )
                                      ) (ASSUME `(((((congA (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                      ))))))
                            ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                               (MP  
                                (DISCH `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                   (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                   )
                                  ) (MP  
                                     (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (not__nCol__Col))))
                                     ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(F : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (col__nCol__False)))
                                          ) (ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                          )
                                         ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                         )))))
                                ) (MP  
                                   (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                       (SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                        (SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                         (DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                             (SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                              (SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                               (DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                   (SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                    (SPEC `((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                         (SPEC `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                          (SPEC `((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                            (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(F : mat_Point)` 
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(E : mat_Point)` 
                                         (lemma__collinearorder)))
                                      ) (ASSUME `((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                      )))))))
                         ) (ASSUME `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                         )))
                      ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` (col__nCol__False)))
                             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )
                            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            ))
                          ) (MP  
                             (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                              (MP  
                               (MP  
                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                        (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                              (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                     ))))
                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                               ))
                             ) (MP  
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (lemma__collinearorder)))
                                ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                )))))))
                   ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   )))
                ) (DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                   (MP  
                    (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                     (MP  
                      (DISCH `mat_not ((((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                       (MP  
                        (CONV_CONV_rule `((((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                         (ASSUME `mat_not ((((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                         )
                        ) (ASSUME `(((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        ))
                      ) (MP  
                         (SPEC `(F : mat_Point)` 
                          (SPEC `(E : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__trichotomy2))))
                         ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                         )))
                    ) (MP  
                       (MP  
                        (MP  
                         (MP  
                          (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(F : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(D : mat_Point)` (proposition__24)))))
                            )
                           ) (ASSUME `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                           )
                          ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                          )
                         ) (ASSUME `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                         )
                        ) (ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                        )
                       ) (ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                       )))))
              ) (MP  
                 (SPEC `(F : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(D : mat_Point)` (lemma__congruencesymmetric))))
                 ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                 )))
            ) (MP  
               (SPEC `(E : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(D : mat_Point)` (lemma__congruencesymmetric))))
               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
               )))))))))))))
 ;;


(*lemma__NCdistinct :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> ((mat_and ((neq A) B)) ((mat_and ((neq B) C)) ((mat_and ((neq A) C)) ((mat_and ((neq B) A)) ((mat_and ((neq C) B)) ((neq C) A)))))))))`*)
let lemma__NCdistinct =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))))` 
      (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
       (MP  
        (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))))` 
           (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
            (MP  
             (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
              (MP  
               (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))))` 
                (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                 (MP  
                  (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (MP  
                     (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))))` 
                      (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (conj)))
                     ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                     )
                    ) (MP  
                       (MP  
                        (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))))` 
                         (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                           (conj)))
                        ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                        )
                       ) (MP  
                          (MP  
                           (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))) ==> ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                            (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                              (conj)))
                           ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                           )
                          ) (MP  
                             (MP  
                              (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                               (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                (conj))
                              ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                              )
                             ) (MP  
                                (MP  
                                 (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                  (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                 )
                                ) (ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                ))))))
                  ) (MP  
                     (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (B : mat_Point))` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric)))
                     ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                     ))))
               ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                    (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (col__nCol__False)))
                       ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )
                      ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )))
                   ) (MP  
                      (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                        (or__intror))
                      ) (MP  
                         (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                          (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                             (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                              (or__introl))
                            ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`)
                         ))))))
             ) (MP  
                (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (A : mat_Point))` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric)))
                ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`)))
           )
          ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
              ) (MP  
                 (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
                 ) (MP  
                    (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                     (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                      (or__introl))
                    ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`))))))
        ) (MP  
           (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric)))
           ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`))))
     ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` (col__nCol__False)))
             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )
            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )))
         ) (MP  
            (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
            ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))))))))
 ;;


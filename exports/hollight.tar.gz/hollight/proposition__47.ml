(*proposition__47 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! K : mat_Point. ((((triangle A) B) C) ==> ((((per B) A) C) ==> (((((sQ A) B) F) G) ==> (((((tS G) B) A) C) ==> (((((sQ A) C) K) H) ==> (((((tS H) C) A) B) ==> (((((sQ B) C) E) D) ==> (((((tS D) C) B) A) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG B) X) Y) D)) ((mat_and (((betS B) X) C)) ((mat_and ((((pG X) C) E) Y)) ((mat_and (((betS D) Y) E)) ((mat_and ((((((((eF A) B) F) G) B) X) Y) D)) ((((((((eF A) C) K) H) X) C) E) Y))))))))))))))))))))))))))`*)
let proposition__47 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(K : mat_Point)` 
         (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (DISCH `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
           (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
            (DISCH `(((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
             (DISCH `(((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
              (DISCH `(((tS (H : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (DISCH `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                (DISCH `(((tS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                 (MP  
                  (DISCH `ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (x : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (x : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))))) ==> (return : bool)))` 
                       (SPEC `\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(M : mat_Point)` 
                        (DISCH `ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (D : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))) ==> (return : bool)))` 
                             (SPEC `\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(L : mat_Point)` 
                              (DISCH `(mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                  (SPEC `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))))` 
                                   (SPEC `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                        (SPEC `(mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))` 
                                         (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                              (SPEC `(mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))` 
                                               (SPEC `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                (DISCH `(mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                    (SPEC `(mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))` 
                                                     (SPEC `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                      (DISCH `(mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                          (SPEC `(mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))` 
                                                           (SPEC `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                            (DISCH `(mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((sQ (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((pG (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (x : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (x : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((betS (x : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (x : mat_Point)) (E : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(l : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (l : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (l : mat_Point)) (D : mat_Point))) ((mat_or (((betS (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (L : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (L : mat_Point)) (E : mat_Point))) ((mat_or (((betS (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (l : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (L : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (L : mat_Point)) (m : mat_Point))) ((mat_or ((eq (L : mat_Point)) (A : mat_Point))) ((mat_or ((eq (m : mat_Point)) (A : mat_Point))) ((mat_or (((betS (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (A : mat_Point))) ((mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (M : mat_Point)) (m : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `mat_not ((neq (M : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (X : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (x : mat_Point))))))) ==> (ex (\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point))) ((mat_and (((betS (D : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (Y : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (M : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (l : mat_Point)) ==> ((((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)) ==> ((((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (L : mat_Point)) (A : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (l : mat_Point)) (L : mat_Point)) ==> (((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) ==> ((((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)) ==> ((((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)) ==> (((neq (L : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (L : mat_Point)) ==> ((((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) ==> (((eq (L : mat_Point)) (l : mat_Point)) ==> ((((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)) ==> ((((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (L : mat_Point)) (A : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L : mat_Point)) (E : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((pG (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (l : mat_Point)) ==> ((((betS (D : mat_Point)) (l : mat_Point)) (E : mat_Point)) ==> ((((betS (l : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (l : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (l : mat_Point)) ==> (((neq (l : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (l : mat_Point)) ==> ((((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)) ==> (((eq (l : mat_Point)) (l : mat_Point)) ==> ((((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (l : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (l : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (l : mat_Point)) (A : mat_Point)) (m : mat_Point)) ==> ((((col (l : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (l : mat_Point)) (A : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (l : mat_Point)) (E : mat_Point))))))))))))))))))))) ==> (! y : mat_Point. (((eq (l : mat_Point)) (y : mat_Point)) ==> (((((pG (B : mat_Point)) (M : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (y : mat_Point)) ==> ((((betS (D : mat_Point)) (y : mat_Point)) (E : mat_Point)) ==> ((((betS (y : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (y : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (y : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (y : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (y : mat_Point)) ==> (((neq (y : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (y : mat_Point)) ==> ((((per (E : mat_Point)) (y : mat_Point)) (A : mat_Point)) ==> (((eq (y : mat_Point)) (l : mat_Point)) ==> ((((betS (y : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (y : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (y : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (y : mat_Point)) (A : mat_Point)) (m : mat_Point)) ==> ((((col (y : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (y : mat_Point)) (A : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (y : mat_Point)) (E : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ L0 : mat_Point. (((((pG (B : mat_Point)) (M : mat_Point)) (L0 : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L0 : mat_Point)) ==> ((((betS (D : mat_Point)) (L0 : mat_Point)) (E : mat_Point)) ==> ((((betS (L0 : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (L0 : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L0 : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (L0 : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (L0 : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (L0 : mat_Point)) ==> (((neq (L0 : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (L0 : mat_Point)) ==> ((((per (E : mat_Point)) (L0 : mat_Point)) (A : mat_Point)) ==> (((eq (L0 : mat_Point)) (l : mat_Point)) ==> ((((betS (L0 : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L0 : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> ((((col (L0 : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (L0 : mat_Point)) (A : mat_Point)) (m : mat_Point)) ==> ((((col (L0 : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (L0 : mat_Point)) (A : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (L0 : mat_Point)) (E : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (l : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (l : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (l : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (l : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (l : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (M : mat_Point)) (l : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (l : mat_Point)) (l : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (l : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (l : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (m : mat_Point)) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (x : mat_Point)) (l : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (X : mat_Point)) (l : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (M : mat_Point)) (m : mat_Point))) ==> ((eq (M : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (m : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (M : mat_Point)) (m : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (M : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (M : mat_Point))) (((col (m : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (M : mat_Point)) (m : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (M : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (M : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (m : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (m : mat_Point))) (((col (M : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (m : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (m : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (m : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (L : mat_Point)) (m : mat_Point))) ((neq (L : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (m : mat_Point))) ((neq (L : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (m : mat_Point))) ((neq (L : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (L : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (m : mat_Point))) ((neq (L : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (L : mat_Point)) (m : mat_Point))) ((neq (L : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and (((col (A : mat_Point)) (L : mat_Point)) (m : mat_Point))) ((mat_and (((col (L : mat_Point)) (A : mat_Point)) (m : mat_Point))) (((col (A : mat_Point)) (m : mat_Point)) (L : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (A : mat_Point))) ((mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (A : mat_Point))) ((mat_or ((eq (m : mat_Point)) (A : mat_Point))) ((mat_or (((betS (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (A : mat_Point))) ((mat_or (((betS (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((mat_or (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (l : mat_Point)) ==> (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (l : mat_Point)) (L : mat_Point)) ==> (((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) ==> ((((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)) ==> ((((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)) ==> (((neq (L : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (L : mat_Point)) ==> ((((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) ==> (((eq (L : mat_Point)) (l : mat_Point)) ==> (((betS (L : mat_Point)) (m : mat_Point)) (A : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((pG (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (l : mat_Point)) ==> ((((betS (D : mat_Point)) (l : mat_Point)) (E : mat_Point)) ==> ((((betS (l : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (l : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (l : mat_Point)) ==> (((neq (l : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (l : mat_Point)) ==> ((((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)) ==> (((eq (l : mat_Point)) (l : mat_Point)) ==> (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))))))))))))))) ==> (! y : mat_Point. (((eq (l : mat_Point)) (y : mat_Point)) ==> (((((pG (B : mat_Point)) (M : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (y : mat_Point)) ==> ((((betS (D : mat_Point)) (y : mat_Point)) (E : mat_Point)) ==> ((((betS (y : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (y : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (y : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (y : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (y : mat_Point)) ==> (((neq (y : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (y : mat_Point)) ==> ((((per (E : mat_Point)) (y : mat_Point)) (A : mat_Point)) ==> (((eq (y : mat_Point)) (l : mat_Point)) ==> (((betS (y : mat_Point)) (m : mat_Point)) (A : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ L0 : mat_Point. (((((pG (B : mat_Point)) (M : mat_Point)) (L0 : mat_Point)) (D : mat_Point)) ==> (((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L0 : mat_Point)) ==> ((((betS (D : mat_Point)) (L0 : mat_Point)) (E : mat_Point)) ==> ((((betS (L0 : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((per (D : mat_Point)) (L0 : mat_Point)) (A : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L0 : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (L0 : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (E : mat_Point)) (L0 : mat_Point)) ==> ((((col (E : mat_Point)) (l : mat_Point)) (L0 : mat_Point)) ==> (((neq (L0 : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (L0 : mat_Point)) ==> ((((per (E : mat_Point)) (L0 : mat_Point)) (A : mat_Point)) ==> (((eq (L0 : mat_Point)) (l : mat_Point)) ==> (((betS (L0 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (l : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (l : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (l : mat_Point)) (l : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (l : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__equalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (l : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__droppedperpendicularunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (L : mat_Point))) ((neq (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (L : mat_Point))) ((neq (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (L : mat_Point))) ((neq (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (L : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (L : mat_Point))) ((neq (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (L : mat_Point))) ((neq (D : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (l : mat_Point)) (L : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (l : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (l : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (l : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (l : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (l : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (l : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (l : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (l : mat_Point))) (((col (D : mat_Point)) (l : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (l : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (L : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (L : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((col (E : mat_Point)) (L : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (L : mat_Point)) (E : mat_Point))) ((mat_or (((betS (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (E : mat_Point))) ((mat_or (((betS (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (l : mat_Point)) (D : mat_Point))) ((mat_or (((betS (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (l : mat_Point)) (D : mat_Point))) ((mat_or (((betS (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (l : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (l : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (D : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (l : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (l : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (l : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (l : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (l : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (l : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (l : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (l : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point))) ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (l : mat_Point))) ((mat_and (((betS (E : mat_Point)) (l : mat_Point)) (D : mat_Point))) ((mat_and (((betS (l : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((per (E : mat_Point)) (l : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (C : mat_Point)) (m : mat_Point)) (l : mat_Point)) (E : mat_Point)))))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__47B
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))) ((((oS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) ==> ((((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (L : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (L : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) ==> ((((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (D : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (D : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__squareparallelogram
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__squareflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))))))`
                                      ))))
                                ) (ASSUME `(mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))`
                                ))))
                          ) (ASSUME `ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))`
                          ))))
                    ) (ASSUME `ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((pG (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point))) ((mat_and (((betS (D : mat_Point)) (L : mat_Point)) (E : mat_Point))) ((mat_and (((betS (L : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)))))))))))`
                    ))
                  ) (MP  
                     (MP  
                      (MP  
                       (MP  
                        (MP  
                         (MP  
                          (SPEC `(G : mat_Point)` 
                           (SPEC `(F : mat_Point)` 
                            (SPEC `(E : mat_Point)` 
                             (SPEC `(D : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` (proposition__47B))))
                             )))
                          ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                          )
                         ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                         )
                        ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                        )
                       ) (ASSUME `(((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                       )
                      ) (ASSUME `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                      )
                     ) (ASSUME `(((tS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                     )))))))))))))))))))
 ;;


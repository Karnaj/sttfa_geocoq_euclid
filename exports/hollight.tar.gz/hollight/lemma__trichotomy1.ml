(*lemma__trichotomy1 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((mat_not ((((lt A) B) C) D)) ==> ((mat_not ((((lt C) D) A) B)) ==> (((neq A) B) ==> (((neq C) D) ==> ((((cong A) B) C) D))))))))`*)
let lemma__trichotomy1 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
     (DISCH `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
      (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
       (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
        (MP  
         (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
          (MP  
           (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                (SPEC `\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(P : mat_Point)` 
                 (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                       (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                            (MP  
                             (DISCH `(neq (P : mat_Point)) (A : mat_Point)` 
                              (MP  
                               (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                    (SPEC `\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(E : mat_Point)` 
                                     (DISCH `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                           (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> mat_false) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                              (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                               (MP  
                                                (CONV_CONV_rule `((((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                 (DISCH `mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                  (MP  
                                                   (DISCH `(eq (E : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                          (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          )
                                                         ) (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (CONV_CONV_rule `((eq (E : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. ((((betS (P : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> (((((cong (A : mat_Point)) (E0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E0 : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (E0 : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                 ) (ASSUME `(eq (E : mat_Point)) (B : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                               )
                                                              ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                              )
                                                             ) (ASSUME `mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                             )
                                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (CONV_CONV_rule `((eq (E : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))))` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point))))))))` 
                                                                  (SPEC `\ E0 : mat_Point. ((((betS (P : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> (((((cong (A : mat_Point)) (E0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E0 : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (E0 : mat_Point)) (B : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point))))))` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                 ) (DISCH `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                              ) (ASSUME `(eq (E : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                             )
                                                            ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                           )
                                                          ) (ASSUME `mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                          )))
                                                     ) (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (cn__congruencereflexive
                                                         ))))
                                                   ) (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (SPEC `(P : mat_Point)` 
                                                             (lemma__outerconnectivity
                                                             ))))
                                                         ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `mat_not (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                       )
                                                      ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                      ))))
                                                ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> mat_false` 
                                                     (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                        (ASSUME `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                        )
                                                       ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                       )))
                                                    ) (MP  
                                                       (SPEC `(E : mat_Point)` 
                                                        (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                                                         (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (ex__intro))))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                             (conj))
                                                           ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          )))))))
                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                    (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                         (ASSUME `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                         )
                                                        ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                        ))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (lemma__lessthancongruence
                                                                ))))))
                                                          ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         ))))
                                                   ) (MP  
                                                      (SPEC `(B : mat_Point)` 
                                                       (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                        (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (ex__intro))))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                            (conj))
                                                          ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                         ))))
                                                 ) (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (cn__congruencereflexive
                                                     ))))))))
                                       ) (ASSUME `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                       ))))
                                 ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                 ))
                               ) (MP  
                                  (MP  
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(P : mat_Point)` 
                                       (lemma__extension))))
                                   ) (ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                   )
                                  ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                  )))
                             ) (MP  
                                (SPEC `(P : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (lemma__inequalitysymmetric))
                                ) (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                )))
                           ) (MP  
                              (DISCH `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                  (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                                   (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                    (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                        (SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                         (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                           (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point)))`
                                ))
                              ) (MP  
                                 (SPEC `(P : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (lemma__betweennotequal)))
                                 ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                 ))))
                         ) (MP  
                            (SPEC `(P : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (axiom__betweennesssymmetry)))
                            ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                            )))))
                   ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                   ))))
             ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
             ))
           ) (MP  
              (MP  
               (SPEC `(B : mat_Point)` 
                (SPEC `(A : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` (lemma__extension))))
               ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`)
              ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
            ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`))))))))))
 ;;


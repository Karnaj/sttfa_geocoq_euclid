(*proposition__23 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((neq A) B) ==> ((((nCol D) C) E) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out A) B) Y)) ((((((congA X) A) Y) D) C) E))))))))))))`*)
let proposition__23 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
      (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
       (MP  
        (CONV_CONV_rule `((((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
         (DISCH `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
          (MP  
           (CONV_CONV_rule `((((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
            (DISCH `mat_not (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
             (MP  
              (CONV_CONV_rule `(((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
               (DISCH `((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `(((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                  (DISCH `((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `(((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                     (DISCH `((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (MP  
                       (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                        (MP  
                         (DISCH `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (MP  
                           (DISCH `(((((tG (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                            (MP  
                             (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                              (MP  
                               (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `(((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (MP  
                                         (DISCH `ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((triangle (A : mat_Point)) (x : mat_Point)) (F : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))))) ==> (return : bool)))` 
                                              (SPEC `\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__ind))))
                                            ) (GEN `(G : mat_Point)` 
                                               (DISCH `ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (x : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))) ==> (return : bool)))` 
                                                    (SPEC `\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__ind))))
                                                  ) (GEN `(F : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                         (SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                          (SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                               (SPEC `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (F : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (x : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((((congA (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ==> (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (F : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((((((congA (F : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (v : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (G : mat_Point))) ==> (((out (A : mat_Point)) (G : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (G : mat_Point)) (F : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (G : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (G : mat_Point)) (F : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (F : mat_Point))) ==> (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or (((betS (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or (((betS (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (E : mat_Point))) ==> (((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))`
                                                       ))))
                                                 ) (ASSUME `ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))`
                                                 ))))
                                           ) (ASSUME `ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (A : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((triangle (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))))))`
                                           ))
                                         ) (MP  
                                            (MP  
                                             (MP  
                                              (MP  
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (proposition__22))))))
                                                 ))
                                               ) (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                               )
                                              ) (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (ASSUME `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                            )))
                                       ) (MP  
                                          (DISCH `(mat_and ((((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (ASSUME `(((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((((((tG (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                            ))
                                          ) (MP  
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (lemma__TGflip))))))
                                             ) (ASSUME `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             ))))
                                     ) (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (lemma__TGsymmetric))))))
                                        ) (ASSUME `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                        )))
                                   ) (MP  
                                      (DISCH `(mat_and ((((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                           (SPEC `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                             (ASSUME `(((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and ((((((tG (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                        ))
                                      ) (MP  
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(E : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (lemma__TGflip))))))
                                         ) (ASSUME `(((((tG (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                         ))))
                                 ) (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (lemma__TGsymmetric))))))
                                    ) (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                    )))
                               ) (MP  
                                  (DISCH `(mat_and ((((((tG (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(((((tG (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((((tG (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                        (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                         (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                         )))
                                    ) (ASSUME `(mat_and ((((((tG (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                    ))
                                  ) (MP  
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (lemma__TGflip))))))
                                     ) (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                     ))))
                             ) (MP  
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (lemma__TGsymmetric))))))
                                ) (ASSUME `(((((tG (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                )))
                           ) (MP  
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(C : mat_Point)` (proposition__20)))
                              ) (ASSUME `((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(E : mat_Point)` (proposition__20)))
                            ) (ASSUME `((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                            )))
                       ) (MP  
                          (SPEC `(E : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(D : mat_Point)` (proposition__20)))
                          ) (ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                          ))))
                    ) (MP  
                       (SPEC `(D : mat_Point)` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(E : mat_Point)` (nCol__notCol)))
                       ) (ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                       ))))
                 ) (MP  
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(E : mat_Point)` 
                      (SPEC `(C : mat_Point)` (nCol__notCol)))
                    ) (ASSUME `mat_not (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                    ))))
              ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
              )))
           ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
              (MP  
               (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `(((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                  (ASSUME `mat_not (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                  )
                 ) (MP  
                    (CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(E : mat_Point)` (not__nCol__Col))))
                    ) (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (MP  
                        (MP  
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(D : mat_Point)` (col__nCol__False)))
                         ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                         )
                        ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                        )))))
               ) (MP  
                  (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                      (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                       (SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                             (SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                  (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                   (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                    (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                        (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                          (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                    ))
                  ) (MP  
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(E : mat_Point)` 
                       (SPEC `(C : mat_Point)` (lemma__collinearorder)))
                     ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                     )))))))
        ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
           (MP  
            (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
             (MP  
              (MP  
               (SPEC `(E : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(D : mat_Point)` (col__nCol__False)))
               ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
               )
              ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
              ))
            ) (MP  
               (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                (MP  
                 (MP  
                  (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                    (SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                      (MP  
                       (MP  
                        (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                         (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                          (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                           (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                            (MP  
                             (MP  
                              (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                               (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                     (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                      (SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                        (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                        )))
                                   ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                             ))))
                       ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                       ))))
                 ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                 ))
               ) (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(E : mat_Point)` (lemma__collinearorder)))
                  ) (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                  ))))))))))))
 ;;


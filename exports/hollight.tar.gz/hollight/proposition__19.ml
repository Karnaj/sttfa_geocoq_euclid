(*proposition__19 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> (((((((ltA B) C) A) A) B) C) ==> ((((lt A) B) A) C)))))`*)
let proposition__19 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (MP  
      (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
       (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
          (MP  
           (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
              (DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
               (MP  
                (CONV_CONV_rule `(((((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                 (DISCH `mat_not ((((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                  (MP  
                   (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `((mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                          (DISCH `mat_not (mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                           (MP  
                            (CONV_CONV_rule `((mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                             (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (nNPP))
                            ) (DISCH `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                               (MP  
                                (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                 (MP  
                                  (SPEC `mat_false` 
                                   (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                      (MP  
                                       (CONV_CONV_rule `(((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                        (MP  
                                         (SPEC `mat_false` 
                                          (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                             (MP  
                                              (CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                               (MP  
                                                (SPEC `mat_false` 
                                                 (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `mat_false` 
                                                       (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                        (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                              (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                     )))))
                                              ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              )))))
                                       ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                       )))))
                                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )))))
                         ) (DISCH `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                  (ASSUME `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                  )
                                 ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                 ))
                               ) (MP  
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__congruencesymmetric))))
                                  ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (MP  
                                  (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (lemma__trichotomy1))))
                                   ) (ASSUME `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                   )
                                  ) (ASSUME `mat_not ((((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                  )
                                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                 )
                                ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                )))))
                       ) (MP  
                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                           (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                         (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                            ))
                          ) (MP  
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (lemma__angledistinct))))))
                             ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             ))))
                     ) (MP  
                        (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                   (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                       (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                          ))
                        ) (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__angledistinct))))))
                           ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                           ))))
                   ) (MP  
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (lemma__equalanglesreflexive)
                        ))
                      ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      ))))
                ) (DISCH `(((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                     (DISCH `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                          (MP  
                           (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                (MP  
                                 (DISCH `mat_not ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                  (MP  
                                   (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                    (ASSUME `mat_not ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                    )
                                   ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                   ))
                                 ) (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (lemma__angletrichotomy))))))
                                    ) (ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__angleorderrespectscongruence
                                            )))))))))
                                   ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                   )
                                  ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                  )))
                             ) (MP  
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (lemma__ABCequalsCBA)))
                                ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (lemma__angleorderrespectscongruence2
                                        )))))))))
                               ) (ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                               )
                              ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` (lemma__ABCequalsCBA)))
                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(A : mat_Point)` (proposition__18)))
                           ) (ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                           )
                          ) (ASSUME `(((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                          ))))
                    ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                    )))))
             ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                    (DISCH `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                           (MP  
                            (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                               (MP  
                                (DISCH `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                 (MP  
                                  (CONV_CONV_rule `((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                   (ASSUME `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                   )
                                  ) (ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                  ))
                                ) (MP  
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (lemma__angletrichotomy))))))
                                   ) (ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                   )))
                              ) (MP  
                                 (MP  
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (lemma__angleorderrespectscongruence
                                           )))))))))
                                  ) (ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  )
                                 ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 )))
                            ) (MP  
                               (MP  
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (lemma__equalanglestransitive)))))))
                                  ))
                                ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                )
                               ) (ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                               )))
                          ) (MP  
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` (lemma__ABCequalsCBA))
                              )
                             ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                             )))
                        ) (MP  
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__equalanglessymmetric))))))
                           ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                           )))
                      ) (MP  
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (proposition__05)))
                         ) (ASSUME `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         ))))
                   ) (MP  
                      (MP  
                       (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (conj)))
                       ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )
                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                      )))
                 ) (MP  
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__congruencesymmetric)))
                     )
                    ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                    )))))
           ) (MP  
              (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
               (MP  
                (MP  
                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                  (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                   (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                    (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                     (MP  
                      (MP  
                       (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                         (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                           (MP  
                            (MP  
                             (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                      (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                       )))
                                  ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                            ))))
                      ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                      ))))
                ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                ))
              ) (MP  
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` (lemma__NCorder)))
                 ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                 ))))
         ) (MP  
            (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                 (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                      (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                       (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                        (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                            (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                             (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                   (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                     (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
              ))
            ) (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (lemma__NCorder)))
               ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )))))
      ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
      ))))))
 ;;


(*lemma__diagonalsmeet :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((pG A) B) C) D) ==> (ex (\ X : mat_Point. ((mat_and (((betS A) X) C)) (((betS B) X) D))))))))`*)
let lemma__diagonalsmeet =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
       (MP  
        (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))` 
         (MP  
          (MP  
           (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (x : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
             (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))))))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(a : mat_Point)` 
              (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                   (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(b : mat_Point)` 
                    (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (x : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (x : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                         (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(c : mat_Point)` 
                          (DISCH `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (c : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (x : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool)))` 
                               (SPEC `\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(d : mat_Point)` 
                                (DISCH `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool)))` 
                                     (SPEC `\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__ind))))
                                   ) (GEN `(m : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                          (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))` 
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))` 
                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                      (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))` 
                                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                            (SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))` 
                                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                              (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                  (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))` 
                                                                   (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (D : mat_Point)) (D : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (S : mat_Point)) (C : mat_Point))) ((mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_or (((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H73 : mat_Point. ((mat_and (((betS (C : mat_Point)) (H73 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H73 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ H74 : mat_Point. ((mat_and (((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H74 : mat_Point. ((mat_and (((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H74 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or ((eq (E : mat_Point)) (H74 : mat_Point))) ((mat_or ((eq (F : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))) (((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (F : mat_Point)) (B : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (H74 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or ((eq (E : mat_Point)) (R : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ T : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ T : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (T : mat_Point)) (B : mat_Point))) ((mat_or ((eq (T : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_or (((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (H74 : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (H74 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H74 : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H74 : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (H74 : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (D : mat_Point))) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj)))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearbetween
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (T : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H74 : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H74 : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H74 : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H74 : mat_Point))) (((col (B : mat_Point)) (H74 : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (T : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (T : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_or (((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_or (((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_or (((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ p : mat_Point. ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (x : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (T : mat_Point))) ((mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (R : mat_Point)) (A : mat_Point))) ((mat_or (((betS (R : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (R : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj)))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (T : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (T : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) (((col (T : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (D : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((col (R : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (C : mat_Point)) (B : mat_Point)) ==> (((neq (C : mat_Point)) (T : mat_Point)) ==> (mat_not ((eq (A : mat_Point)) (D : mat_Point))))) ==> (((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))) ==> ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (T : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (R : mat_Point)) (A : mat_Point))) ((mat_or (((betS (R : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (R : mat_Point)) (A : mat_Point))) ((mat_or (((betS (R : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (R : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (R : mat_Point))) (((col (p : mat_Point)) (R : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (T : mat_Point))) ((mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ p : mat_Point. ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (T : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (p : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (p : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (R : mat_Point)) (T : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ T : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or ((eq (E : mat_Point)) (R : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (R : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((((cong (E : mat_Point)) (R : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (H74 : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_and (((col (F : mat_Point)) (H74 : mat_Point)) (E : mat_Point))) ((mat_and (((col (H74 : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))) (((col (H74 : mat_Point)) (F : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (H74 : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (H74 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (H74 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (H74 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (H74 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (H74 : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (H74 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H74 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (F : mat_Point)) (B : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (B : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (H74 : mat_Point))) ((mat_or ((eq (F : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))) (((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))) (((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))) (((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))) (((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (E : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H74 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (H74 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H74 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H73 : mat_Point. ((mat_and (((betS (C : mat_Point)) (H73 : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H73 : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__outer
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (S : mat_Point))) ((mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (S : mat_Point))) ((mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (S : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (S : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (S : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearbetween
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (S : mat_Point))) ((mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj)))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (S : mat_Point)) (C : mat_Point)) ==> (((neq (S : mat_Point)) (B : mat_Point)) ==> (mat_not ((eq (A : mat_Point)) (D : mat_Point))))) ==> (((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))) ==> ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or ((eq (C : mat_Point)) (R : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or ((eq (C : mat_Point)) (R : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (R : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (C : mat_Point))) (((col (S : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (S : mat_Point))) ((mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (S : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) (((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (E : mat_Point)) (A : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (S : mat_Point)) (C : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_or (((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (S : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_or (((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_or (((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (S : mat_Point))) ((((cong (C : mat_Point)) (S : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> (((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((pG (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (D : mat_Point)) (B : mat_Point)) ==> ((((col (D : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((oS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> ((eq (D : mat_Point)) (D : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> (((((pG (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((eq (x : mat_Point)) (x : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. (((((pG (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((oS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> ((eq (A0 : mat_Point)) (A0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((pG (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> (((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((pG (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (D : mat_Point)) (B : mat_Point)) ==> ((((col (D : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((oS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> (((((pG (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. (((((pG (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((mat_not ((((meet (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((par (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((tP (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((oS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((col (D : mat_Point)) (C : mat_Point)) (A0 : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((pG (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (D : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (D : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))`
                                        ))))
                                  ) (ASSUME `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))`
                                  ))))
                            ) (ASSUME `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))`
                            ))))
                      ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))`
                      ))))
                ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))`
                ))))
          ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))`
          ))
        ) (MP  
           (CONV_CONV_rule `((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))))))))` 
            (MP  
             (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))` 
              (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
               (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                (and__ind)))
             ) (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                 (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                 ))))
           ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
          (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
           (MP  
            (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (conj))
                     ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                     )
                    ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    ))))
              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
              ))
            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
            )))
         ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


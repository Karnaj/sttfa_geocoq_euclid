(*proposition__40 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! H : mat_Point. (((((cong B) C) H) E) ==> (((((((eT A) B) C) D) H) E) ==> ((((triangle A) B) C) ==> ((((triangle D) H) E) ==> ((((col B) C) H) ==> ((((col B) C) E) ==> (((((oS A) D) B) C) ==> (((neq A) D) ==> ((((par A) D) B) C))))))))))))))`*)
let proposition__40 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(H : mat_Point)` 
      (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
       (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
        (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (DISCH `((triangle (D : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
          (DISCH `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
           (DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
            (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
              (MP  
               (CONV_CONV_rule `(((triangle (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                (DISCH `((nCol (D : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                 (MP  
                  (DISCH `(neq (H : mat_Point)) (E : mat_Point)` 
                   (MP  
                    (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                     (MP  
                      (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((((cong (H : mat_Point)) (x : mat_Point)) (E : mat_Point)) (H : mat_Point))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))) ==> (return : bool)))` 
                           (SPEC `\ R : mat_Point. ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(R : mat_Point)` 
                            (DISCH `(mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                 (SPEC `((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                  (DISCH `(((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                   (MP  
                                    (DISCH `((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                     (MP  
                                      (DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((mat_or ((eq (R : mat_Point)) (H : mat_Point))) ((mat_or ((eq (R : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_or (((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) (((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                         (DISCH `((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                          (MP  
                                           (DISCH `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                              (DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                 (DISCH `((col (H : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(neq (R : mat_Point)) (E : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((nCol (R : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (DISCH `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (x : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (x : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))))) ==> (return : bool)))` 
                                                            (SPEC `\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))))))))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__ind))))
                                                          ) (GEN `(P : mat_Point)` 
                                                             (DISCH `ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (x : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))) ==> (return : bool)))` 
                                                                  (SPEC `\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))))))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                  ))
                                                                ) (GEN `(Q : mat_Point)` 
                                                                   (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (x : mat_Point)) (H : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (P : mat_Point)) (Q : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (D : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (D : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__39
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETtransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    proposition__38
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((par (P : mat_Point)) (Q : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((col (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))) (((col (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (D : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))`
                                                                    ))))
                                                               ) (ASSUME `ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))`
                                                               ))))
                                                         ) (ASSUME `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (D : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))))`
                                                         ))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(H : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(R : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (proposition__31short
                                                               ))))
                                                           ) (ASSUME `((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                           )
                                                          ) (ASSUME `((nCol (R : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(R : mat_Point)` 
                                                           (nCol__notCol)))
                                                        ) (MP  
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(R : mat_Point)` 
                                                              (nCol__not__Col
                                                              )))
                                                           ) (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(R : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                 ) (ASSUME `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (H : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                               )
                                                              ) (ASSUME `(neq (R : mat_Point)) (E : mat_Point)`
                                                              )))))
                                                   ) (MP  
                                                      (DISCH `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (R : mat_Point)) (H : mat_Point))) ((neq (R : mat_Point)) (E : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(neq (R : mat_Point)) (E : mat_Point)` 
                                                          (SPEC `(mat_and ((neq (R : mat_Point)) (H : mat_Point))) ((neq (R : mat_Point)) (E : mat_Point))` 
                                                           (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (H : mat_Point)) (E : mat_Point)` 
                                                            (DISCH `(mat_and ((neq (R : mat_Point)) (H : mat_Point))) ((neq (R : mat_Point)) (E : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(neq (R : mat_Point)) (E : mat_Point)` 
                                                                (SPEC `(neq (R : mat_Point)) (E : mat_Point)` 
                                                                 (SPEC `(neq (R : mat_Point)) (H : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (R : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(neq (R : mat_Point)) (E : mat_Point)` 
                                                                   (ASSUME `(neq (R : mat_Point)) (E : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((neq (R : mat_Point)) (H : mat_Point))) ((neq (R : mat_Point)) (E : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (R : mat_Point)) (H : mat_Point))) ((neq (R : mat_Point)) (E : mat_Point)))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(H : mat_Point)` 
                                                           (SPEC `(R : mat_Point)` 
                                                            (lemma__betweennotequal
                                                            )))
                                                         ) (ASSUME `((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                         )))))
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point)))))` 
                                                    (SPEC `(eq (H : mat_Point)) (E : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))))` 
                                                       (SPEC `(eq (H : mat_Point)) (E : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `(mat_or (((betS (E : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (H : mat_Point)) (E : mat_Point)) (E : mat_Point)))` 
                                                          (SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                         ))))))
                                             ) (SPEC `(E : mat_Point)` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (eq__refl))))
                                           ) (MP  
                                              (DISCH `(mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                  (SPEC `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))))` 
                                                   (SPEC `((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                    (DISCH `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                        (SPEC `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)))` 
                                                         (SPEC `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                          (DISCH `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                              (SPEC `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))` 
                                                               (SPEC `((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point)` 
                                                                (DISCH `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (H : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((col (E : mat_Point)) (H : mat_Point)) (R : mat_Point)))))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(H : mat_Point)` 
                                                   (SPEC `(R : mat_Point)` 
                                                    (lemma__collinearorder)))
                                                 ) (ASSUME `((col (R : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                 )))))
                                        ) (MP  
                                           (SPEC `(mat_or ((eq (R : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_or (((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) (((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                            (SPEC `(eq (R : mat_Point)) (H : mat_Point)` 
                                             (or__intror))
                                           ) (MP  
                                              (SPEC `(mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_or (((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) (((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                               (SPEC `(eq (R : mat_Point)) (E : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or (((betS (H : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_or (((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) (((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                  (SPEC `(eq (H : mat_Point)) (E : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `(mat_or (((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point))) (((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                     (SPEC `((betS (H : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `((betS (R : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                        (SPEC `((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                         (or__introl))
                                                       ) (ASSUME `((betS (R : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                       )))))))
                                      ) (MP  
                                         (DISCH `(mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                              (SPEC `((nCol (H : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (H : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                    (SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                           (DISCH `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                 (DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                  (ASSUME `((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                           ))
                                         ) (MP  
                                            (SPEC `(E : mat_Point)` 
                                             (SPEC `(H : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (lemma__NCorder)))
                                            ) (ASSUME `((nCol (D : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                            ))))
                                    ) (MP  
                                       (SPEC `(R : mat_Point)` 
                                        (SPEC `(H : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (axiom__betweennesssymmetry)))
                                       ) (ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point)`
                                       )))))
                              ) (ASSUME `(mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                              ))))
                        ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (R : mat_Point))) ((((cong (H : mat_Point)) (R : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                        ))
                      ) (MP  
                         (MP  
                          (SPEC `(H : mat_Point)` 
                           (SPEC `(E : mat_Point)` 
                            (SPEC `(H : mat_Point)` 
                             (SPEC `(E : mat_Point)` (lemma__extension))))
                          ) (ASSUME `(neq (E : mat_Point)) (H : mat_Point)`)
                         ) (ASSUME `(neq (E : mat_Point)) (H : mat_Point)`)))
                    ) (MP  
                       (SPEC `(E : mat_Point)` 
                        (SPEC `(H : mat_Point)` (lemma__inequalitysymmetric))
                       ) (ASSUME `(neq (H : mat_Point)) (E : mat_Point)`)))
                  ) (MP  
                     (DISCH `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                         (SPEC `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                          (SPEC `(neq (D : mat_Point)) (H : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                           (DISCH `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                               (SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (H : mat_Point)) (E : mat_Point)` 
                                 (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                     (SPEC `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                      (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                       (DISCH `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                           (SPEC `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                            (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                                             (DISCH `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                                 (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                   (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                    (ASSUME `(neq (H : mat_Point)) (E : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                             ))))
                       ) (ASSUME `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
                       ))
                     ) (MP  
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(H : mat_Point)` 
                          (SPEC `(D : mat_Point)` (lemma__NCdistinct)))
                        ) (ASSUME `((nCol (D : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                        )))))
               ) (ASSUME `((triangle (D : mat_Point)) (H : mat_Point)) (E : mat_Point)`
               )))))))))))))))
 ;;


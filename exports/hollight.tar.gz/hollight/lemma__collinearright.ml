(*lemma__collinearright :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((per A) B) D) ==> ((((col A) B) C) ==> (((neq C) B) ==> (((per C) B) D)))))))`*)
let lemma__collinearright =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
         (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
          (MP  
           (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
            (MP  
             (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
              (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
               (MP  
                (DISCH `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                 (MP  
                  (DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (DISCH `((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                     )
                    ) (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(D : mat_Point)` (lemma__8__2)))
                       ) (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )))
                  ) (MP  
                     (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                      (MP  
                       (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                        (MP  
                         (MP  
                          (MP  
                           (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                              (or__ind)))
                           ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                (DISCH `mat_not (mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                 (MP  
                                  (CONV_CONV_rule `((mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (nNPP))
                                  ) (DISCH `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                       (MP  
                                        (SPEC `mat_false` 
                                         (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `mat_false` 
                                               (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `mat_false` 
                                                     (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                      (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `mat_false` 
                                                           (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                            (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                             (and__ind)))
                                                          ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                             (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `mat_false` 
                                                                 (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                  (SPEC `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                   (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                               ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))`
                                             )))))
                                      ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                      )))))
                               ) (DISCH `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                    (DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                       (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                       )
                                      ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                      )))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                      ))))))
                          ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                             (MP  
                              (MP  
                               (MP  
                                (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                  (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                   (or__ind)))
                                ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )
                                    ) (MP  
                                       (MP  
                                        (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (MP  
                                             (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                              (SPEC `(A : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (B : mat_Point))) ==> ((((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((per (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (B : mat_Point))) ==> ((((per (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                 (SPEC `\ A0 : mat_Point. ((((per (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (A0 : mat_Point)) (B : mat_Point))) ==> ((((per (D : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (eq__ind__r))))
                                                ) (DISCH `((per (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `mat_not ((eq (C : mat_Point)) (B : mat_Point))` 
                                                      (DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       ))))))))
                                             ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                             )
                                            ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                            )
                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )
                                          ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                          ))
                                        ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                        )
                                       ) (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                       ))))
                               ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (or__ind)))
                                     ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (CONV_CONV_rule `((mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                          (DISCH `mat_not (mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                           (MP  
                                            (CONV_CONV_rule `((mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                             (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (nNPP))
                                            ) (DISCH `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                 (MP  
                                                  (SPEC `mat_false` 
                                                   (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                          (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `mat_false` 
                                                               (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))`
                                                       )))))
                                                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                )))))
                                         ) (DISCH `mat_not (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (DISCH `(eq (C : mat_Point)) (B : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((eq (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                )
                                               ) (ASSUME `(eq (C : mat_Point)) (B : mat_Point)`
                                               ))
                                             ) (MP  
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (lemma__equalitysymmetric))
                                                ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                ))))))
                                    ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (MP  
                                          (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                             (or__ind)))
                                          ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                               (MP  
                                                (DISCH `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                   )
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (lemma__8__3))))
                                                      ) (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                      )
                                                     ) (ASSUME `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__ray4)))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                        (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                            (or__intror))
                                                          ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                          )))
                                                   ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (lemma__inequalitysymmetric
                                                    )))
                                                 ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                 ))))
                                         ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (MP  
                                               (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (or__ind)))
                                               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                    (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))) ==> (return : bool)))` 
                                                         (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (ex__ind))))
                                                       ) (GEN `(E : mat_Point)` 
                                                          (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (E : mat_Point))))) ==> (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))`
                                                            ))))
                                                      ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))`
                                                      )))
                                                   ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                   )))
                                              ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((out (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (lemma__ray5
                                                                  )))
                                                               ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                               )))
                                                          ) (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                          ))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__ray4))
                                                             )
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                  )))
                                                           ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (lemma__inequalitysymmetric
                                                           ))
                                                         ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__betweennotequal
                                                             )))
                                                          ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (axiom__betweennesssymmetry
                                                        )))
                                                     ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                     ))))
                                             ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                             )))
                                        ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                        )))
                                   ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                   )))
                              ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                              )))
                         ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                         ))
                       ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                       ))
                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                     )))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__8__2)))
                   ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                   ))))
             ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `((nCol (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                    (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                       (DISCH `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                        (MP  
                         (DISCH `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                          (MP  
                           (MP  
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(A : mat_Point)` (col__nCol__False)))
                            ) (ASSUME `((nCol (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                            )
                           ) (ASSUME `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                           ))
                         ) (MP  
                            (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                (SPEC `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                 (SPEC `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                       (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                             (SPEC `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                              (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                    (DISCH `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                     (ASSUME `((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))))`
                              ))
                            ) (MP  
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (lemma__collinearorder)))
                               ) (ASSUME `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                               )))))
                      ) (MP  
                         (SPEC `(mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point)))))` 
                          (SPEC `(eq (D : mat_Point)) (A : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))))` 
                             (SPEC `(eq (D : mat_Point)) (A : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point)))` 
                                (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                 (or__introl))
                               ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                               ))))))
                   ) (SPEC `(A : mat_Point)` 
                      (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                 ) (MP  
                    (MP  
                     (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((nCol (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                      (MP  
                       (MP  
                        (MP  
                         (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((nCol (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                          (SPEC `(A : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((((per (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((nCol (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((nCol (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((per (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (x : mat_Point)) (B : mat_Point))) ((mat_or ((eq (x : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_or (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (x : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((nCol (x : mat_Point)) (x : mat_Point)) (D : mat_Point))))))))` 
                             (SPEC `\ A0 : mat_Point. ((((per (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A0 : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A0 : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((nCol (A0 : mat_Point)) (A0 : mat_Point)) (D : mat_Point))))))` 
                              (SPEC `(B : mat_Point)` 
                               (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r)))
                             )
                            ) (DISCH `((per (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                               (DISCH `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                 (DISCH `((nCol (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (ASSUME `((nCol (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                  )))))))
                         ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)
                        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                        )
                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       ))
                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                     )
                    ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                    )))))
           ) (MP  
              (SPEC `(D : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__rightangleNC)))
              ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
              ))))
        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
      ))))))
 ;;


new_type("mat_Point",0);;

new_type("mat_Circle",0);;

new_constant("cong",`:mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> bool)))`);;

new_constant("betS",`:mat_Point -> (mat_Point -> (mat_Point -> bool))`);;

new_constant("pA",`:mat_Point`);;

new_constant("pB",`:mat_Point`);;

new_constant("pC",`:mat_Point`);;

new_constant("cI",`:mat_Circle -> (mat_Point -> (mat_Point -> (mat_Point -> bool)))`);;

(*eq :  |- `eq = eq`*)
let eq =

 new_basic_definition `eq = (\ x : A. (\ y : A. (! P : A -> bool. (((P : A -> bool) (x : A)) ==> ((P : A -> bool) (y : A))))))`
 ;;

let _ = (new_defs := ("eq",eq)::!new_defs);;

(*neq :  |- `neq = (\ A : mat_Point. (\ B : mat_Point. (mat_not ((eq A) B))))`*)
let neq =

 new_basic_definition `neq = (\ A : mat_Point. (\ B : mat_Point. (mat_not ((eq (A : mat_Point)) (B : mat_Point)))))`
 ;;

let _ = (new_defs := ("neq",neq)::!new_defs);;

(*tE :  |- `tE = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (mat_not ((mat_and ((neq A) B)) ((mat_and ((neq B) C)) (mat_not (((betS A) B) C))))))))`*)
let tE =

 new_basic_definition `tE = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (mat_not ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))`
 ;;

let _ = (new_defs := ("tE",tE)::!new_defs);;

(*nCol :  |- `nCol = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and ((neq A) B)) ((mat_and ((neq A) C)) ((mat_and ((neq B) C)) ((mat_and (mat_not (((betS A) B) C))) ((mat_and (mat_not (((betS A) C) B))) (mat_not (((betS B) A) C))))))))))`*)
let nCol =

 new_basic_definition `nCol = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))))`
 ;;

let _ = (new_defs := ("nCol",nCol)::!new_defs);;

(*col :  |- `col = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_or ((eq A) B)) ((mat_or ((eq A) C)) ((mat_or ((eq B) C)) ((mat_or (((betS B) A) C)) ((mat_or (((betS A) B) C)) (((betS A) C) B)))))))))`*)
let col =

 new_basic_definition `col = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("col",col)::!new_defs);;

(*cong__3 :  |- `cong__3 = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. ((mat_and ((((cong A) B) a) b)) ((mat_and ((((cong B) C) b) c)) ((((cong A) C) a) c)))))))))`*)
let cong__3 =

 new_basic_definition `cong__3 = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("cong__3",cong__3)::!new_defs);;

(*tS :  |- `tS = (\ P : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (\ Q : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS P) X) Q)) ((mat_and (((col A) B) X)) (((nCol A) B) P)))))))))`*)
let tS =

 new_basic_definition `tS = (\ P : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (\ Q : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("tS",tS)::!new_defs);;

(*triangle :  |- `triangle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (((nCol A) B) C))))`*)
let triangle =

 new_basic_definition `triangle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
 ;;

let _ = (new_defs := ("triangle",triangle)::!new_defs);;

(*onCirc :  |- `onCirc = (\ B : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI J) U) X) Y)) ((((cong U) B) X) Y))))))))))`*)
let onCirc =

 new_basic_definition `onCirc = (\ B : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))))`
 ;;

let _ = (new_defs := ("onCirc",onCirc)::!new_defs);;

(*inCirc :  |- `inCirc = (\ P : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI J) U) V) W)) ((mat_or ((eq P) U)) ((mat_and (((betS U) Y) X)) ((mat_and ((((cong U) X) V) W)) ((((cong U) P) U) Y)))))))))))))))))`*)
let inCirc =

 new_basic_definition `inCirc = (\ P : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (P : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (P : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))))))`
 ;;

let _ = (new_defs := ("inCirc",inCirc)::!new_defs);;

(*outCirc :  |- `outCirc = (\ P : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI J) U) V) W)) ((mat_and (((betS U) X) P)) ((((cong U) X) V) W)))))))))))))`*)
let outCirc =

 new_basic_definition `outCirc = (\ P : mat_Point. (\ J : mat_Circle. (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))))))))))))))`
 ;;

let _ = (new_defs := ("outCirc",outCirc)::!new_defs);;

(*cn__congruencetransitive :  |- `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((cong P) Q) B) C) ==> (((((cong P) Q) D) E) ==> ((((cong B) C) D) E))))))))`*)
let cn__congruencetransitive =

 new_axiom `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((cong (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))`
 ;;

(*cn__congruencereflexive :  |- `! A : mat_Point. (! B : mat_Point. ((((cong A) B) A) B))`*)
let cn__congruencereflexive =

 new_axiom `! A : mat_Point. (! B : mat_Point. ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
 ;;

(*cn__equalityreverse :  |- `! A : mat_Point. (! B : mat_Point. ((((cong A) B) B) A))`*)
let cn__equalityreverse =

 new_axiom `! A : mat_Point. (! B : mat_Point. ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
 ;;

(*cn__sumofparts :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong A) B) a) b) ==> (((((cong B) C) b) c) ==> ((((betS A) B) C) ==> ((((betS a) b) c) ==> ((((cong A) C) a) c))))))))))`*)
let cn__sumofparts =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)))))))))))`
 ;;

(*cn__stability :  |- `! A : mat_Point. (! B : mat_Point. ((mat_not ((neq A) B)) ==> ((eq A) B)))`*)
let cn__stability =

 new_axiom `! A : mat_Point. (! B : mat_Point. ((mat_not ((neq (A : mat_Point)) (B : mat_Point))) ==> ((eq (A : mat_Point)) (B : mat_Point))))`
 ;;

(*axiom__circle__center__radius :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! J : mat_Circle. (! P : mat_Point. (((((cI J) A) B) C) ==> (((onCirc P) J) ==> ((((cong A) P) B) C)))))))`*)
let axiom__circle__center__radius =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! J : mat_Circle. (! P : mat_Point. (((((cI (J : mat_Circle)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((onCirc (P : mat_Point)) (J : mat_Circle)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
 ;;

(*axiom__lower__dim :  |- `((nCol pA) pB) pC`*)
let axiom__lower__dim =

 new_axiom `((nCol pA) pB) pC`
 ;;

(*axiom__betweennessidentity :  |- `! A : mat_Point. (! B : mat_Point. (mat_not (((betS A) B) A)))`*)
let axiom__betweennessidentity =

 new_axiom `! A : mat_Point. (! B : mat_Point. (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
 ;;

(*axiom__betweennesssymmetry :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((betS A) B) C) ==> (((betS C) B) A))))`*)
let axiom__betweennesssymmetry =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
 ;;

(*axiom__innertransitivity :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) D) ==> ((((betS B) C) D) ==> (((betS A) B) C))))))`*)
let axiom__innertransitivity =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
 ;;

(*axiom__connectivity :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) D) ==> ((((betS A) C) D) ==> ((mat_not (((betS A) B) C)) ==> ((mat_not (((betS A) C) B)) ==> ((eq B) C))))))))`*)
let axiom__connectivity =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((eq (B : mat_Point)) (C : mat_Point)))))))))`
 ;;

(*axiom__nocollapse :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((neq A) B) ==> (((((cong A) B) C) D) ==> ((neq C) D))))))`*)
let axiom__nocollapse =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((neq (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point)))))))`
 ;;

(*axiom__5__line :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((cong B) C) b) c) ==> (((((cong A) D) a) d) ==> (((((cong B) D) b) d) ==> ((((betS A) B) C) ==> ((((betS a) b) c) ==> (((((cong A) B) a) b) ==> ((((cong D) C) d) c))))))))))))))`*)
let axiom__5__line =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)))))))))))))))`
 ;;

(*postulate__Pasch__inner :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((betS A) P) C) ==> ((((betS B) Q) C) ==> ((((nCol A) C) B) ==> (ex (\ X : mat_Point. ((mat_and (((betS A) X) Q)) (((betS B) X) P)))))))))))`*)
let postulate__Pasch__inner =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((betS (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (P : mat_Point))))))))))))`
 ;;

(*postulate__Pasch__outer :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((betS A) P) C) ==> ((((betS B) C) Q) ==> ((((nCol B) Q) A) ==> (ex (\ X : mat_Point. ((mat_and (((betS A) X) Q)) (((betS B) P) X)))))))))))`*)
let postulate__Pasch__outer =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((betS (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (P : mat_Point)) (X : mat_Point))))))))))))`
 ;;

(*postulate__Euclid2 :  |- `! A : mat_Point. (! B : mat_Point. (((neq A) B) ==> (ex (\ X : mat_Point. (((betS A) B) X)))))`*)
let postulate__Euclid2 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))`
 ;;

(*postulate__Euclid3 :  |- `! A : mat_Point. (! B : mat_Point. (((neq A) B) ==> (ex (\ X : mat_Circle. ((((cI X) A) A) B)))))`*)
let postulate__Euclid3 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Circle. ((((cI (X : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))`
 ;;

(*postulate__line__circle :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! K : mat_Circle. (! P : mat_Point. (! Q : mat_Point. (((((cI K) C) P) Q) ==> (((inCirc B) K) ==> (((neq A) B) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((col A) B) X)) ((mat_and (((betS A) B) Y)) ((mat_and ((onCirc X) K)) ((mat_and ((onCirc Y) K)) (((betS X) B) Y)))))))))))))))))`*)
let postulate__line__circle =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! K : mat_Circle. (! P : mat_Point. (! Q : mat_Point. (((((cI (K : mat_Circle)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (((inCirc (B : mat_Point)) (K : mat_Circle)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((onCirc (X : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Y : mat_Point)) (K : mat_Circle))) (((betS (X : mat_Point)) (B : mat_Point)) (Y : mat_Point))))))))))))))))))`
 ;;

(*postulate__circle__circle :  |- `! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! J : mat_Circle. (! K : mat_Circle. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! S : mat_Point. (((((cI J) C) R) S) ==> (((inCirc P) J) ==> (((outCirc Q) J) ==> (((((cI K) D) F) G) ==> (((onCirc P) K) ==> (((onCirc Q) K) ==> (ex (\ X : mat_Point. ((mat_and ((onCirc X) J)) ((onCirc X) K)))))))))))))))))))`*)
let postulate__circle__circle =

 new_axiom `! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! J : mat_Circle. (! K : mat_Circle. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! S : mat_Point. (((((cI (J : mat_Circle)) (C : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> (((inCirc (P : mat_Point)) (J : mat_Circle)) ==> (((outCirc (Q : mat_Point)) (J : mat_Circle)) ==> (((((cI (K : mat_Circle)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((onCirc (P : mat_Point)) (K : mat_Circle)) ==> (((onCirc (Q : mat_Point)) (K : mat_Circle)) ==> (ex (\ X : mat_Point. ((mat_and ((onCirc (X : mat_Point)) (J : mat_Circle))) ((onCirc (X : mat_Point)) (K : mat_Circle))))))))))))))))))))`
 ;;

(*postulate__Euclid5 :  |- `! a : mat_Point. (! p : mat_Point. (! q : mat_Point. (! r : mat_Point. (! s : mat_Point. (! t : mat_Point. ((((betS r) t) s) ==> ((((betS p) t) q) ==> ((((betS r) a) q) ==> (((((cong p) t) q) t) ==> (((((cong t) r) t) s) ==> ((((nCol p) q) s) ==> (ex (\ X : mat_Point. ((mat_and (((betS p) a) X)) (((betS s) q) X)))))))))))))))`*)
let postulate__Euclid5 =

 new_axiom `! a : mat_Point. (! p : mat_Point. (! q : mat_Point. (! r : mat_Point. (! s : mat_Point. (! t : mat_Point. ((((betS (r : mat_Point)) (t : mat_Point)) (s : mat_Point)) ==> ((((betS (p : mat_Point)) (t : mat_Point)) (q : mat_Point)) ==> ((((betS (r : mat_Point)) (a : mat_Point)) (q : mat_Point)) ==> (((((cong (p : mat_Point)) (t : mat_Point)) (q : mat_Point)) (t : mat_Point)) ==> (((((cong (t : mat_Point)) (r : mat_Point)) (t : mat_Point)) (s : mat_Point)) ==> ((((nCol (p : mat_Point)) (q : mat_Point)) (s : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (p : mat_Point)) (a : mat_Point)) (X : mat_Point))) (((betS (s : mat_Point)) (q : mat_Point)) (X : mat_Point))))))))))))))))`
 ;;

new_constant("eF",`:mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> bool)))))))`);;

new_constant("eT",`:mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> (mat_Point -> bool)))))`);;

(*axiom__congruentequal :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((cong__3 A) B) C) a) b) c) ==> ((((((eT A) B) C) a) b) c)))))))`*)
let axiom__congruentequal =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))`
 ;;

(*axiom__ETpermutation :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT A) B) C) a) b) c) ==> ((mat_and ((((((eT A) B) C) b) c) a)) ((mat_and ((((((eT A) B) C) a) c) b)) ((mat_and ((((((eT A) B) C) b) a) c)) ((mat_and ((((((eT A) B) C) c) b) a)) ((((((eT A) B) C) c) a) b)))))))))))`*)
let axiom__ETpermutation =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))))))`
 ;;

(*axiom__ETsymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT A) B) C) a) b) c) ==> ((((((eT a) b) c) A) B) C)))))))`*)
let axiom__ETsymmetric =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((eT (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
 ;;

(*axiom__EFpermutation :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF A) B) C) D) a) b) c) d) ==> ((mat_and ((((((((eF A) B) C) D) b) c) d) a)) ((mat_and ((((((((eF A) B) C) D) d) c) b) a)) ((mat_and ((((((((eF A) B) C) D) c) d) a) b)) ((mat_and ((((((((eF A) B) C) D) b) a) d) c)) ((mat_and ((((((((eF A) B) C) D) d) a) b) c)) ((mat_and ((((((((eF A) B) C) D) c) b) a) d)) ((((((((eF A) B) C) D) a) d) c) b)))))))))))))))`*)
let axiom__EFpermutation =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))))))))))))))))`
 ;;

(*axiom__halvesofequals :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((eT A) B) C) B) C) D) ==> (((((tS A) B) C) D) ==> (((((((eT a) b) c) b) c) d) ==> (((((tS a) b) c) d) ==> (((((((((eF A) B) D) C) a) b) d) c) ==> ((((((eT A) B) C) a) b) c)))))))))))))`*)
let axiom__halvesofequals =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((tS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((eT (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((tS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))`
 ;;

(*axiom__EFsymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF A) B) C) D) a) b) c) d) ==> ((((((((eF a) b) c) d) A) B) C) D)))))))))`*)
let axiom__EFsymmetric =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))))`
 ;;

(*axiom__EFtransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! S : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF A) B) C) D) a) b) c) d) ==> (((((((((eF a) b) c) d) P) Q) R) S) ==> ((((((((eF A) B) C) D) P) Q) R) S))))))))))))))`*)
let axiom__EFtransitive =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! S : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))))))))))))))`
 ;;

(*axiom__ETtransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT A) B) C) a) b) c) ==> (((((((eT a) b) c) P) Q) R) ==> ((((((eT A) B) C) P) Q) R)))))))))))`*)
let axiom__ETtransitive =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((((eT (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))`
 ;;

(*axiom__cutoff1 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS A) B) C) ==> ((((betS a) b) c) ==> ((((betS E) D) C) ==> ((((betS e) d) c) ==> (((((((eT B) C) D) b) c) d) ==> (((((((eT A) C) E) a) c) e) ==> ((((((((eF A) B) D) E) a) b) d) e))))))))))))))))`*)
let axiom__cutoff1 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((betS (e : mat_Point)) (d : mat_Point)) (c : mat_Point)) ==> (((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((eT (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (a : mat_Point)) (c : mat_Point)) (e : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (e : mat_Point)))))))))))))))))`
 ;;

(*axiom__cutoff2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS B) C) D) ==> ((((betS b) c) d) ==> (((((((eT C) D) E) c) d) e) ==> (((((((((eF A) B) D) E) a) b) d) e) ==> ((((((((eF A) B) C) E) a) b) c) e))))))))))))))`*)
let axiom__cutoff2 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((eT (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)))))))))))))))`
 ;;

(*axiom__paste1 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS A) B) C) ==> ((((betS a) b) c) ==> ((((betS E) D) C) ==> ((((betS e) d) c) ==> (((((((eT B) C) D) b) c) d) ==> (((((((((eF A) B) D) E) a) b) d) e) ==> ((((((eT A) C) E) a) c) e))))))))))))))))`*)
let axiom__paste1 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((betS (e : mat_Point)) (d : mat_Point)) (c : mat_Point)) ==> (((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> ((((((eT (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (a : mat_Point)) (c : mat_Point)) (e : mat_Point)))))))))))))))))`
 ;;

(*axiom__deZolt1 :  |- `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS B) E) D) ==> (mat_not ((((((eT D) B) C) E) B) C))))))`*)
let axiom__deZolt1 =

 new_axiom `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (mat_not ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
 ;;

(*axiom__deZolt2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! E : mat_Point. (! F : mat_Point. ((((triangle A) B) C) ==> ((((betS B) E) A) ==> ((((betS B) F) C) ==> (mat_not ((((((eT A) B) C) E) B) F)))))))))`*)
let axiom__deZolt2 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! E : mat_Point. (! F : mat_Point. ((((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> (mat_not ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))`
 ;;

(*axiom__paste2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! M : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. (! m : mat_Point. ((((betS B) C) D) ==> ((((betS b) c) d) ==> (((((((eT C) D) E) c) d) e) ==> (((((((((eF A) B) C) E) a) b) c) e) ==> ((((betS A) M) D) ==> ((((betS B) M) E) ==> ((((betS a) m) d) ==> ((((betS b) m) e) ==> ((((((((eF A) B) D) E) a) b) d) e))))))))))))))))))))`*)
let axiom__paste2 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! M : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. (! m : mat_Point. ((((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((((((eT (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)) ==> ((((betS (b : mat_Point)) (m : mat_Point)) (e : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (e : mat_Point)))))))))))))))))))))`
 ;;

(*axiom__paste3 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! M : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! m : mat_Point. (((((((eT A) B) C) a) b) c) ==> (((((((eT A) B) D) a) b) d) ==> ((((betS C) M) D) ==> (((mat_or (((betS A) M) B)) ((mat_or ((eq A) M)) ((eq M) B))) ==> ((((betS c) m) d) ==> (((mat_or (((betS a) m) b)) ((mat_or ((eq a) m)) ((eq m) b))) ==> ((((((((eF A) C) B) D) a) c) b) d))))))))))))))))`*)
let axiom__paste3 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! M : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! m : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) ==> ((((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((eq (M : mat_Point)) (B : mat_Point)))) ==> ((((betS (c : mat_Point)) (m : mat_Point)) (d : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (m : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (m : mat_Point))) ((eq (m : mat_Point)) (b : mat_Point)))) ==> ((((((((eF (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))))))`
 ;;

(*axiom__paste4 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! J : mat_Point. (! K : mat_Point. (! L : mat_Point. (! M : mat_Point. (! P : mat_Point. (! e : mat_Point. (! m : mat_Point. (((((((((eF A) B) m) D) F) K) H) G) ==> (((((((((eF D) B) e) C) G) H) M) L) ==> ((((betS A) P) C) ==> ((((betS B) P) D) ==> ((((betS K) H) M) ==> ((((betS F) G) L) ==> ((((betS B) m) D) ==> ((((betS B) e) C) ==> ((((betS F) J) M) ==> ((((betS K) J) L) ==> ((((((((eF A) B) C) D) F) K) M) L))))))))))))))))))))))))`*)
let axiom__paste4 =

 new_axiom `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! J : mat_Point. (! K : mat_Point. (! L : mat_Point. (! M : mat_Point. (! P : mat_Point. (! e : mat_Point. (! m : mat_Point. (((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) ==> (((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((betS (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> ((((betS (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> ((((betS (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) ==> ((((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) ==> ((((betS (F : mat_Point)) (J : mat_Point)) (M : mat_Point)) ==> ((((betS (K : mat_Point)) (J : mat_Point)) (L : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))))))))))))))))))))))))`
 ;;


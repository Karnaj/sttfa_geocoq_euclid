(*lemma__equalanglessymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((congA A) B) C) a) b) c) ==> ((((((congA a) b) c) A) B) C)))))))`*)
let lemma__equalanglessymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
       (MP  
        (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
         (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
          (MP  
           (MP  
            (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
              (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(U : mat_Point)` 
               (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                (MP  
                 (MP  
                  (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                    (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(V : mat_Point)` 
                     (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                          (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(u : mat_Point)` 
                           (DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                            (MP  
                             (MP  
                              (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                (SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(v : mat_Point)` 
                                 (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                      (SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                       (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                            (SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                             (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                  (SPEC `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                   (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                        (SPEC `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                              (SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                  (DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))) ==> ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (x : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v0 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (u : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (V : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (C : mat_Point))) (((col (V : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (V : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) (((col (A : mat_Point)) (V : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (V : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (V : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (V : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (V : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (U : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (U : mat_Point))) (((col (V : mat_Point)) (U : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (U : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearitypreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (u : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (v : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (u : mat_Point)) (v : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (u : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and (((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and (((col (c : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and (((col (v : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (v : mat_Point)) (c : mat_Point))) (((col (v : mat_Point)) (c : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (u : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (u : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (u : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (u : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (u : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (u : mat_Point))) (((col (c : mat_Point)) (u : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (u : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (u : mat_Point)) (c : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (u : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (u : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (u : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((col (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and (((col (u : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) (((col (u : mat_Point)) (a : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point))) ((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (v : mat_Point)) (u : mat_Point)) (V : mat_Point)) (U : mat_Point))) ((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                   ))))
                             ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                             ))))
                       ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                       ))))
                 ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                 ))))
           ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
           )))
        ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
        ))))))))
 ;;


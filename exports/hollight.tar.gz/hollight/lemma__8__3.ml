(*lemma__8__3 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((per A) B) C) ==> ((((out B) C) D) ==> (((per A) B) D))))))`*)
let lemma__8__3 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
        (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
         (MP  
          (MP  
           (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
             (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(E : mat_Point)` 
              (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                  (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                    (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                     (MP  
                      (MP  
                       (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                        (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                          (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                         (MP  
                                          (DISCH `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                           (MP  
                                            (DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                             (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (MP  
                                               (DISCH `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                (MP  
                                                 (DISCH `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                       (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (or__ind)))
                                                     ) (DISCH `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                   ))))))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                )))
                                                           ) (SPEC `(C : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (cn__congruencereflexive
                                                               ))))
                                                         ) (SPEC `(D : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (cn__congruencereflexive
                                                             )))))
                                                    ) (DISCH `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                             (or__ind)))
                                                          ) (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (D : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (D : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((out (B : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (E : mat_Point)) (C0 : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) ==> (((((cong (C0 : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (E : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                 ))))
                                                         ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))) ==> (((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                  (DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                ))))
                                                        ) (ASSUME `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                        )))
                                                   ) (ASSUME `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                   ))
                                                 ) (ASSUME `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                 ))
                                               ) (ASSUME `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                               )))
                                          ) (MP  
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (lemma__ray1)))
                                             ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                      (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                        (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__congruenceflip))))
                                              ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                             (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                      (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                           ))
                                         ) (MP  
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (lemma__congruenceflip))))
                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                            ))))
                                    ) (SPEC `(D : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (cn__congruencereflexive))))
                                  ) (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (cn__congruencereflexive))))))
                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                      ))))
                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                ))))
          ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
          )))
       ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)))
    ))))
 ;;


(*proposition__36 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (((((pG A) B) C) D) ==> (((((pG E) F) G) H) ==> ((((col A) D) E) ==> ((((col A) D) H) ==> ((((col B) C) F) ==> ((((col B) C) G) ==> (((((cong B) C) F) G) ==> ((((((((eF A) B) C) D) E) F) G) H)))))))))))))))`*)
let proposition__36 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
         (DISCH `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
          (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
           (DISCH `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
            (DISCH `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
             (DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
              (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
               (MP  
                (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (MP  
                  (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                   (MP  
                    (DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                     (MP  
                      (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                       (MP  
                        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                             (MP  
                              (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                               (MP  
                                (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                 (MP  
                                  (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                   (MP  
                                    (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                     (MP  
                                      (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))) ==> mat_false) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                           (DISCH `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))` 
                                            (MP  
                                             (DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                              (ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                              )
                                             ) (MP  
                                                (DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                         (SPEC `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                           (or__ind)))
                                                        ) (DISCH `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                           (MP  
                                                            (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (H : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))) ==> (return : bool)))` 
                                                                 (SPEC `\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__ind))
                                                                 ))
                                                               ) (GEN `(M : mat_Point)` 
                                                                  (DISCH `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) ==> ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__33
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                              ))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                 (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                  (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                               ))))
                                                       ) (DISCH `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                (SPEC `\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(M : mat_Point)` 
                                                                 (DISCH `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((par (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (G : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (H : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((par (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    proposition__33
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((par (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (H : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
                                                             ))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                 (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (H : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                              ))))
                                                      ) (ASSUME `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                      ))
                                                    ) (ASSUME `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                    ))
                                                  ) (ASSUME `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                  ))
                                                ) (MP  
                                                   (CONV_CONV_rule `((mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))) ==> mat_false) ==> ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                    (SPEC `(mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                     (nNPP))
                                                   ) (DISCH `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `mat_false` 
                                                               (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                 (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `(mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    )
                                                                   ) (
                                                                   ASSUME `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                   )))))
                                                             ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       )))))))
                                          ) (DISCH `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (DISCH `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                 (ASSUME `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                 )
                                                ) (MP  
                                                   (SPEC `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                     (or__introl))
                                                   ) (ASSUME `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                   (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                    (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                     (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `(((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                              (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(H : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (lemma__crisscross
                                                                   ))))
                                                               ) (ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                               ))
                                                             ) (DISCH `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                  (ASSUME `mat_not ((mat_or ((((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                  )
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cR (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                       ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                 )))))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                              (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                               (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (SPEC `(H : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(E : mat_Point)` 
                                                           (lemma__congruencesymmetric
                                                           ))))
                                                       ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                           )))
                                      ) (MP  
                                         (MP  
                                          (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                            (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                             (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (SPEC `(H : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (lemma__parallelsymmetric
                                                         ))))
                                                     ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                     ))))
                                               ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                         )))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                         (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                          (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                           (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(H : mat_Point)` 
                                                       (SPEC `(E : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__collinearparallel2
                                                            ))))))
                                                      ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                     )
                                                    ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                    )
                                                   ) (ASSUME `(neq (E : mat_Point)) (H : mat_Point)`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                       )))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                        (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                         (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__parallelsymmetric
                                                     ))))
                                                 ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 ))))
                                           ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                     )))
                                ) (MP  
                                   (MP  
                                    (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                     (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                      (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                       (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                           (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (MP  
                                               (MP  
                                                (SPEC `(H : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(G : mat_Point)` 
                                                   (SPEC `(F : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (lemma__congruencetransitive
                                                      ))))))
                                                ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                               ))))
                                         ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                   )))
                              ) (MP  
                                 (MP  
                                  (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                   (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                    (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                     (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (SPEC `(G : mat_Point)` 
                                              (SPEC `(H : mat_Point)` 
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(F : mat_Point)` 
                                                 (lemma__congruencesymmetric)
                                                )))
                                             ) (ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                             ))))
                                       ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                 )))
                            ) (MP  
                               (MP  
                                (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                 (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                  (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                   (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                       (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (DISCH `(mat_and ((((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                     (SPEC `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                      (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                       (DISCH `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                           (SPEC `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                            (SPEC `(((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                             (DISCH `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                 (SPEC `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                  (SPEC `(((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(G : mat_Point)` 
                                               (SPEC `(F : mat_Point)` 
                                                (SPEC `(H : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (proposition__34))))
                                              ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                              )))))
                                     ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                               )))
                          ) (MP  
                             (MP  
                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                 (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                           ))
                                         ) (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (lemma__NCdistinct)))
                                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            )))))
                                   ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                             )))
                        ) (MP  
                           (MP  
                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                              (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                               (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                            (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__parallelNC))))
                                          ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                          )))))
                                 ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                 ))))
                           ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                           )))
                      ) (MP  
                         (MP  
                          (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                           (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                            (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                 (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                         (SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))))` 
                                          (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                           (DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                               (SPEC `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))))` 
                                                (SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                     (SPEC `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))` 
                                                      (SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (E : mat_Point)) (G : mat_Point)` 
                                                       (DISCH `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))` 
                                                            (SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (H : mat_Point)) (E : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                 (SPEC `(neq (G : mat_Point)) (E : mat_Point)` 
                                                                  (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `(neq (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point)))))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (E : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (E : mat_Point))))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(G : mat_Point)` 
                                         (SPEC `(H : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (lemma__NCdistinct)))
                                        ) (ASSUME `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                        )))))
                               ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                         )))
                    ) (MP  
                       (MP  
                        (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                         (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                          (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                           (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                 (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(mat_and (((nCol (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                       (SPEC `(mat_and (((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                        (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                         (DISCH `(mat_and (((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                              (SPEC `((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                   (SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                    (SPEC `((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                     (DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                      (ASSUME `((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                           ))))
                                     ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(G : mat_Point)` 
                                       (SPEC `(F : mat_Point)` 
                                        (SPEC `(H : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (lemma__parallelNC))))
                                      ) (ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                       )))
                  ) (MP  
                     (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                      (MP  
                       (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                           (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                 (MP  
                                  (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                      (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                       (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                        (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                           (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                 (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                       (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                        (conj))
                                                      ) (ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                     ))))
                                               ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                               ))
                                             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                             )))
                                          ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          ))))
                                    ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                    ))
                                  ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                  )))
                               ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                               ))))
                         ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                         ))
                       ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                       ))
                     ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                     )))
                ) (MP  
                   (CONV_CONV_rule `((((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                    (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                     (MP  
                      (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                           (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                            (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                               (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                (MP  
                                 (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (conj))
                                          ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          )
                                         ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                         ))))
                                   ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                   ))
                                 ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                 )))
                              ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                              ))))
                        ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                        ))
                      ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                      )))
                   ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                   )))))))))))))))))
 ;;


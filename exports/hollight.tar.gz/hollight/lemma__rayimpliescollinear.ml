(*lemma__rayimpliescollinear :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((out A) B) C) ==> (((col A) B) C))))`*)
let lemma__rayimpliescollinear =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
      (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
       (MP  
        (MP  
         (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
           (SPEC `\ J : mat_Point. ((mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
         ) (GEN `(J : mat_Point)` 
            (DISCH `(mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
             (MP  
              (MP  
               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (DISCH `(neq (J : mat_Point)) (A : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((mat_or ((eq (J : mat_Point)) (A : mat_Point))) ((mat_or ((eq (J : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point))))))) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                       (DISCH `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `((mat_or ((eq (J : mat_Point)) (A : mat_Point))) ((mat_or ((eq (J : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (C : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point))))))) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                          (DISCH `((col (J : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )
                            ) (MP  
                               (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` (not__nCol__Col))))
                               ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (col__nCol__False)))
                                    ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )
                                   ) (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(J : mat_Point)` 
                                            (lemma__collinear4))))
                                        ) (ASSUME `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                        )
                                       ) (ASSUME `((col (J : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                       )
                                      ) (ASSUME `(neq (J : mat_Point)) (A : mat_Point)`
                                      )))))))
                         ) (MP  
                            (SPEC `(mat_or ((eq (J : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (C : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                             (SPEC `(eq (J : mat_Point)) (A : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (C : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                (SPEC `(eq (J : mat_Point)) (C : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or (((betS (A : mat_Point)) (J : mat_Point)) (C : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                      (SPEC `((betS (A : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `((betS (J : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                         (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                          (or__introl))
                                        ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                        ))))))))
                      ) (MP  
                         (SPEC `(mat_or ((eq (J : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                          (SPEC `(eq (J : mat_Point)) (A : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                             (SPEC `(eq (J : mat_Point)) (B : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `(mat_or (((betS (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_or (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                   (SPEC `((betS (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `((betS (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                      (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                       (or__introl))
                                     ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                     )))))))
                    ) (MP  
                       (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (J : mat_Point)) (A : mat_Point))) ((neq (J : mat_Point)) (B : mat_Point)))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (J : mat_Point)) (A : mat_Point)` 
                           (SPEC `(mat_and ((neq (J : mat_Point)) (A : mat_Point))) ((neq (J : mat_Point)) (B : mat_Point))` 
                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                             (DISCH `(mat_and ((neq (J : mat_Point)) (A : mat_Point))) ((neq (J : mat_Point)) (B : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (J : mat_Point)) (A : mat_Point)` 
                                 (SPEC `(neq (J : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(neq (J : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (J : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(neq (J : mat_Point)) (B : mat_Point)` 
                                    (ASSUME `(neq (J : mat_Point)) (A : mat_Point)`
                                    )))
                               ) (ASSUME `(mat_and ((neq (J : mat_Point)) (A : mat_Point))) ((neq (J : mat_Point)) (B : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (J : mat_Point)) (A : mat_Point))) ((neq (J : mat_Point)) (B : mat_Point)))`
                         ))
                       ) (MP  
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(J : mat_Point)` (lemma__betweennotequal))
                           )
                          ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                          ))))))
              ) (ASSUME `(mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))`
              ))))
        ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (J : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
        )))
     ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)))))
 ;;


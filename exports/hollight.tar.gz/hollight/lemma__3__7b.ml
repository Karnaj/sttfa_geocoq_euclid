(*lemma__3__7b :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) C) ==> ((((betS B) C) D) ==> (((betS A) B) D))))))`*)
let lemma__3__7b =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
            (MP  
             (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
              (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
              )
             ) (MP  
                (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(D : mat_Point)` (axiom__betweennesssymmetry)))
                ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                )))
           ) (MP  
              (MP  
               (SPEC `(A : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(D : mat_Point)` (lemma__3__7a))))
               ) (ASSUME `((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
               )
              ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
              )))
         ) (MP  
            (SPEC `(D : mat_Point)` 
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` (axiom__betweennesssymmetry)))
            ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
            )))
       ) (MP  
          (SPEC `(C : mat_Point)` 
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (axiom__betweennesssymmetry)))
          ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          ))))))))
 ;;


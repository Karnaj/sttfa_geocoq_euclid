(*lemma__layoff :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((neq A) B) ==> (((neq C) D) ==> (ex (\ X : mat_Point. ((mat_and (((out A) B) X)) ((((cong A) X) C) D)))))))))`*)
let lemma__layoff =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
     (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
        (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
         (MP  
          (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(E : mat_Point)` 
                (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                    (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                      (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (MP  
                        (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (MP  
                          (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                           (MP  
                            (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (MP  
                              (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ P : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(P : mat_Point)` 
                                    (DISCH `(mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                        (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                             (DISCH `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                              (MP  
                                               (SPEC `(P : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (SPEC `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                   )
                                                  ) (ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                  ))))
                                            ) (MP  
                                               (SPEC `(E : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                   )
                                                  ) (ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                  ))))))
                                      ) (ASSUME `(mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (lemma__extension))))
                                  ) (ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                  )
                                 ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                 )))
                            ) (ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                            ))
                          ) (MP  
                             (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                 (SPEC `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (DISCH `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                       (SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                         (DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                          (ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                          )))
                                     ) (ASSUME `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))`
                               ))
                             ) (MP  
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(E : mat_Point)` 
                                   (lemma__betweennotequal)))
                                ) (ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                ))))
                        ) (MP  
                           (SPEC `(E : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (axiom__betweennesssymmetry)))
                           ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                           )))))
                  ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
            ))
          ) (MP  
             (MP  
              (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` (lemma__extension)))))
              ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`)
             ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`))))
       ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
          (MP  
           (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
              (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
             ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))
           ) (MP  
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` (lemma__equalitysymmetric))
              ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`))))))))))
 ;;


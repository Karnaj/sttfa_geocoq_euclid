(*lemma__triangletoparallelogram :  |- `! A : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((par D) C) E) F) ==> ((((col E) F) A) ==> (ex (\ X : mat_Point. ((mat_and ((((pG A) X) C) D)) (((col E) F) X))))))))))`*)
let lemma__triangletoparallelogram =

 GEN `(A : mat_Point)` 
 (GEN `(C : mat_Point)` 
  (GEN `(D : mat_Point)` 
   (GEN `(E : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (DISCH `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
      (DISCH `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
       (MP  
        (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
         (MP  
          (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
             (MP  
              (DISCH `ex (\ B : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (D : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ B : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ B : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(B : mat_Point)` 
                    (DISCH `(mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                        (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                          (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (DISCH `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                               (MP  
                                (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                   (DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                    (MP  
                                     (DISCH `ex (\ c : mat_Point. (ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (x : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))))) ==> (return : bool)))` 
                                          (SPEC `\ c : mat_Point. (ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))))))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(c : mat_Point)` 
                                           (DISCH `ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (x : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))) ==> (return : bool)))` 
                                                (SPEC `\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))))))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(b : mat_Point)` 
                                                 (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (x : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))))))))))))))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))) ==> (return : bool)))` 
                                                      (SPEC `\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__ind))))
                                                    ) (GEN `(M : mat_Point)` 
                                                       (DISCH `(mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                           (SPEC `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                            (SPEC `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                             (DISCH `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                 (SPEC `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                  (SPEC `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (M : mat_Point))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (R : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (c : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (c : mat_Point)) (A : mat_Point))) ((mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or ((eq (A : mat_Point)) (b : mat_Point))) ((mat_or (((betS (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (F : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((pG (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((((pG (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (F : mat_Point)) ==> ((((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> ((((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> (((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (A : mat_Point)) (E : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ==> ((((betS (c : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (D : mat_Point)) (F : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (F : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)) ==> ((((col (c : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> (((((par (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((par (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point))))))))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> ((((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (x : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (x : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (c : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((par (x : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (E : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)))))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((col (E : mat_Point)) (F : mat_Point)) (A0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (A0 : mat_Point))) ==> ((((betS (c : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (A0 : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((cong (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A0 : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (A0 : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (A0 : mat_Point)) ==> ((((col (c : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (A0 : mat_Point)) ==> (((neq (A0 : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> (((((par (A0 : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (A0 : mat_Point)) (E : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (E : mat_Point)) ==> ((((col (A0 : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (F : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (F : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (b : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__Playfair
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (F : mat_Point)) ==> ((((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> ((((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)) ==> (((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (A : mat_Point)) (E : mat_Point))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ==> ((((betS (c : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (D : mat_Point)) (F : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (F : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)) ==> ((((col (c : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> (((((par (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((par (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (F : mat_Point)) (E : mat_Point)))))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> ((((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (x : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (x : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (c : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (c : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((par (x : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (x : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (x : mat_Point)) (E : mat_Point))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((col (E : mat_Point)) (F : mat_Point)) (A0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (C : mat_Point)) (A0 : mat_Point))) ==> ((((betS (c : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> (((((((congA (b : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (b : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((((congA (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (A0 : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((cong (c : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A0 : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((betS (b : mat_Point)) (A0 : mat_Point)) (c : mat_Point)) ==> ((((betS (C : mat_Point)) (Q : mat_Point)) (A0 : mat_Point)) ==> ((((col (c : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> ((((col (c : mat_Point)) (b : mat_Point)) (A0 : mat_Point)) ==> (((neq (A0 : mat_Point)) (b : mat_Point)) ==> (((((par (D : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) ==> (((((par (A0 : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((par (b : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A0 : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)) ==> (((((pG (A0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (A0 : mat_Point)) (E : mat_Point))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (b : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (F : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (c : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (F : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (F : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (b : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (b : mat_Point))) (((col (E : mat_Point)) (b : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (b : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (b : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (b : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (b : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (b : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) (((col (F : mat_Point)) (b : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__Playfair
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((eq (E : mat_Point)) (E : mat_Point)))) ==> (((mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> ((eq (E : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (b : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    proposition__33
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (A : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (b : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (b : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (b : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (A : mat_Point))) (((col (b : mat_Point)) (A : mat_Point)) (c : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or ((eq (A : mat_Point)) (b : mat_Point))) ((mat_or (((betS (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (b : mat_Point))) ((mat_or (((betS (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (c : mat_Point)) (b : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (b : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (R : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (C : mat_Point)) (b : mat_Point))) (((nCol (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (b : mat_Point)) (R : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (R : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))))))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))`
                                                         ))))
                                                   ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))`
                                                   ))))
                                             ) (ASSUME `ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))`
                                             ))))
                                       ) (ASSUME `ex (\ c : mat_Point. (ex (\ b : mat_Point. (ex (\ M : mat_Point. ((mat_and (((betS (c : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (b : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((par (c : mat_Point)) (b : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (b : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (c : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (b : mat_Point))) ((mat_and (((betS (c : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))))))))))))))`
                                       ))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (proposition__31))))
                                         ) (ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                         )
                                        ) (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (nCol__notCol)))
                                           ) (ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                           )))))
                                  ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                       (DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                        (MP  
                                         (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                  (DISCH `(((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                   (MP  
                                                    (DISCH `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                       (ASSUME `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                       )
                                                      ) (ASSUME `(((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                      ))
                                                    ) (MP  
                                                       (CONV_CONV_rule `((((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                        (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                         (MP  
                                                          (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                               (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__ind))))
                                                             ) (GEN `(x : mat_Point)` 
                                                                (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                   ) (
                                                                   GEN `(x0 : mat_Point)` 
                                                                   (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                  ))))
                                                            ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                            ))
                                                          ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                          )))
                                                       ) (ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                       ))))
                                                 ) (MP  
                                                    (SPEC `(A : mat_Point)` 
                                                     (CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point))))))))` 
                                                      (SPEC `\ X : mat_Point. ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (X : mat_Point)))))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__intro))))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                         (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                             (conj))
                                                           ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                           )
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (conj))
                                                              ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                             ))))))
                                               ) (MP  
                                                  (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                       (SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                             (SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                   (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (lemma__collinearorder
                                                        )))
                                                     ) (ASSUME `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                     ))))
                                             ) (MP  
                                                (CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (not__nCol__Col))))
                                                ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (col__nCol__False)))
                                                     ) (ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (MP  
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__collinear4
                                                             ))))
                                                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                         )
                                                        ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                        )
                                                       ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                       ))))))
                                           ) (MP  
                                              (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                   (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                           (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (lemma__betweennotequal))
                                                  )
                                                 ) (ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                 (SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                       (SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                             (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                              (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                              ))
                                            ) (MP  
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (lemma__collinearorder)))
                                               ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                               )))))
                                      ) (MP  
                                         (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                          (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `(mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                             (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                              (or__intror))
                                            ) (MP  
                                               (SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                (SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                 (or__intror))
                                               ) (MP  
                                                  (SPEC `(mat_or (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                   (SPEC `((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                       (or__introl))
                                                     ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                     )))))))))
                                ) (MP  
                                   (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                       (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))))` 
                                        (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                         (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                             (SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))))` 
                                              (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                               (DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))` 
                                                    (SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))` 
                                                          (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                               (SPEC `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                (SPEC `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                  (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(F : mat_Point)` 
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (lemma__NCdistinct)))
                                      ) (ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                      ))))
                              ) (MP  
                                 (DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                     (SPEC `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                      (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                       (DISCH `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                           (SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                            (SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                             (DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                 (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                  (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                   (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                    (ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))`
                                   ))
                                 ) (MP  
                                    (SPEC `(F : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(D : mat_Point)` 
                                        (lemma__parallelNC))))
                                    ) (ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                    ))))
                            ) (MP  
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (axiom__betweennesssymmetry)))
                               ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                               )))))
                      ) (ASSUME `(mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ B : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                ))
              ) (MP  
                 (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` (lemma__extension))))
                  ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)
                 ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)))
            ) (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(D : mat_Point)` (lemma__inequalitysymmetric))
               ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`)))
          ) (MP  
             (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
              (MP  
               (MP  
                (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                 (SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                  (SPEC `(neq (D : mat_Point)) (C : mat_Point)` (and__ind)))
                ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                   (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                    (MP  
                     (MP  
                      (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                       (SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                        (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                         (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                          (MP  
                           (MP  
                            (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                             (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                              (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                               (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                    (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                     (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                            (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                 ))))
                           ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                           ))))
                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                     ))))
               ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
               ))
             ) (MP  
                (SPEC `(E : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(D : mat_Point)` (lemma__NCdistinct)))
                ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                ))))
        ) (MP  
           (DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
               (SPEC `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                 (and__ind)))
              ) (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                 (DISCH `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                     (SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                      (SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                       (DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                           (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                            (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                              (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                              )))
                         ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))`
                   ))))
             ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))`
             ))
           ) (MP  
              (SPEC `(F : mat_Point)` 
               (SPEC `(E : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(D : mat_Point)` (lemma__parallelNC))))
              ) (ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
              ))))))))))
 ;;


(*lemma__midpointunique :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((midpoint A) B) C) ==> ((((midpoint A) D) C) ==> ((eq B) D))))))`*)
let lemma__midpointunique =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((midpoint (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
      (MP  
       (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
        (MP  
         (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
          (MP  
           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((eq (B : mat_Point)) (D : mat_Point))` 
              (DISCH `mat_not (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
               (MP  
                (CONV_CONV_rule `((((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (B : mat_Point)) (D : mat_Point))` 
                 (DISCH `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                  (MP  
                   (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                    (MP  
                     (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                      (MP  
                       (DISCH `(eq (B : mat_Point)) (D : mat_Point)` 
                        (ASSUME `(eq (B : mat_Point)) (D : mat_Point)`)
                       ) (MP  
                          (MP  
                           (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                            (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (axiom__connectivity))))
                                         ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                         )
                                        ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                        )
                                       ) (ASSUME `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                       )
                                      ) (ASSUME `mat_not (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                          )))
                     ) (MP  
                        (MP  
                         (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                          (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                           (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (MP  
                               (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (axiom__betweennesssymmetry)))
                                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    ))))
                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                        )))
                   ) (MP  
                      (MP  
                       (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (axiom__betweennesssymmetry)))
                                  ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                  ))))
                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                      ))))
                ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point))))) ==> mat_false` 
                           (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                (MP  
                                 (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                      (DISCH `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (MP  
                                                (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `mat_false` 
                                                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                             (SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__ind))))
                                                           ) (GEN `(F : mat_Point)` 
                                                              (DISCH `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `mat_false` 
                                                                  (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                          ))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (MP  
                                                                  (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ==> (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                                                   (SPEC `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                  ) (
                                                                  DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                           )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((cong (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                   )))))
                                                             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                 ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (lemma__congruencesymmetric
                                                                 ))))
                                                             ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (lemma__lessthancongruence
                                                                  ))))))
                                                            ) (ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                               )))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (cn__equalityreverse
                                                          )))))
                                                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                             )))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__lessthantransitive
                                                              ))))))
                                                        ) (ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                           ))))
                                     ) (MP  
                                        (SPEC `(B : mat_Point)` 
                                         (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                          (SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__intro))))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                             (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (conj))
                                            ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                            )
                                           ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                           ))))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (cn__congruencereflexive))
                                                 )))
                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((lt (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__lessthancongruence
                                                     ))))))
                                               ) (ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                               )
                                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__congruenceflip))))
                                               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (MP  
                             (SPEC `(D : mat_Point)` 
                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                               (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__intro)))
                              )
                             ) (MP  
                                (MP  
                                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                 )
                                ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                ))))
                        ) (MP  
                           (MP  
                            (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (cn__congruencereflexive)))))
                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                 ))))
                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                           )))
                      ) (MP  
                         (MP  
                          (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                           (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (axiom__innertransitivity))))
                                      ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                      )
                                     ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     ))))
                               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                         )))
                    ) (MP  
                       (MP  
                        (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                          (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                           (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (MP  
                              (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (axiom__betweennesssymmetry)))
                                   ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                   ))))
                             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                       ))))))
             ) (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                      (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                       (MP  
                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                             (MP  
                              (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> mat_false` 
                                 (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `mat_false` 
                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                  (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(E : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `mat_false` 
                                                       (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                     ))))
                                               ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                               ))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                  (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ==> (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                        (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (and__ind))))
                                                       ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                )))
                                           ) (MP  
                                              (MP  
                                               (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__lessthancongruence
                                                                 ))))))
                                                           ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__congruencesymmetric
                                                            ))))
                                                        ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                            )))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__lessthancongruence
                                                             ))))))
                                                       ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      ))))
                                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (cn__equalityreverse))))
                                               )
                                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (lemma__lessthantransitive
                                                         ))))))
                                                   ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                   )
                                                  ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                  ))))
                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (MP  
                                   (SPEC `(D : mat_Point)` 
                                    (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                                     (SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__intro))))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      ))))
                              ) (MP  
                                 (MP  
                                  (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (cn__congruencereflexive)))))
                                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                 )))
                            ) (MP  
                               (MP  
                                (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                          )))
                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                               )))
                          ) (MP  
                             (MP  
                              (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (lemma__lessthancongruence)))
                                             )))
                                          ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                          )
                                         ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                         ))))
                                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                             )))
                        ) (MP  
                           (MP  
                            (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                            (SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (DISCH `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                         ))
                                       ) (MP  
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__congruenceflip))))
                                          ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                          )))))
                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                 ))))
                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                           ))))
                     ) (MP  
                        (SPEC `(B : mat_Point)` 
                         (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                          (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__intro))))
                        ) (MP  
                           (MP  
                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (conj))
                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                            )
                           ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                           ))))
                   ) (MP  
                      (MP  
                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(D : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (axiom__innertransitivity))))
                                   ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                  ))))
                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                      )))
                 ) (MP  
                    (MP  
                     (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                      (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                       (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (MP  
                           (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (axiom__betweennesssymmetry)))
                                ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                ))))
                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                    )))))
           ) (MP  
              (MP  
               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                 (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                  (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(A : mat_Point)` (cn__congruencereflexive)))
                        ))
                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                    ))))
              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
              )))
         ) (MP  
            (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `(((midpoint (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                       (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `(((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                  (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (conj))
                                             ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))
                                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                    )))
                                 ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 ))))
                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                           ))
                         ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                         )))
                      ) (ASSUME `((midpoint (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                      ))))
                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                ))
              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
              ))
            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
            )))
       ) (MP  
          (CONV_CONV_rule `(((midpoint (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
           (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
            (MP  
             (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
              (MP  
               (MP  
                (SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `(((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                      (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                       (MP  
                        (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 )
                                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                ))))
                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                          ))
                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                        )))
                     ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     ))))
               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
               ))
             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))`
             )))
          ) (ASSUME `((midpoint (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
          ))))))))
 ;;


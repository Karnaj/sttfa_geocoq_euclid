(*lemma__layoffunique :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((out A) B) C) ==> ((((out A) B) D) ==> (((((cong A) C) A) D) ==> ((eq C) D)))))))`*)
let lemma__layoffunique =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
       (MP  
        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
           (MP  
            (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
             (MP  
              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (MP  
                (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                       (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`)
                      ) (MP  
                         (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                          (MP  
                           (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                            (MP  
                             (MP  
                              (MP  
                               (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                 (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (or__ind)))
                               ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                    (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                    )
                                   ) (MP  
                                      (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                       (MP  
                                        (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                               (or__ind)))
                                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                         (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                          (MP  
                                                           (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                             (nNPP))
                                                           ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                              (MP  
                                                               (DISCH `mat_false` 
                                                                (MP  
                                                                 (SPEC `mat_false` 
                                                                  (false__ind
                                                                  )
                                                                 ) (ASSUME `mat_false`
                                                                 ))
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                   (ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                   )
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                  ))))))
                                                        ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (C : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                               (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                  (ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                              ) (MP  
                                                                 (DISCH `mat_false` 
                                                                  (MP  
                                                                   (DISCH `mat_false` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))
                                                                   ) (
                                                                   ASSUME `mat_false`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                               )))))
                                                      ) (MP  
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (lemma__congruencesymmetric
                                                             ))))
                                                         ) (ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                            ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                            )
                                                           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (lemma__congruenceflip
                                                            ))))
                                                        ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                        ))))
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__differenceofparts
                                                            ))))))
                                                      ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                     )
                                                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                    )
                                                   ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                   ))))
                                           ) (DISCH `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                    (or__ind)))
                                                 ) (DISCH `(eq (B : mat_Point)) (D : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                        (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                         (MP  
                                                          (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                           (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                            (nNPP))
                                                          ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (MP  
                                                                (SPEC `mat_false` 
                                                                 (false__ind)
                                                                ) (ASSUME `mat_false`
                                                                ))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                  (ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                  )
                                                                 ) (ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                 ))))))
                                                       ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                          (MP  
                                                           (DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (CONV_CONV_rule `((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                              (ASSUME `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                              )
                                                             ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__partnotequalwhole
                                                                 )))
                                                              ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                              )))))
                                                     ) (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((((out (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))))` 
                                                                  (SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                 ) (DISCH `((out (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                              ) (ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                                              )
                                                             ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                             )
                                                            ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                        ))))
                                                ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                       (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                        (MP  
                                                         (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                           (nNPP))
                                                         ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (DISCH `mat_false` 
                                                              (MP  
                                                               (SPEC `mat_false` 
                                                                (false__ind)
                                                               ) (ASSUME `mat_false`
                                                               ))
                                                             ) (MP  
                                                                (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                 (ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                 )
                                                                ) (ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                ))))))
                                                      ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                         (MP  
                                                          (DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                           (MP  
                                                            (CONV_CONV_rule `((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                             (ASSUME `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                             )
                                                            ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (lemma__partnotequalwhole
                                                                )))
                                                             ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                             )))))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__3__6b))))
                                                        ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                       ))))
                                               ) (ASSUME `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                               )))
                                          ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                          ))
                                        ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                        ))
                                      ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                      ))))
                              ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (MP  
                                    (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                       (or__ind)))
                                    ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                             (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (MP  
                                               (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                (MP  
                                                 (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                       (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (or__ind)))
                                                     ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                          (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                             (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                              (nNPP))
                                                            ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                               (MP  
                                                                (DISCH `mat_false` 
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (false__ind
                                                                   )
                                                                  ) (
                                                                  ASSUME `mat_false`
                                                                  ))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                   ) (
                                                                   ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                   ))))))
                                                         ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                              (MP  
                                                               (CONV_CONV_rule `((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                (ASSUME `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                )
                                                               ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__partnotequalwhole
                                                                   )))
                                                                ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                ))))))
                                                    ) (DISCH `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                             (or__ind)))
                                                          ) (DISCH `(eq (B : mat_Point)) (D : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(eq (C : mat_Point)) (B : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((eq (D : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                 (DISCH `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((eq (C : mat_Point)) (D : mat_Point)) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((eq (D : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (D : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (B : mat_Point)))))))) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (y : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ D0 : mat_Point. ((((out (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D0 : mat_Point)) ==> (((((cong (A : mat_Point)) (D0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D0 : mat_Point)) ==> (((((cong (A : mat_Point)) (D0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (D0 : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (D0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((eq (C : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (B : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((eq (y : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (y : mat_Point)) (B : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((out (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (C0 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((eq (C0 : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (C0 : mat_Point)) (B : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (D : mat_Point)) (B : mat_Point)`
                                                                   ))))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `((eq (C : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((eq (C : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point))))))))) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((((cong (B : mat_Point)) (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (y : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((eq (y : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((out (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (C0 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((eq (C0 : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (B : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((eq (D : mat_Point)) (D : mat_Point)) ==> ((eq (D : mat_Point)) (D : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (x : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (x : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((eq (D : mat_Point)) (x : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((eq (B0 : mat_Point)) (B0 : mat_Point)) ==> ((eq (D : mat_Point)) (B0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (C : mat_Point)) (B : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (lemma__equalitysymmetric
                                                                   ))
                                                                 ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                 ))))
                                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                   (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (nNPP))
                                                                  ) (
                                                                  DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                  (MP  
                                                                   (DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                   ) (
                                                                   ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                   ))))))
                                                               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   )))))
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                ))))
                                                        ) (ASSUME `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                        )))
                                                   ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                   ))
                                                 ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                 ))
                                               ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                               )))
                                          ) (MP  
                                             (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_or ((eq (x : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)))))))))))` 
                                                         (SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point))) ((mat_or ((eq (B0 : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)))))))))` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (eq__ind__r))))
                                                        ) (DISCH `((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                             (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                 (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 ))))))))))
                                                     ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )
                                                   ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                   ))
                                                 ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                 )
                                                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                               )
                                              ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                             )))
                                        ) (MP  
                                           (MP  
                                            (MP  
                                             (MP  
                                              (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_or ((eq (x : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))))` 
                                                      (SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point))) ((mat_or ((eq (B0 : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)))) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (eq__ind__r))))
                                                     ) (DISCH `((out (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `((out (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                          (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                            (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                             (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                             )))))))))
                                                  ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 )
                                                ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                ))
                                              ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                              )
                                             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                           ))))
                                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                        (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                        )
                                       ) (MP  
                                          (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                           (MP  
                                            (DISCH `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (MP  
                                                (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                   (or__ind)))
                                                ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                         (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                          (MP  
                                                           (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                             (nNPP))
                                                           ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                              (MP  
                                                               (DISCH `mat_false` 
                                                                (MP  
                                                                 (SPEC `mat_false` 
                                                                  (false__ind
                                                                  )
                                                                 ) (ASSUME `mat_false`
                                                                 ))
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                   (ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                   )
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                  ))))))
                                                        ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (DISCH `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                             (MP  
                                                              (CONV_CONV_rule `((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                               (ASSUME `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                               )
                                                              ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (lemma__partnotequalwhole
                                                                  )))
                                                               ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                               )))))
                                                      ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                      ))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__3__6b))))
                                                        ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       ))))
                                               ) (DISCH `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                        (or__ind)))
                                                     ) (DISCH `(eq (B : mat_Point)) (D : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `(((neq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                            (DISCH `mat_not ((neq (C : mat_Point)) (D : mat_Point))` 
                                                             (MP  
                                                              (CONV_CONV_rule `((mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                                                               (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                (nNPP))
                                                              ) (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                 (MP  
                                                                  (DISCH `mat_false` 
                                                                   (MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                   (ASSUME `mat_not ((neq (C : mat_Point)) (D : mat_Point))`
                                                                   )
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                  ))))))
                                                           ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (DISCH `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                  (ASSUME `mat_not ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                  )
                                                                 ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                         ) (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                  ) (
                                                                  ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                            ))))
                                                    ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                             (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                               )
                                                              ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                              )
                                                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__betweennotequal
                                                                 )))
                                                              ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                              )))))
                                                   ) (ASSUME `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                   )))
                                              ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                              ))
                                            ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                            ))
                                          ) (ASSUME `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                          ))))
                                  ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                  )))
                             ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                             ))
                           ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                           ))
                         ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                         )))
                    ) (SPEC `(C : mat_Point)` 
                       (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
                  ) (SPEC `(B : mat_Point)` 
                     (SPEC `(C : mat_Point)` (cn__congruencereflexive))))
                ) (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` (cn__congruencereflexive))))
              ) (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (lemma__ray1)))
               ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
               )))
          ) (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__ray1)))
             ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )))
        ) (MP  
           (SPEC `(D : mat_Point)` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(A : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__congruencesymmetric))))
           ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
           )))))))))
 ;;


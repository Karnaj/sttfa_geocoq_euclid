(*lemma__Euclid4 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. ((((per A) B) C) ==> ((((per a) b) c) ==> ((((((congA A) B) C) a) b) c))))))))`*)
let lemma__Euclid4 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
        (MP  
         (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
          (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
           (MP  
            (MP  
             (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
               (SPEC `\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(D : mat_Point)` 
                (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                    (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                      (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                          (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                            (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `(((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                     (DISCH `ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))))) ==> (return : bool)))` 
                                          (SPEC `\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(d : mat_Point)` 
                                           (DISCH `(mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))` 
                                                (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                     (SPEC `(mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                      (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                       (DISCH `(mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                           (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                            (SPEC `(((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                             (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ p : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ q : mat_Point. ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ q : mat_Point. ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (q : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ r : mat_Point. ((mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (p : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))) ==> (return : bool))) ==> ((ex (\ r : mat_Point. ((mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ r : mat_Point. ((mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (q : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (x : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (p : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (p : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (r : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (b : mat_Point)) (b : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (q : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (r : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (b : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (F : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (p : mat_Point)) (p : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (q : mat_Point)) (q : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (x : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (p : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (q : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (p : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (q : mat_Point))) (((betS (b : mat_Point)) (q : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (q : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (p : mat_Point))) (((betS (b : mat_Point)) (p : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__10__12
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (r : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (q : mat_Point)) (r : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (b : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (p : mat_Point)) (b : mat_Point))) ==> ((neq (b : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (b : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (E0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (r : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((cong (r : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (r : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (p : mat_Point)) (b : mat_Point))) ((mat_or ((eq (p : mat_Point)) (q : mat_Point))) ((mat_or ((eq (b : mat_Point)) (q : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_or (((betS (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) (((betS (p : mat_Point)) (q : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (p : mat_Point)) (b : mat_Point)) ==> ((((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)) ==> (((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((per (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> ((((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) ==> (((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) ==> (((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)) ==> (((((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) ==> ((((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ==> ((mat_not (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ==> ((((triangle (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((triangle (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> ((((triangle (q : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> (((((((tG (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (b : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (b : mat_Point)) (b : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((per (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> ((((per (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((betS (b : mat_Point)) (b : mat_Point)) (r : mat_Point)) ==> (((((cong (b : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) ==> (((((cong (b : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)) ==> (((((cong (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (r : mat_Point)) ==> ((((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((mat_not (((col (b : mat_Point)) (q : mat_Point)) (b : mat_Point))) ==> ((mat_not (((col (q : mat_Point)) (b : mat_Point)) (b : mat_Point))) ==> ((((triangle (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((triangle (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> ((((triangle (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((col (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (b : mat_Point)) ==> ((((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((per (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((betS (x : mat_Point)) (b : mat_Point)) (r : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)) ==> (((((cong (q : mat_Point)) (x : mat_Point)) (q : mat_Point)) (r : mat_Point)) ==> ((((nCol (x : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((mat_not (((col (b : mat_Point)) (q : mat_Point)) (x : mat_Point))) ==> ((mat_not (((col (q : mat_Point)) (x : mat_Point)) (b : mat_Point))) ==> ((((triangle (x : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((triangle (b : mat_Point)) (q : mat_Point)) (x : mat_Point)) ==> ((((triangle (q : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (x : mat_Point)) (x : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (x : mat_Point)) (q : mat_Point)) (x : mat_Point)) ==> (((((((tG (x : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) (q : mat_Point)) (x : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) (x : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) (q : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (x : mat_Point)) (q : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (x : mat_Point)) (q : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((((tG (b : mat_Point)) (x : mat_Point)) (x : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (q : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (x : mat_Point)) (q : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((nCol (x : mat_Point)) (b : mat_Point)) (q : mat_Point))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ p0 : mat_Point. ((((out (b : mat_Point)) (a : mat_Point)) (p0 : mat_Point)) ==> (((((cong (b : mat_Point)) (p0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((per (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) ==> ((((per (p0 : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((betS (p0 : mat_Point)) (b : mat_Point)) (r : mat_Point)) ==> (((((cong (p0 : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)) ==> (((((cong (p0 : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)) ==> (((((cong (q : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (r : mat_Point)) ==> ((((nCol (p0 : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((mat_not (((col (b : mat_Point)) (q : mat_Point)) (p0 : mat_Point))) ==> ((mat_not (((col (q : mat_Point)) (p0 : mat_Point)) (b : mat_Point))) ==> ((((triangle (p0 : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((triangle (b : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) ==> ((((triangle (q : mat_Point)) (p0 : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (p0 : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) ==> (((((((tG (p0 : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) ==> (((((((tG (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) (b : mat_Point)) ==> (((((((tG (b : mat_Point)) (q : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) ==> (((((((tG (b : mat_Point)) (p0 : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p0 : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) ==> ((((col (p0 : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> (((nCol (p0 : mat_Point)) (b : mat_Point)) (q : mat_Point))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (b : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (q : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (b : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (b : mat_Point)) (q : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (q : mat_Point)) (b : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (b : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (q : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (b : mat_Point)) (b : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (b : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (q : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (b : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (q : mat_Point))) ((mat_or ((eq (b : mat_Point)) (q : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_or (((betS (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) (((betS (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((triangle (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. (((((cong (B : mat_Point)) (E0 : mat_Point)) (b : mat_Point)) (p : mat_Point)) ==> (((((cong (E0 : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> ((((triangle (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((triangle (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    proposition__22
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((tG (p : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (p : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((tG (p : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((tG (p : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__TGflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__TGflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((tG (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__TGflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__TGsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__TGflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((tG (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (p : mat_Point)) (q : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__TGflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((tG (q : mat_Point)) (b : mat_Point)) (b : mat_Point)) (p : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    proposition__20
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    proposition__20
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (b : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    proposition__20
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (q : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (p : mat_Point)) (b : mat_Point))) ((mat_and (((col (p : mat_Point)) (b : mat_Point)) (q : mat_Point))) ((mat_and (((col (b : mat_Point)) (p : mat_Point)) (q : mat_Point))) (((col (p : mat_Point)) (q : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (q : mat_Point)) (p : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((((cong (p : mat_Point)) (q : mat_Point)) (q : mat_Point)) (r : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ r : mat_Point. ((mat_and (((betS (p : mat_Point)) (b : mat_Point)) (r : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (b : mat_Point)) (r : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (q : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (q : mat_Point)) (b : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (q : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (a : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ q : mat_Point. ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ p : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((((cong (b : mat_Point)) (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(d : mat_Point)` 
                                                                   (SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                  ))))))
                                                         ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))`
                                             ))))
                                       ) (ASSUME `ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))))))`
                                       )))
                                    ) (ASSUME `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                  ))))
            ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
            )))
         ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)
        ))))))))
 ;;


(*lemma__ETreflexive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> ((((((eT A) B) C) A) B) C))))`*)
let lemma__ETreflexive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
      (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           )
          ) (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (axiom__congruentequal))))))
             ) (ASSUME `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )))
        ) (MP  
           (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__TCreflexive))))
           ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           ))))
     ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
     )))))
 ;;


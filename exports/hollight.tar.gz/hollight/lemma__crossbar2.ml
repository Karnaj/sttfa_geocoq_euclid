(*lemma__crossbar2 :  |- `! A : mat_Point. (! G : mat_Point. (! H : mat_Point. (! P : mat_Point. (! S : mat_Point. (! T : mat_Point. (((((((ltA H) G) A) H) G) P) ==> (((((oS A) P) G) H) ==> ((((out G) H) S) ==> ((((out G) P) T) ==> (ex (\ X : mat_Point. ((mat_and (((betS T) X) S)) (((out G) A) X)))))))))))))`*)
let lemma__crossbar2 =

 GEN `(A : mat_Point)` 
 (GEN `(G : mat_Point)` 
  (GEN `(H : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (GEN `(S : mat_Point)` 
     (GEN `(T : mat_Point)` 
      (DISCH `(((((ltA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
       (DISCH `(((oS (A : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
        (DISCH `((out (G : mat_Point)) (H : mat_Point)) (S : mat_Point)` 
         (DISCH `((out (G : mat_Point)) (P : mat_Point)) (T : mat_Point)` 
          (MP  
           (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
            (MP  
             (DISCH `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
              (MP  
               (MP  
                (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))) ==> (return : bool)))` 
                  (SPEC `\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(J : mat_Point)` 
                   (DISCH `ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (x : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))) ==> (return : bool)))` 
                        (SPEC `\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(K : mat_Point)` 
                         (DISCH `ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))) ==> (return : bool)))` 
                              (SPEC `\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(L : mat_Point)` 
                               (DISCH `(mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                   (SPEC `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                    (SPEC `((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point)` 
                                     (DISCH `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                         (SPEC `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                          (SPEC `((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                           (DISCH `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                               (SPEC `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                (SPEC `((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point)` 
                                                 (DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                      (DISCH `mat_not (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                       (MP  
                                                        (CONV_CONV_rule `(((nCol (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                         (DISCH `((triangle (L : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((out (G : mat_Point)) (J : mat_Point)) (T : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((out (G : mat_Point)) (L : mat_Point)) (S : mat_Point)` 
                                                              (MP  
                                                               (DISCH `ex (\ M : mat_Point. ((mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (G : mat_Point)) (K : mat_Point)) (x : mat_Point))) (((betS (S : mat_Point)) (x : mat_Point)) (T : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                  ) (
                                                                  GEN `(M : mat_Point)` 
                                                                  (DISCH `(mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (T : mat_Point)) (M : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ N : mat_Point. ((mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (G : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (G : mat_Point)) (M : mat_Point))) ==> (return : bool))) ==> ((ex (\ N : mat_Point. ((mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ N : mat_Point. ((mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H : mat_Point)) (H : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (G : mat_Point)) (H : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (H : mat_Point)) (G : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (T : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (S : mat_Point)) (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (S : mat_Point)) (T : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (H : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (N : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (T : mat_Point)) (x : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (x : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (T : mat_Point)) (X : mat_Point)) (S : mat_Point))) (((out (G : mat_Point)) (A : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (T : mat_Point)) (M : mat_Point)) (S : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (M : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (N : mat_Point)) (M : mat_Point)) ==> (((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (N : mat_Point)) ==> ((((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)) ==> (((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((cong (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) ==> (((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) ==> (((eq (N : mat_Point)) (M : mat_Point)) ==> (((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((cong (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> (((eq (M : mat_Point)) (M : mat_Point)) ==> (((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)))))))))))))) ==> (! y : mat_Point. (((eq (M : mat_Point)) (y : mat_Point)) ==> ((((out (G : mat_Point)) (A : mat_Point)) (y : mat_Point)) ==> (((((cong (G : mat_Point)) (y : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (y : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (y : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (y : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((cong (H : mat_Point)) (y : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (y : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((cong (y : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (y : mat_Point)) (H : mat_Point)) ==> (((((cong (y : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (y : mat_Point)) (G : mat_Point)) ==> (((eq (y : mat_Point)) (M : mat_Point)) ==> (((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ N0 : mat_Point. ((((out (G : mat_Point)) (A : mat_Point)) (N0 : mat_Point)) ==> (((((cong (G : mat_Point)) (N0 : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N0 : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N0 : mat_Point)) ==> (((((((congA (H : mat_Point)) (G : mat_Point)) (N0 : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> (((((cong (H : mat_Point)) (N0 : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (N0 : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((cong (N0 : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (N0 : mat_Point)) (H : mat_Point)) ==> (((((cong (N0 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (N0 : mat_Point)) (G : mat_Point)) ==> (((eq (N0 : mat_Point)) (M : mat_Point)) ==> (((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (H : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (G : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (N : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    lemma__equalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (G : mat_Point)) (H : mat_Point))) ==> (((((cong (M : mat_Point)) (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) ==> (((((cong (M : mat_Point)) (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) ==> (((((oS (M : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((eq (M : mat_Point)) (N : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (G : mat_Point)) (H : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (G : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (H : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (H : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((((cong (H : mat_Point)) (N : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (N : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (M : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (M : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (T : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (S : mat_Point)) (T : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (S : mat_Point))) ((mat_and (((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point))) ((mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point))) ((mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point))) ((mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point))) ((mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (S : mat_Point))) ((mat_and (((col (H : mat_Point)) (S : mat_Point)) (G : mat_Point))) ((mat_and (((col (S : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (S : mat_Point)) (H : mat_Point))) (((col (S : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (H : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (S : mat_Point)) (M : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (T : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (T : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (T : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (T : mat_Point))) ((mat_and ((neq (S : mat_Point)) (M : mat_Point))) ((neq (S : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (M : mat_Point))) ((neq (S : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (M : mat_Point))) ((neq (S : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (S : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (M : mat_Point))) ((neq (S : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (T : mat_Point))) ((mat_and ((neq (S : mat_Point)) (M : mat_Point))) ((neq (S : mat_Point)) (T : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (P : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (N : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B : mat_Point)` 
                                                                    (
                                                                    GEN `(C : mat_Point)` 
                                                                    (
                                                                    GEN `(a : mat_Point)` 
                                                                    (
                                                                    GEN `(b : mat_Point)` 
                                                                    (
                                                                    GEN `(c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (M : mat_Point)) (H : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (H : mat_Point)) (G : mat_Point)) (M : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (L : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (G : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (G : mat_Point))) (((col (M : mat_Point)) (G : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (G : mat_Point)) (H : mat_Point))) ==> (((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (G : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (P : mat_Point))) ((mat_or ((eq (H : mat_Point)) (P : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (P : mat_Point))) (((betS (G : mat_Point)) (P : mat_Point)) (H : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (L : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (L : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (P : mat_Point))) ((mat_or ((eq (H : mat_Point)) (P : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (P : mat_Point))) (((betS (G : mat_Point)) (P : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (H : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ N : mat_Point. ((mat_and (((out (G : mat_Point)) (A : mat_Point)) (N : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (H : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((out (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (S : mat_Point)) (M : mat_Point)) (T : mat_Point))))`
                                                                 ))
                                                               ) (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (L : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((out (G : mat_Point)) (L : mat_Point)) (S : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((out (G : mat_Point)) (J : mat_Point)) (T : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(S : mat_Point)` 
                                                                  (SPEC `(L : mat_Point)` 
                                                                   (SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                 ) (ASSUME `((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((out (G : mat_Point)) (H : mat_Point)) (S : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(T : mat_Point)` 
                                                                (SPEC `(J : mat_Point)` 
                                                                 (SPEC `(P : mat_Point)` 
                                                                  (SPEC `(G : mat_Point)` 
                                                                   (lemma__ray3
                                                                   ))))
                                                               ) (ASSUME `((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point)`
                                                               )
                                                              ) (ASSUME `((out (G : mat_Point)) (P : mat_Point)) (T : mat_Point)`
                                                              ))))
                                                        ) (MP  
                                                           (SPEC `(J : mat_Point)` 
                                                            (SPEC `(G : mat_Point)` 
                                                             (SPEC `(L : mat_Point)` 
                                                              (nCol__notCol))
                                                            )
                                                           ) (ASSUME `mat_not (((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point))`
                                                           ))))
                                                     ) (DISCH `((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((col (G : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((col (G : mat_Point)) (P : mat_Point)) (J : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (G : mat_Point)) (L : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (L : mat_Point)) (G : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((col (G : mat_Point)) (J : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (H : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (P : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (P : mat_Point))) (((col (J : mat_Point)) (P : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (P : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (J : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((col (H : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (J : mat_Point))) (((col (H : mat_Point)) (J : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (J : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((((nCol (G : mat_Point)) (J : mat_Point)) (H : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (J : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                   ) (
                                                                   DISCH `((nCol (G : mat_Point)) (J : mat_Point)) (H : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (J : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (SPEC `(L : mat_Point)` 
                                                                   (SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (H : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((col (L : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (G : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (SPEC `(J : mat_Point)` 
                                                               (SPEC `(P : mat_Point)` 
                                                                (SPEC `(G : mat_Point)` 
                                                                 (lemma__rayimpliescollinear
                                                                 )))
                                                              ) (ASSUME `((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (SPEC `(L : mat_Point)` 
                                                             (SPEC `(H : mat_Point)` 
                                                              (SPEC `(G : mat_Point)` 
                                                               (lemma__rayimpliescollinear
                                                               )))
                                                            ) (ASSUME `((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                            )))))
                                                   ) (MP  
                                                      (SPEC `(K : mat_Point)` 
                                                       (SPEC `(G : mat_Point)` 
                                                        (SPEC `(H : mat_Point)` 
                                                         (nCol__notCol)))
                                                      ) (MP  
                                                         (SPEC `(K : mat_Point)` 
                                                          (SPEC `(G : mat_Point)` 
                                                           (SPEC `(H : mat_Point)` 
                                                            (nCol__not__Col))
                                                          )
                                                         ) (MP  
                                                            (SPEC `(K : mat_Point)` 
                                                             (SPEC `(G : mat_Point)` 
                                                              (SPEC `(H : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(G : mat_Point)` 
                                                                 (SPEC `(H : mat_Point)` 
                                                                  (lemma__equalanglesNC
                                                                  ))))))
                                                            ) (ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                            )))))))
                                             ) (ASSUME `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))`
                                       ))))
                                 ) (ASSUME `(mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))`
                                 ))))
                           ) (ASSUME `ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))`
                           ))))
                     ) (ASSUME `ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))`
                     ))))
               ) (ASSUME `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))`
               ))
             ) (MP  
                (CONV_CONV_rule `((((((ltA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (P : mat_Point)) ==> (ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))))))` 
                 (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))))` 
                  (MP  
                   (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                        (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point)))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(x : mat_Point)` 
                         (DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))` 
                          (MP  
                           (MP  
                            (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                             (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                              (SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point)))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(x0 : mat_Point)` 
                               (DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                                   (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool)))` 
                                    (SPEC `\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(x1 : mat_Point)` 
                                     (DISCH `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                                         (SPEC `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))` 
                                          (SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                           (DISCH `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                                               (SPEC `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))` 
                                                (SPEC `((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point)` 
                                                 (DISCH `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                                                     (SPEC `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)` 
                                                      (SPEC `((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point)` 
                                                       (DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)` 
                                                        (MP  
                                                         (SPEC `(x1 : mat_Point)` 
                                                          (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))) ==> (ex (\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))))` 
                                                           (SPEC `\ J : mat_Point. (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (J : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (J : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__intro))))
                                                         ) (MP  
                                                            (SPEC `(x0 : mat_Point)` 
                                                             (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (x2 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x2 : mat_Point))))))) ==> (ex (\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point))))))))))` 
                                                              (SPEC `\ K : mat_Point. (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (K : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (ex__intro)))
                                                             )
                                                            ) (MP  
                                                               (SPEC `(x : mat_Point)` 
                                                                (CONV_CONV_rule `! x2 : mat_Point. (((mat_and (((betS (x2 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))) ==> (ex (\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))))))` 
                                                                 (SPEC `\ L : mat_Point. ((mat_and (((betS (L : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__intro
                                                                   ))))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)`
                                                                  )))))))))
                                                   ) (ASSUME `(mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (x1 : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))`
                                       ))))
                                 ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (x0 : mat_Point))))))`
                                 ))))
                           ) (ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))`
                           ))))
                     ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))))`
                     ))
                   ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (P : mat_Point)) (V : mat_Point))) ((((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (X : mat_Point))))))))))`
                   )))
                ) (ASSUME `(((((ltA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (H : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                )))
           ) (MP  
              (CONV_CONV_rule `((((oS (A : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))` 
               (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))))` 
                (MP  
                 (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))))` 
                  (MP  
                   (MP  
                    (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))))) ==> (return : bool)))` 
                      (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))))))))` 
                       (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                    ) (GEN `(x : mat_Point)` 
                       (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))` 
                        (MP  
                         (MP  
                          (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                           (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))) ==> (return : bool)))` 
                            (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))))))` 
                             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                          ) (GEN `(x0 : mat_Point)` 
                             (DISCH `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))` 
                              (MP  
                               (MP  
                                (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                 (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))) ==> (return : bool)))` 
                                  (SPEC `\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))))` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))
                                  ))
                                ) (GEN `(x1 : mat_Point)` 
                                   (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                       (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))` 
                                        (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                         (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                             (SPEC `(mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))` 
                                              (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                               (DISCH `(mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                   (SPEC `(mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))` 
                                                    (SPEC `((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                     (DISCH `(mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                         (SPEC `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))` 
                                                          (SPEC `((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                           (DISCH `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                               (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                                (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                 (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)` 
                                                                  (ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point)))))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))`
                                     ))))
                               ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))`
                               ))))
                         ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))`
                         ))))
                   ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))))`
                   ))
                 ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (P : mat_Point))))))))))))`
                 )))
              ) (ASSUME `(((oS (A : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)`
              ))))))))))))
 ;;


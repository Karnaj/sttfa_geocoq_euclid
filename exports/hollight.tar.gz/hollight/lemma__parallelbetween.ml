(*lemma__parallelbetween :  |- `! B : mat_Point. (! H : mat_Point. (! K : mat_Point. (! L : mat_Point. (! M : mat_Point. ((((betS H) B) K) ==> (((((par M) B) H) L) ==> ((((col L) M) K) ==> (((betS L) M) K))))))))`*)
let lemma__parallelbetween =

 GEN `(B : mat_Point)` 
 (GEN `(H : mat_Point)` 
  (GEN `(K : mat_Point)` 
   (GEN `(L : mat_Point)` 
    (GEN `(M : mat_Point)` 
     (DISCH `((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
      (DISCH `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
       (DISCH `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
        (MP  
         (DISCH `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
          (MP  
           (DISCH `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
            (MP  
             (DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
              (MP  
               (DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                  (MP  
                   (DISCH `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                    (MP  
                     (DISCH `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (B : mat_Point))) ((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (B : mat_Point)) (K : mat_Point))) ((mat_or (((betS (B : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point))))))) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                        (DISCH `((col (H : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((eq (M : mat_Point)) (M : mat_Point)) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                           (DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((eq (L : mat_Point)) (L : mat_Point)) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                              (DISCH `(eq (L : mat_Point)) (L : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                 (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((eq (H : mat_Point)) (H : mat_Point)) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                    (DISCH `(eq (H : mat_Point)) (H : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `(((eq (M : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                       (DISCH `mat_not ((eq (M : mat_Point)) (K : mat_Point))` 
                                        (MP  
                                         (DISCH `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((mat_or ((eq (M : mat_Point)) (L : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (L : mat_Point))))))) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                            (DISCH `((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                             (MP  
                                              (DISCH `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                               (MP  
                                                (DISCH `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `(((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                   (DISCH `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))` 
                                                    (MP  
                                                     (DISCH `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                      (ASSUME `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                      )
                                                     ) (MP  
                                                        (DISCH `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))` 
                                                         (MP  
                                                          (DISCH `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))` 
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                               (SPEC `(mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))))` 
                                                                (SPEC `(eq (L : mat_Point)) (M : mat_Point)` 
                                                                 (or__ind)))
                                                              ) (DISCH `(eq (L : mat_Point)) (M : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                   (DISCH `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (L : mat_Point)) (L : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> ((((col (H : mat_Point)) (L : mat_Point)) (L : mat_Point)) ==> (((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (M : mat_Point)) ==> (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (H : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (L : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> ((((col (H : mat_Point)) (L : mat_Point)) (L : mat_Point)) ==> (((col (H : mat_Point)) (L : mat_Point)) (M : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> ((((col (M : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (M : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> (((neq (H : mat_Point)) (M : mat_Point)) ==> ((((nCol (M : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> (((eq (M : mat_Point)) (M : mat_Point)) ==> ((((nCol (M : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (M : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> ((((col (H : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> (((col (H : mat_Point)) (M : mat_Point)) (M : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (x : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> (((neq (H : mat_Point)) (x : mat_Point)) ==> ((((nCol (M : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (x : mat_Point)) (K : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((nCol (M : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (x : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> ((((col (H : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> (((col (H : mat_Point)) (x : mat_Point)) (M : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ L0 : mat_Point. (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L0 : mat_Point)) ==> ((((col (L0 : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L0 : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (L0 : mat_Point)) ==> (((neq (H : mat_Point)) (L0 : mat_Point)) ==> ((((nCol (M : mat_Point)) (L0 : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L0 : mat_Point)) (K : mat_Point)) ==> (((eq (L0 : mat_Point)) (L0 : mat_Point)) ==> ((((nCol (M : mat_Point)) (L0 : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L0 : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L0 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> ((((col (H : mat_Point)) (L0 : mat_Point)) (L0 : mat_Point)) ==> (((col (H : mat_Point)) (L0 : mat_Point)) (M : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (M : mat_Point)) (M : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (L : mat_Point)) (L : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (L : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (L : mat_Point)`
                                                                    ))))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                                                   )))))))
                                                             ) (DISCH `(mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(eq (L : mat_Point)) (K : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (B : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (B : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (B : mat_Point))) (((col (L : mat_Point)) (B : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (B : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> (((col (H : mat_Point)) (B : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (L : mat_Point)) (K : mat_Point)) ==> (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (H : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (L : mat_Point)) (L : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> (((col (H : mat_Point)) (B : mat_Point)) (L : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((col (K : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (K : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> (((neq (H : mat_Point)) (K : mat_Point)) ==> ((((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (K : mat_Point)) (K : mat_Point)) ==> (((eq (K : mat_Point)) (K : mat_Point)) ==> ((((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (K : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (K : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> (((col (H : mat_Point)) (B : mat_Point)) (K : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (K : mat_Point)) ==> (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (x : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> (((neq (H : mat_Point)) (x : mat_Point)) ==> ((((nCol (M : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (x : mat_Point)) (K : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((nCol (M : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (x : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> (((col (H : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ L0 : mat_Point. (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L0 : mat_Point)) ==> ((((col (L0 : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L0 : mat_Point))) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (L0 : mat_Point)) ==> (((neq (H : mat_Point)) (L0 : mat_Point)) ==> ((((nCol (M : mat_Point)) (L0 : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L0 : mat_Point)) (K : mat_Point)) ==> (((eq (L0 : mat_Point)) (L0 : mat_Point)) ==> ((((nCol (M : mat_Point)) (L0 : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L0 : mat_Point)) (M : mat_Point)) ==> ((mat_not (((betS (L0 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> (((col (H : mat_Point)) (B : mat_Point)) (L0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (L : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    ))))))
                                                                  ) (
                                                                  DISCH `(mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (K : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (K : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H : mat_Point)) (x : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (M : mat_Point)) (E : mat_Point))) ((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false) ==> (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (M : mat_Point)) (K : mat_Point))) ((mat_and (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (K : mat_Point)))) ((mat_and (mat_not (((betS (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))) (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (K : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (K : mat_Point)))) (mat_not (((betS (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) (mat_not (((betS (L : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (L : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (M : mat_Point)) (L : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (M : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H : mat_Point)) (x : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or ((eq (M : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (E : mat_Point)) (L : mat_Point)) (H : mat_Point))) ((mat_and (((col (L : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (E : mat_Point))) (((col (L : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (L : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (L : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (H : mat_Point)) (E : mat_Point)) (L : mat_Point))) (((betS (M : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__outer
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (K : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))`
                                                                   )))
                                                                 ) (ASSUME `(mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))))`
                                                                 )))
                                                            ) (ASSUME `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))`
                                                            ))
                                                          ) (ASSUME `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))`
                                                          ))
                                                        ) (ASSUME `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (K : mat_Point))) ((mat_or ((eq (M : mat_Point)) (K : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((betS (L : mat_Point)) (K : mat_Point)) (M : mat_Point))))))`
                                                        ))))
                                                  ) (ASSUME `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                  ))
                                                ) (MP  
                                                   (DISCH `(mat_and (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                       (SPEC `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                        (SPEC `((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                         (DISCH `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                             (SPEC `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                              (SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                               (DISCH `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                   (SPEC `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                  (DISCH `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((nCol (K : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (M : mat_Point)))))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(H : mat_Point)` 
                                                       (SPEC `(K : mat_Point)` 
                                                        (SPEC `(M : mat_Point)` 
                                                         (lemma__NCorder)))
                                                      ) (ASSUME `((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                      ))))
                                              ) (MP  
                                                 (SPEC `(H : mat_Point)` 
                                                  (SPEC `(K : mat_Point)` 
                                                   (SPEC `(M : mat_Point)` 
                                                    (nCol__notCol)))
                                                 ) (MP  
                                                    (SPEC `(H : mat_Point)` 
                                                     (SPEC `(K : mat_Point)` 
                                                      (SPEC `(M : mat_Point)` 
                                                       (nCol__not__Col)))
                                                    ) (MP  
                                                       (CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (K : mat_Point))) ==> (((nCol (M : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(K : mat_Point)` 
                                                            (SPEC `(M : mat_Point)` 
                                                             (SPEC `(H : mat_Point)` 
                                                              (SPEC `(L : mat_Point)` 
                                                               (SPEC `(M : mat_Point)` 
                                                                (lemma__NChelper
                                                                )))))
                                                           ) (ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                           )
                                                          ) (ASSUME `((col (M : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                          )
                                                         ) (ASSUME `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                                         ))
                                                       ) (ASSUME `mat_not ((eq (M : mat_Point)) (K : mat_Point))`
                                                       ))))))
                                           ) (MP  
                                              (SPEC `(mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                                               (SPEC `(eq (M : mat_Point)) (L : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((betS (M : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                                                  (SPEC `(eq (M : mat_Point)) (M : mat_Point)` 
                                                   (or__introl))
                                                 ) (ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (DISCH `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                (SPEC `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))` 
                                                 (SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                  (DISCH `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                      (SPEC `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))` 
                                                       (SPEC `((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                        (DISCH `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                            (SPEC `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                             (SPEC `((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                              (DISCH `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                  (SPEC `((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                   (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))))`
                                              ))
                                            ) (MP  
                                               (SPEC `(L : mat_Point)` 
                                                (SPEC `(H : mat_Point)` 
                                                 (SPEC `(M : mat_Point)` 
                                                  (lemma__NCorder)))
                                               ) (ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                               )))))
                                      ) (DISCH `(eq (M : mat_Point)) (K : mat_Point)` 
                                         (MP  
                                          (DISCH `((col (H : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                           (MP  
                                            (DISCH `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (L : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (L : mat_Point)) (H : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (L : mat_Point))))))) ==> mat_false` 
                                               (DISCH `((col (H : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                  (DISCH `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> mat_false` 
                                                     (ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                     )
                                                    ) (ASSUME `(((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                    )))
                                                 ) (MP  
                                                    (SPEC `(H : mat_Point)` 
                                                     (CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point))))))))` 
                                                      (SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (X : mat_Point)))))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__intro))))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (H : mat_Point)))` 
                                                         (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) (((col (H : mat_Point)) (L : mat_Point)) (H : mat_Point))` 
                                                            (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                             (conj))
                                                           ) (ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                           )
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `((col (H : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                               (SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                (conj))
                                                              ) (ASSUME `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (H : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                             )))))))
                                              ) (MP  
                                                 (SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (L : mat_Point)) (H : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (L : mat_Point)))))` 
                                                  (SPEC `(eq (H : mat_Point)) (L : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `(mat_or ((eq (L : mat_Point)) (H : mat_Point))) ((mat_or (((betS (L : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (L : mat_Point))))` 
                                                     (SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                      (or__introl))
                                                    ) (ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                    ))))
                                            ) (MP  
                                               (DISCH `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                   (SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))))` 
                                                    (SPEC `((col (B : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (B : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                     (DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                         (SPEC `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))` 
                                                          (SPEC `((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                           (DISCH `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                               (SPEC `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                (SPEC `((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((col (M : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (H : mat_Point)))))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(M : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(H : mat_Point)` 
                                                     (lemma__collinearorder))
                                                   )
                                                  ) (ASSUME `((col (H : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (CONV_CONV_rule `((eq (M : mat_Point)) (M : mat_Point)) ==> (((col (H : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (M : mat_Point)) (K : mat_Point)) ==> (((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (M : mat_Point)) (M : mat_Point)) ==> (((col (H : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))))))` 
                                                        (SPEC `(M : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `(((((par (K : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (K : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (K : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (K : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((nCol (K : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (K : mat_Point)) (B : mat_Point)) ==> ((((nCol (K : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (K : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (K : mat_Point)) (K : mat_Point)) ==> (((col (H : mat_Point)) (B : mat_Point)) (K : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (K : mat_Point)) ==> (((((par (x : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (x : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((nCol (x : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((nCol (x : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (x : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> (((col (H : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))` 
                                                           (SPEC `\ M0 : mat_Point. (((((par (M0 : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> ((((col (L : mat_Point)) (M0 : mat_Point)) (K : mat_Point)) ==> ((mat_not ((((meet (M0 : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) ==> ((((nCol (M0 : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((nCol (M0 : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (((neq (M0 : mat_Point)) (B : mat_Point)) ==> ((((nCol (M0 : mat_Point)) (L : mat_Point)) (H : mat_Point)) ==> ((((col (M0 : mat_Point)) (L : mat_Point)) (K : mat_Point)) ==> (((eq (M0 : mat_Point)) (M0 : mat_Point)) ==> (((col (H : mat_Point)) (B : mat_Point)) (M0 : mat_Point)))))))))))` 
                                                            (SPEC `(K : mat_Point)` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (eq__ind__r))))
                                                          ) (DISCH `(((par (K : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                             (DISCH `((col (L : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                              (DISCH `mat_not ((((meet (K : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                               (DISCH `((nCol (K : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                (DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                 (DISCH `(neq (K : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `((nCol (K : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `((col (K : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                                                    )))))))))
                                                          )))
                                                       ) (ASSUME `(eq (M : mat_Point)) (K : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                     )
                                                    ) (ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                    )
                                                   ) (ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                   )
                                                  ) (ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                  )
                                                 ) (ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                )
                                               ) (ASSUME `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                               ))
                                             ) (ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                             ))))))
                                   ) (SPEC `(H : mat_Point)` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (eq__refl)))))
                                ) (SPEC `(B : mat_Point)` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)
                                   ))))
                             ) (SPEC `(L : mat_Point)` 
                                (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                           )
                          ) (SPEC `(M : mat_Point)` 
                             (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                       ) (MP  
                          (SPEC `(mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (B : mat_Point)) (K : mat_Point))) ((mat_or (((betS (B : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point)))))` 
                           (SPEC `(eq (H : mat_Point)) (B : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `(mat_or ((eq (B : mat_Point)) (K : mat_Point))) ((mat_or (((betS (B : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point))))` 
                              (SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(mat_or (((betS (B : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point)))` 
                                 (SPEC `(eq (B : mat_Point)) (K : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or (((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point))` 
                                    (SPEC `((betS (B : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `((betS (H : mat_Point)) (K : mat_Point)) (B : mat_Point)` 
                                       (SPEC `((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `((betS (H : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                      )))))))
                     ) (MP  
                        (DISCH `(mat_and (((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                            (SPEC `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                             (SPEC `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                              (DISCH `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                  (SPEC `(mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                   (SPEC `((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                    (DISCH `(mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                        (SPEC `(mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                         (SPEC `((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                          (DISCH `(mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                              (SPEC `((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                               (SPEC `((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                (DISCH `((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                 (ASSUME `((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (M : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((col (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((col (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (L : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(K : mat_Point)` 
                            (SPEC `(M : mat_Point)` 
                             (SPEC `(L : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                           ))))
                   ) (MP  
                      (DISCH `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                          (SPEC `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))` 
                           (SPEC `((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                            (DISCH `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                (SPEC `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))` 
                                 (SPEC `((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                  (DISCH `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                      (SPEC `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                       (SPEC `((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                        (DISCH `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                            (SPEC `((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                             (SPEC `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                              (DISCH `((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                               (ASSUME `((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and (((nCol (H : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (L : mat_Point)) (H : mat_Point))) (((nCol (L : mat_Point)) (H : mat_Point)) (M : mat_Point)))))`
                        ))
                      ) (MP  
                         (SPEC `(L : mat_Point)` 
                          (SPEC `(H : mat_Point)` 
                           (SPEC `(M : mat_Point)` (lemma__NCorder)))
                         ) (ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                         ))))
                 ) (MP  
                    (DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))))))` 
                     (MP  
                      (MP  
                       (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                        (SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))))` 
                         (SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                          (DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                              (SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))))` 
                               (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                (DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                    (SPEC `(mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))` 
                                     (SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                      (DISCH `(mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                          (SPEC `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))` 
                                           (SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                            (DISCH `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                (SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                 (SPEC `(neq (L : mat_Point)) (H : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (L : mat_Point)) (H : mat_Point)` 
                                                  (DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                   (ASSUME `(neq (H : mat_Point)) (L : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point)))))`
                            ))))
                      ) (ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (H : mat_Point))) ((neq (L : mat_Point)) (M : mat_Point))))))`
                      ))
                    ) (MP  
                       (SPEC `(L : mat_Point)` 
                        (SPEC `(H : mat_Point)` 
                         (SPEC `(M : mat_Point)` (lemma__NCdistinct)))
                       ) (ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                       ))))
               ) (MP  
                  (DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))))))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                      (SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))))` 
                       (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))))` 
                             (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                              (DISCH `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))` 
                                   (SPEC `(neq (M : mat_Point)) (H : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                    (DISCH `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))` 
                                         (SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                          (DISCH `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(neq (H : mat_Point)) (M : mat_Point)` 
                                               (SPEC `(neq (H : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (H : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(neq (H : mat_Point)) (M : mat_Point)` 
                                                 (ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point)))))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((neq (H : mat_Point)) (M : mat_Point))))))`
                    ))
                  ) (MP  
                     (SPEC `(H : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(M : mat_Point)` (lemma__NCdistinct)))
                     ) (ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                     ))))
             ) (MP  
                (DISCH `(mat_and (((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                    (SPEC `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))` 
                     (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                      (DISCH `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                          (SPEC `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))` 
                           (SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                            (DISCH `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)` 
                                 (SPEC `((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                  (DISCH `((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)` 
                                   (ASSUME `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                   )))
                              ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))))`
                  ))
                ) (MP  
                   (SPEC `(L : mat_Point)` 
                    (SPEC `(H : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(M : mat_Point)` (lemma__parallelNC))))
                   ) (ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                   ))))
           ) (MP  
              (DISCH `(mat_and (((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                  (SPEC `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))` 
                   (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                    (DISCH `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))` 
                     (MP  
                      (MP  
                       (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                        (SPEC `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))` 
                         (SPEC `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                          (DISCH `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                              (SPEC `((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)` 
                               (SPEC `((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                (DISCH `((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)` 
                                 (ASSUME `((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                 )))
                            ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point)))`
                      ))))
                ) (ASSUME `(mat_and (((nCol (M : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (M : mat_Point)) (H : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (L : mat_Point))) (((nCol (M : mat_Point)) (B : mat_Point)) (L : mat_Point))))`
                ))
              ) (MP  
                 (SPEC `(L : mat_Point)` 
                  (SPEC `(H : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(M : mat_Point)` (lemma__parallelNC))))
                 ) (ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                 ))))
         ) (MP  
            (CONV_CONV_rule `((((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)) ==> (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))` 
             (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
              (MP  
               (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                (MP  
                 (MP  
                  (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                    (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(x : mat_Point)` 
                     (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                         (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                          (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(x0 : mat_Point)` 
                           (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                            (MP  
                             (MP  
                              (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                               (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x1 : mat_Point)` 
                                 (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                     (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                      (SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(x2 : mat_Point)` 
                                       (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                           (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                            (SPEC `\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__ind))))
                                          ) (GEN `(x3 : mat_Point)` 
                                             (DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                 (SPEC `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                  (SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                       (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                        (SPEC `(neq (H : mat_Point)) (L : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (H : mat_Point)) (L : mat_Point)` 
                                                         (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                             (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                              (SPEC `((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                               (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                   (SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                               ))))
                                         ) (ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                         ))))
                                   ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                   ))))
                             ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                             ))))
                       ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                       ))))
                 ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                 ))
               ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (L : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (u : mat_Point))) ((mat_and (((col (H : mat_Point)) (L : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
               )))
            ) (ASSUME `(((par (M : mat_Point)) (B : mat_Point)) (H : mat_Point)) (L : mat_Point)`
            ))))))))))
 ;;


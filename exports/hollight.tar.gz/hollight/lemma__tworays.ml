(*lemma__tworays :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((out A) B) C) ==> ((((out B) A) C) ==> (((betS A) C) B)))))`*)
let lemma__tworays =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (DISCH `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
     (MP  
      (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
       (MP  
        (DISCH `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
         (MP  
          (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
           (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
           )
          ) (MP  
             (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
              (MP  
               (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                (MP  
                 (MP  
                  (MP  
                   (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                     (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (or__ind)))
                   ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                      ))
                  ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                     (MP  
                      (MP  
                       (MP  
                        (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                           (or__ind)))
                        ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                             (DISCH `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                              (MP  
                               (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                 (nNPP))
                               ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `mat_false` 
                                      (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                       (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                        (or__ind)))
                                     ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                        (MP  
                                         (DISCH `mat_false` 
                                          (MP  
                                           (SPEC `mat_false` (false__ind)
                                           ) (ASSUME `mat_false`))
                                         ) (MP  
                                            (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                             (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                             )
                                            ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                            ))))
                                    ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (MP  
                                          (SPEC `mat_false` 
                                           (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                             (or__ind)))
                                          ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `mat_false` 
                                               (MP  
                                                (SPEC `mat_false` 
                                                 (false__ind)
                                                ) (ASSUME `mat_false`))
                                              ) (MP  
                                                 (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                  (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                  )
                                                 ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                 ))))
                                         ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (DISCH `mat_false` 
                                              (MP  
                                               (SPEC `mat_false` (false__ind)
                                               ) (ASSUME `mat_false`))
                                             ) (MP  
                                                (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                 (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                 )
                                                ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                ))))
                                        ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                        )))
                                   ) (ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                   )))))
                            ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                               (MP  
                                (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                   (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                  ))
                                ) (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (lemma__raystrict)))
                                   ) (ASSUME `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                   ))))))
                       ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                            )
                           ) (MP  
                              (DISCH `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (DISCH `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (MP  
                                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                      (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                       (or__ind)))
                                    ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                       (MP  
                                        (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                         (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                         )
                                        ) (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (axiom__betweennesssymmetry)))
                                           ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                           ))))
                                   ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                            (or__ind)))
                                         ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                              (DISCH `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (nNPP))
                                                ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                   (MP  
                                                    (DISCH `mat_false` 
                                                     (MP  
                                                      (SPEC `mat_false` 
                                                       (false__ind)
                                                      ) (ASSUME `mat_false`))
                                                    ) (MP  
                                                       (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                        (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                        )
                                                       ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                       ))))))
                                             ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                (MP  
                                                 (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                    (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                    )
                                                   ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (lemma__raystrict)))
                                                    ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    ))))))
                                        ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                             (DISCH `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                              (MP  
                                               (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (nNPP))
                                               ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                  (MP  
                                                   (DISCH `mat_false` 
                                                    (MP  
                                                     (SPEC `mat_false` 
                                                      (false__ind)
                                                     ) (ASSUME `mat_false`))
                                                   ) (MP  
                                                      (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                       (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                       )
                                                      ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                      ))))))
                                            ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                               (MP  
                                                (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                 (MP  
                                                  (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                   (MP  
                                                    (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                     (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                     )
                                                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                    ))
                                                  ) (SPEC `(B : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (axiom__betweennessidentity
                                                      ))))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (axiom__innertransitivity
                                                        ))))
                                                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )
                                                   ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                   ))))))
                                       ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                       )))
                                  ) (ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                  ))
                                ) (ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                ))
                              ) (ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                              ))))
                      ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                      )))
                 ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                 ))
               ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
               ))
             ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
             )))
        ) (MP  
           (SPEC `(C : mat_Point)` 
            (SPEC `(A : mat_Point)` (SPEC `(B : mat_Point)` (lemma__ray1)))
           ) (ASSUME `((out (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
           )))
      ) (MP  
         (SPEC `(C : mat_Point)` 
          (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__ray1)))
         ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)
      ))))))
 ;;


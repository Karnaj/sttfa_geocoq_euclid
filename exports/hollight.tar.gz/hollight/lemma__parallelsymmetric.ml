(*lemma__parallelsymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((par A) B) C) D) ==> ((((par C) D) A) B)))))`*)
let lemma__parallelsymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
       (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))` 
        (MP  
         (MP  
          (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (x : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
            (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))))))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(a : mat_Point)` 
             (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))` 
              (MP  
               (MP  
                (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                  (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(b : mat_Point)` 
                   (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (x : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (x : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                        (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(c : mat_Point)` 
                         (DISCH `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (c : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (x : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool)))` 
                              (SPEC `\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(d : mat_Point)` 
                               (DISCH `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool)))` 
                                    (SPEC `\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(m : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))` 
                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))` 
                                                (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))` 
                                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                       (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))` 
                                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))` 
                                                                  (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (c : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (c : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (c : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x : mat_Point)) (X : mat_Point)) (d : mat_Point)))))))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (d : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (d : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (x : mat_Point))) (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point)))))))))))))) ==> (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (a : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (a : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (X : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    DISCH `(((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point))))))))))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))`
                                       ))))
                                 ) (ASSUME `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))`
                                 ))))
                           ) (ASSUME `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))`
                           ))))
                     ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))`
                     ))))
               ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))`
               ))))
         ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (m : mat_Point)) (b : mat_Point)))))))))))))))))))))`
         )))
      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
      ))))))
 ;;


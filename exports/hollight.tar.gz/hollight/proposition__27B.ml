(*proposition__27B :  |- `! A : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((((congA A) E) F) E) F) D) ==> (((((tS A) E) F) D) ==> ((((par A) E) F) D))))))`*)
let proposition__27B =

 GEN `(A : mat_Point)` 
 (GEN `(D : mat_Point)` 
  (GEN `(E : mat_Point)` 
   (GEN `(F : mat_Point)` 
    (DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
     (DISCH `(((tS (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
      (MP  
       (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
        (MP  
         (DISCH `ex (\ B : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
          (MP  
           (MP  
            (SPEC `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ B : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
              (SPEC `\ B : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(B : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                (MP  
                 (MP  
                  (SPEC `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                   (SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                    (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                     (DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                      (MP  
                       (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                          (MP  
                           (DISCH `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                (SPEC `\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(C : mat_Point)` 
                                 (DISCH `(mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                      (SPEC `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                        (MP  
                                         (DISCH `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (F : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))))) ==> ((((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                              (DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> ((((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                         (DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((par (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and ((((par (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                   (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                 ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                 )))))
                                                        ) (MP  
                                                           (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                            (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                               (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                (or__intror))
                                                              ) (MP  
                                                                 (SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                  (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                   (or__intror
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                      ) (MP  
                                                         (DISCH `(mat_and ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                              (SPEC `(((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (DISCH `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and ((((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((par (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(F : mat_Point)` 
                                                                (lemma__parallelflip
                                                                ))))
                                                            ) (ASSUME `(((par (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(F : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__parallelsymmetric
                                                           ))))
                                                       ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__collinearparallel
                                                            )))))
                                                       ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                      )
                                                     ) (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (DISCH `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                       (SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))` 
                                                        (SPEC `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                             (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                              (SPEC `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)))))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(F : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (lemma__collinearorder
                                                         )))
                                                      ) (ASSUME `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                      )))))
                                             ) (MP  
                                                (SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))))` 
                                                 (SPEC `(eq (D : mat_Point)) (F : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                                    (SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or (((betS (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                                       (SPEC `(eq (F : mat_Point)) (C : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `(mat_or (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                          (SPEC `((betS (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `((betS (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                             (SPEC `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                              (or__introl))
                                                            ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                            )))))))
                                           ) (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(F : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (proposition__27))))))
                                                 ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                )
                                               ) (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                               )
                                              ) (ASSUME `(((tS (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                              )))
                                         ) (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(F : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (axiom__betweennesssymmetry)))
                                            ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                            )))))
                                   ) (ASSUME `(mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point))`
                                   ))))
                             ) (ASSUME `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (F : mat_Point)) (D : mat_Point))))`
                             ))
                           ) (MP  
                              (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(F : mat_Point)` 
                                 (SPEC `(F : mat_Point)` 
                                  (SPEC `(D : mat_Point)` (lemma__extension))
                                 ))
                               ) (ASSUME `(neq (D : mat_Point)) (F : mat_Point)`
                               )
                              ) (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(F : mat_Point)` 
                              (lemma__inequalitysymmetric))
                            ) (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                            )))
                       ) (MP  
                          (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                              (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                    (SPEC `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                     (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                           (SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                            (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                         (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
                            ))
                          ) (MP  
                             (SPEC `(D : mat_Point)` 
                              (SPEC `(F : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(F : mat_Point)` 
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (lemma__angledistinct))))))
                             ) (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                             ))))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                 ))))
           ) (ASSUME `ex (\ B : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
           ))
         ) (MP  
            (MP  
             (SPEC `(E : mat_Point)` 
              (SPEC `(A : mat_Point)` 
               (SPEC `(E : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__extension))))
             ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`)
            ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`)))
       ) (MP  
          (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
           (MP  
            (MP  
             (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
              (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` (and__ind)))
             ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                    (SPEC `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                     (SPEC `(neq (E : mat_Point)) (F : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                      (DISCH `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                          (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                           (SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                            (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                (SPEC `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                 (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                  (DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                      (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                         (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                         )))
                                    ) (ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                  ))))
            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
            ))
          ) (MP  
             (SPEC `(D : mat_Point)` 
              (SPEC `(F : mat_Point)` 
               (SPEC `(E : mat_Point)` 
                (SPEC `(F : mat_Point)` 
                 (SPEC `(E : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__angledistinct))))))
             ) (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
             )))))))))
 ;;


(*lemma__erectedperpendicularunique :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! E : mat_Point. ((((per A) B) C) ==> ((((per A) B) E) ==> (((((oS C) E) A) B) ==> (((out B) C) E)))))))`*)
let lemma__erectedperpendicularunique =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(E : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
      (DISCH `(((oS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
         (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
          (MP  
           (MP  
            (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
              (SPEC `\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(D : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                    (MP  
                                     (DISCH `ex (\ H11 : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (H11 : mat_Point))) ((((cong (B : mat_Point)) (H11 : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ H12 : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                          (SPEC `\ H12 : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(H12 : mat_Point)` 
                                           (DISCH `(mat_and (((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                               (SPEC `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)` 
                                                 (DISCH `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                    (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                       (DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((oS (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((per (A : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (H12 : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) ==> (((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((oS (H12 : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H12 : mat_Point)) (D : mat_Point)) (H12 : mat_Point)) ==> (((neq (B : mat_Point)) (H12 : mat_Point)) ==> (((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((oS (H12 : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((cong (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) ==> (((((cong (H12 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) ==> (((((cong (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) ==> (((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H12 : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (x : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (x : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) ==> (((out (B : mat_Point)) (E : mat_Point)) (x : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((oS (C0 : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((oS (C0 : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) ==> (((((cong (C0 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) ==> (((((cong (C0 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) ==> (((out (B : mat_Point)) (E : mat_Point)) (C0 : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(H12 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H12 : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H12 : mat_Point)) (D : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H12 : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H12 : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H12 : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (H12 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) ==> (((((oS (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((eq (C : mat_Point)) (H12 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(H12 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(H12 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H12 : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (H12 : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H12 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H12 : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(H12 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__10__12
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((per (A : mat_Point)) (B : mat_Point)) (H12 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H12 : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(H12 : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                ) (ASSUME `(((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(H12 : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__8__3
                                                                   ))))
                                                               ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                               )
                                                              ) (ASSUME `((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(H12 : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                              ) (ASSUME `(((oS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (ASSUME `((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point)`
                                                            ))))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                          (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                 (or__introl)
                                                                )
                                                               ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                               ))))))
                                                   ) (SPEC `(B : mat_Point)` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (eq__refl))))))
                                             ) (ASSUME `(mat_and (((out (B : mat_Point)) (E : mat_Point)) (H12 : mat_Point))) ((((cong (B : mat_Point)) (H12 : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                             ))))
                                       ) (ASSUME `ex (\ H11 : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (H11 : mat_Point))) ((((cong (B : mat_Point)) (H11 : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                       ))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (lemma__layoff))))
                                         ) (ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                         )
                                        ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                        )))
                                   ) (MP  
                                      (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((neq (B : mat_Point)) (E : mat_Point))` 
                                       (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))))` 
                                        (MP  
                                         (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))))) ==> (return : bool)))` 
                                              (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__ind))))
                                            ) (GEN `(x : mat_Point)` 
                                               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                         (SPEC `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))))`
                                           ))
                                         ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))))))`
                                         )))
                                      ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                 ))))
           ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
           )))
        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
      ))))))
 ;;


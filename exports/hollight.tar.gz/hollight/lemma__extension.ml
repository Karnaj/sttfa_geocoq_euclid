(*lemma__extension :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((neq A) B) ==> (((neq P) Q) ==> (ex (\ X : mat_Point. ((mat_and (((betS A) B) X)) ((((cong B) X) P) Q)))))))))`*)
let lemma__extension =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (GEN `(Q : mat_Point)` 
    (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
     (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
      (MP  
       (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
        (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
         (MP  
          (DISCH `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
           (MP  
            (MP  
             (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))) ==> (return : bool)))` 
               (SPEC `\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(D : mat_Point)` 
                (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                 (MP  
                  (DISCH `(((cong (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                     (MP  
                      (DISCH `ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (return : bool))) ==> ((ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (return : bool)))` 
                           (SPEC `\ J : mat_Circle. ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                            (PINST [(`:mat_Circle`,`:A`)] [] (ex__ind))))
                         ) (GEN `(J : mat_Circle)` 
                            (DISCH `(((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
                               (DISCH `(inCirc (B : mat_Point)) (J : mat_Circle)` 
                                (MP  
                                 (DISCH `ex (\ C : mat_Point. (ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (x : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (x : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. (ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))) ==> (return : bool)))` 
                                      (SPEC `\ C : mat_Point. (ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(C : mat_Point)` 
                                       (DISCH `ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (x : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))) ==> (return : bool)))` 
                                            (SPEC `\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__ind))))
                                          ) (GEN `(E : mat_Point)` 
                                             (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                 (SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                       (SPEC `(mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                         (DISCH `(mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                             (SPEC `(mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                              (SPEC `(onCirc (C : mat_Point)) (J : mat_Circle)` 
                                                               (and__ind)))
                                                            ) (DISCH `(onCirc (C : mat_Point)) (J : mat_Circle)` 
                                                               (DISCH `(mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                                   (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(onCirc (E : mat_Point)) (J : mat_Circle)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(onCirc (E : mat_Point)) (J : mat_Circle)` 
                                                                  (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Circle)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (E : mat_Point)) (J : mat_Circle)`
                                                                    )))))
                                                                 ) (ASSUME `(mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                               ))))
                                         ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))`
                                         ))))
                                   ) (ASSUME `ex (\ C : mat_Point. (ex (\ E : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((onCirc (C : mat_Point)) (J : mat_Circle))) ((mat_and ((onCirc (E : mat_Point)) (J : mat_Circle))) (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))`
                                   ))
                                 ) (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(J : mat_Circle)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (postulate__line__circle))))))
                                      ) (ASSUME `(((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (ASSUME `(inCirc (B : mat_Point)) (J : mat_Circle)`
                                     )
                                    ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                    ))))
                              ) (MP  
                                 (SPEC `(A : mat_Point)` 
                                  (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                   (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (
                                                                    ex__intro
                                                                    ))))
                                 ) (MP  
                                    (SPEC `(A : mat_Point)` 
                                     (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                      (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__intro))))
                                    ) (MP  
                                       (SPEC `(B : mat_Point)` 
                                        (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) (A : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (A : mat_Point)))))))))))))` 
                                         (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (A : mat_Point))))))))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__intro))))
                                       ) (MP  
                                          (SPEC `(B : mat_Point)` 
                                           (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))` 
                                            (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__intro))))
                                          ) (MP  
                                             (SPEC `(D : mat_Point)` 
                                              (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))` 
                                               (SPEC `\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__intro))))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                  (SPEC `(((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (conj))
                                                 ) (ASSUME `(((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                 )
                                                ) (MP  
                                                   (SPEC `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                    (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                     (or__introl))
                                                   ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                   )))))))))))
                        ) (ASSUME `ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                        ))
                      ) (MP  
                         (SPEC `(D : mat_Point)` 
                          (SPEC `(B : mat_Point)` (postulate__Euclid3))
                         ) (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`)))
                    ) (MP  
                       (MP  
                        (SPEC `(D : mat_Point)` 
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(Q : mat_Point)` 
                           (SPEC `(P : mat_Point)` (axiom__nocollapse))))
                        ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`)
                       ) (ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                       )))
                  ) (MP  
                     (SPEC `(Q : mat_Point)` 
                      (SPEC `(D : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(P : mat_Point)` (lemma__congruencesymmetric))
                       ))
                     ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                     )))))
            ) (ASSUME `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))`
            ))
          ) (MP  
             (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
              (MP  
               (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                (MP  
                 (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                  (MP  
                   (MP  
                    (MP  
                     (SPEC `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                      (SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                       (SPEC `(eq (B : mat_Point)) (P : mat_Point)` (or__ind)
                       ))
                     ) (DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                        (MP  
                         (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                          (MP  
                           (DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                              (MP  
                               (DISCH `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((((cong (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (P : mat_Point)) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)))) ==> (return : bool)))` 
                                    (SPEC `\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(D : mat_Point)` 
                                     (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                        (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (CONV_CONV_rule `! x : mat_Point. (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (ex (\ D0 : mat_Point. ((((cong (B : mat_Point)) (D0 : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
                                           (SPEC `\ D0 : mat_Point. ((((cong (B : mat_Point)) (D0 : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__intro))))
                                         ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                         ))
                                       ) (MP  
                                          (DISCH `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                              (SPEC `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                               (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                (DISCH `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                    (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                     (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                      (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                       (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))`
                                            ))
                                          ) (MP  
                                             (SPEC `(P : mat_Point)` 
                                              (SPEC `(Q : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__congruenceflip))))
                                             ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                             ))))))
                                 ) (ASSUME `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                 ))
                               ) (MP  
                                  (MP  
                                   (SPEC `(P : mat_Point)` 
                                    (SPEC `(Q : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (proposition__02)))
                                   ) (ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                   )
                                  ) (ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((neq (Q : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> (((neq (Q : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point)))))` 
                                     (SPEC `(B : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `(((neq (A : mat_Point)) (P : mat_Point)) ==> (((eq (P : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (P : mat_Point)) ==> ((neq (P : mat_Point)) (Q : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> (((neq (Q : mat_Point)) (x : mat_Point)) ==> ((neq (x : mat_Point)) (Q : mat_Point)))))))` 
                                        (SPEC `\ B0 : mat_Point. (((neq (A : mat_Point)) (B0 : mat_Point)) ==> (((eq (B0 : mat_Point)) (B0 : mat_Point)) ==> (((neq (Q : mat_Point)) (B0 : mat_Point)) ==> ((neq (B0 : mat_Point)) (Q : mat_Point)))))` 
                                         (SPEC `(P : mat_Point)` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (eq__ind__r))))
                                       ) (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                          (DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                           (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                            (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                            ))))))
                                    ) (ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                    )
                                   ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                   ))
                                 ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                 )
                                ) (ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                )))
                           ) (MP  
                              (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((neq (Q : mat_Point)) (B : mat_Point))` 
                               (MP  
                                (MP  
                                 (CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((neq (Q : mat_Point)) (B : mat_Point))))` 
                                  (SPEC `(B : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `(((neq (A : mat_Point)) (P : mat_Point)) ==> (((eq (P : mat_Point)) (P : mat_Point)) ==> ((neq (Q : mat_Point)) (P : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((neq (Q : mat_Point)) (x : mat_Point))))))` 
                                     (SPEC `\ B0 : mat_Point. (((neq (A : mat_Point)) (B0 : mat_Point)) ==> (((eq (B0 : mat_Point)) (B0 : mat_Point)) ==> ((neq (Q : mat_Point)) (B0 : mat_Point))))` 
                                      (SPEC `(P : mat_Point)` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (eq__ind__r))))
                                    ) (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                       (DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                        (ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                        )))))
                                 ) (ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                 )
                                ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                ))
                              ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(Q : mat_Point)` 
                             (SPEC `(P : mat_Point)` 
                              (lemma__inequalitysymmetric))
                            ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                            ))))
                    ) (DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                       (MP  
                        (DISCH `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))) ==> (return : bool)))` 
                             (SPEC `\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(D : mat_Point)` 
                              (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                               (MP  
                                (SPEC `(D : mat_Point)` 
                                 (CONV_CONV_rule `! x : mat_Point. (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (ex (\ D0 : mat_Point. ((((cong (B : mat_Point)) (D0 : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
                                  (SPEC `\ D0 : mat_Point. ((((cong (B : mat_Point)) (D0 : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (ex__intro
                                                                   ))))
                                ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                ))))
                          ) (ASSUME `ex (\ D : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)))`
                          ))
                        ) (MP  
                           (MP  
                            (SPEC `(Q : mat_Point)` 
                             (SPEC `(P : mat_Point)` 
                              (SPEC `(B : mat_Point)` (proposition__02)))
                            ) (ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                            )
                           ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`)
                        )))
                   ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))`
                   ))
                 ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))`
                 ))
               ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))`
               ))
             ) (SPEC `(P : mat_Point)` (SPEC `(B : mat_Point)` (eq__or__neq))
             ))))
       ) (SPEC `(B : mat_Point)` (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))
      ))))))
 ;;


(*lemma__21helper :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! E : mat_Point. (((((((tG B) A) A) E) B) E) ==> ((((betS A) E) C) ==> ((((((((tT B) A) A) C) B) E) E) C))))))`*)
let lemma__21helper =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(E : mat_Point)` 
    (DISCH `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
      (MP  
       (CONV_CONV_rule `((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
        (DISCH `ex (\ H1 : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H1 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H1 : mat_Point)))))` 
         (MP  
          (MP  
           (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ H2 : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)))))) ==> (return : bool)))` 
             (SPEC `\ H2 : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point))))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(H2 : mat_Point)` 
              (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)))` 
               (MP  
                (MP  
                 (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                  (SPEC `(mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point))` 
                   (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)` 
                    (DISCH `(mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                        (SPEC `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)` 
                         (SPEC `(((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                          (DISCH `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)` 
                           (MP  
                            (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(((eq (B : mat_Point)) (E : mat_Point)) ==> mat_false) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                               (DISCH `mat_not ((eq (B : mat_Point)) (E : mat_Point))` 
                                (MP  
                                 (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                        (SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                          (ex__ind))))
                                      ) (GEN `(F : mat_Point)` 
                                         (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                               (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (DISCH `ex (\ G : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                        (SPEC `\ G : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (ex__ind))))
                                                      ) (GEN `(G : mat_Point)` 
                                                         (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                               (DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (H2 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point))))) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (H2 : mat_Point))))) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (H2 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (H2 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (H2 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (H2 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (H2 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__lessthanadditive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthanbetween
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (H2 : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (H2 : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (H2 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (H2 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                           ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                     ))
                                                   ) (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (E : mat_Point))) ==> (((neq (E : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__extension
                                                            )))))
                                                       ) (ASSUME `mat_not ((eq (B : mat_Point)) (E : mat_Point))`
                                                       )
                                                      ) (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                         (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                 (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__betweennotequal
                                                          )))
                                                       ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                       ))))))
                                           ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                           ))))
                                     ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                     ))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (lemma__extension))))
                                       ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                       )
                                      ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                      )))
                                 ) (MP  
                                    (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                         (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                 (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                      ))
                                    ) (MP  
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__betweennotequal)))
                                       ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                       )))))
                              ) (DISCH `(eq (B : mat_Point)) (E : mat_Point)` 
                                 (MP  
                                  (DISCH `(((lt (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((((lt (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point)) ==> mat_false` 
                                     (DISCH `ex (\ K : mat_Point. ((mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `mat_false` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                          (SPEC `\ K : mat_Point. ((mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(K : mat_Point)` 
                                           (DISCH `(mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `mat_false` 
                                               (SPEC `(((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                (SPEC `((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point)` 
                                                 (DISCH `(((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `(((neq (B : mat_Point)) (K : mat_Point)) ==> mat_false) ==> mat_false` 
                                                    (DISCH `mat_not ((neq (B : mat_Point)) (K : mat_Point))` 
                                                     (MP  
                                                      (DISCH `((betS (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                           (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                              (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                             )))
                                                          ) (MP  
                                                             (DISCH `mat_false` 
                                                              (MP  
                                                               (DISCH `mat_false` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (eq__refl))
                                                                )
                                                               ) (ASSUME `mat_false`
                                                               ))
                                                             ) (MP  
                                                                (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                   (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                  ))
                                                                ) (SPEC `(B : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                   )))))
                                                        ) (MP  
                                                           (DISCH `(mat_and ((neq (B : mat_Point)) (H2 : mat_Point))) ((mat_and ((neq (B : mat_Point)) (B : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (B : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (B : mat_Point)) (B : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))` 
                                                                (SPEC `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (B : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (B : mat_Point)) (B : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (H2 : mat_Point))) ((mat_and ((neq (B : mat_Point)) (B : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point)))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(H2 : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (lemma__betweennotequal
                                                                 )))
                                                              ) (ASSUME `((betS (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `(((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (K : mat_Point)) ==> (((betS (B : mat_Point)) (x : mat_Point)) (H2 : mat_Point))))` 
                                                            (SPEC `\ X : mat_Point. (((betS (B : mat_Point)) (X : mat_Point)) (H2 : mat_Point))` 
                                                             (SPEC `(K : mat_Point)` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (eq__ind__r)))
                                                            )
                                                           ) (ASSUME `((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point)`
                                                           ))
                                                         ) (MP  
                                                            (CONV_CONV_rule `(mat_not ((neq (B : mat_Point)) (K : mat_Point))) ==> ((eq (B : mat_Point)) (K : mat_Point))` 
                                                             (SPEC `(eq (B : mat_Point)) (K : mat_Point)` 
                                                              (nNPP))
                                                            ) (ASSUME `mat_not ((neq (B : mat_Point)) (K : mat_Point))`
                                                            )))))
                                                   ) (DISCH `(neq (B : mat_Point)) (K : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                          (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                             (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                            )))
                                                         ) (MP  
                                                            (DISCH `mat_false` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__refl)))
                                                              ) (ASSUME `mat_false`
                                                              ))
                                                            ) (MP  
                                                               (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                  (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                 ))
                                                               ) (SPEC `(B : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__refl)
                                                                  )))))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(K : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (axiom__nocollapse
                                                               ))))
                                                           ) (ASSUME `(neq (B : mat_Point)) (K : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                          )))))))
                                             ) (ASSUME `(mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point))`
                                             ))))
                                       ) (ASSUME `ex (\ K : mat_Point. ((mat_and (((betS (B : mat_Point)) (K : mat_Point)) (H2 : mat_Point))) ((((cong (B : mat_Point)) (K : mat_Point)) (B : mat_Point)) (B : mat_Point))))`
                                       )))
                                    ) (ASSUME `(((lt (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point)`
                                    ))
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (MP  
                                        (MP  
                                         (CONV_CONV_rule `((eq (B : mat_Point)) (E : mat_Point)) ==> (((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)) ==> (((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((lt (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H2 : mat_Point))))))` 
                                          (SPEC `(B : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(((((((tG (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (H2 : mat_Point)) ==> (((((lt (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (H2 : mat_Point)) ==> (((neq (E : mat_Point)) (A : mat_Point)) ==> ((((lt (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (H2 : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> (((((((tG (x : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((betS (x : mat_Point)) (A : mat_Point)) (H2 : mat_Point)) ==> (((((lt (x : mat_Point)) (E : mat_Point)) (x : mat_Point)) (H2 : mat_Point)) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((((lt (x : mat_Point)) (x : mat_Point)) (x : mat_Point)) (H2 : mat_Point))))))))` 
                                             (SPEC `\ B0 : mat_Point. (((((((tG (B0 : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> ((((betS (B0 : mat_Point)) (A : mat_Point)) (H2 : mat_Point)) ==> (((((lt (B0 : mat_Point)) (E : mat_Point)) (B0 : mat_Point)) (H2 : mat_Point)) ==> (((neq (B0 : mat_Point)) (A : mat_Point)) ==> ((((lt (B0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (H2 : mat_Point))))))` 
                                              (SPEC `(E : mat_Point)` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (eq__ind__r))))
                                            ) (DISCH `(((((tG (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                               (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (H2 : mat_Point)` 
                                                (DISCH `(((lt (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (H2 : mat_Point)` 
                                                 (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                  (ASSUME `(((lt (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (H2 : mat_Point)`
                                                  )))))))
                                         ) (ASSUME `(eq (B : mat_Point)) (E : mat_Point)`
                                         )
                                        ) (ASSUME `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                        )
                                       ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                       )
                                      ) (ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)`
                                      )
                                     ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                     )))))
                            ) (MP  
                               (DISCH `(mat_and ((neq (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                   (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))` 
                                    (SPEC `(neq (A : mat_Point)) (H2 : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (A : mat_Point)) (H2 : mat_Point)` 
                                     (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                         (SPEC `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                          (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                           (DISCH `(neq (B : mat_Point)) (H2 : mat_Point)` 
                                            (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (H2 : mat_Point)))`
                                 ))
                               ) (MP  
                                  (SPEC `(H2 : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (lemma__betweennotequal)))
                                  ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point)`
                                  ))))))
                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point))`
                      ))))
                ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H2 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H2 : mat_Point)))`
                ))))
          ) (ASSUME `ex (\ H1 : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H1 : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (H1 : mat_Point)))))`
          )))
       ) (ASSUME `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
       )))))))
 ;;


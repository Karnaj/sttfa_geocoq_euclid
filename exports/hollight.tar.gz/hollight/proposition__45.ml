(*proposition__45 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! J : mat_Point. (! K : mat_Point. (! N : mat_Point. (! mat_O : mat_Point. (! R : mat_Point. (! S : mat_Point. ((((nCol J) E) N) ==> ((((nCol A) B) D) ==> ((((nCol C) B) D) ==> ((((betS A) mat_O) C) ==> ((((betS B) mat_O) D) ==> (((neq R) K) ==> ((((nCol K) R) S) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG X) K) Z) U)) ((mat_and ((((((congA X) K) Z) J) E) N)) ((mat_and ((((((((eF X) K) Z) U) A) B) C) D)) ((mat_and (((out K) R) Z)) ((((oS X) S) K) Z))))))))))))))))))))))))))))`*)
let proposition__45 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(J : mat_Point)` 
      (GEN `(K : mat_Point)` 
       (GEN `(N : mat_Point)` 
        (GEN `(mat_O : mat_Point)` 
         (GEN `(R : mat_Point)` 
          (GEN `(S : mat_Point)` 
           (DISCH `((nCol (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
             (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
              (DISCH `((betS (A : mat_Point)) (mat_O : mat_Point)) (C : mat_Point)` 
               (DISCH `((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)` 
                (DISCH `(neq (R : mat_Point)) (K : mat_Point)` 
                 (DISCH `((nCol (K : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                  (MP  
                   (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))` 
                      (MP  
                       (MP  
                        (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                          (SPEC `\ m : mat_Point. ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(m : mat_Point)` 
                           (DISCH `(mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                               (SPEC `(((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                (SPEC `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                 (DISCH `(((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                      (DISCH `((midpoint (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `(neq (B : mat_Point)) (m : mat_Point)` 
                                         (MP  
                                          (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (R : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((((cong (K : mat_Point)) (x : mat_Point)) (B : mat_Point)) (m : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point))))) ==> (return : bool)))` 
                                               (SPEC `\ P : mat_Point. ((mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point)))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(P : mat_Point)` 
                                                (DISCH `(mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                    (SPEC `(((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                     (SPEC `((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point)` 
                                                      (DISCH `(((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                         (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (K : mat_Point)) (P : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(neq (P : mat_Point)) (K : mat_Point)` 
                                                              (MP  
                                                               (DISCH `ex (\ H21 : mat_Point. ((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H21 : mat_Point))) ((((cong (K : mat_Point)) (H21 : mat_Point)) (P : mat_Point)) (K : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((((cong (K : mat_Point)) (x : mat_Point)) (P : mat_Point)) (K : mat_Point))) ==> (return : bool))) ==> ((ex (\ H22 : mat_Point. ((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H22 : mat_Point. ((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                  ) (
                                                                  GEN `(H22 : mat_Point)` 
                                                                  (DISCH `(mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((midpoint (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (H22 : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (K : mat_Point))) ((mat_or ((eq (P : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (K : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) (((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (K : mat_Point))) ((mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (K : mat_Point)) (R : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (K : mat_Point)) (K : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (R : mat_Point)) (K : mat_Point))) ((mat_or ((eq (R : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_or (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H22 : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ G : mat_Point. ((mat_and ((((pG (x : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (x : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (x : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (x : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (x : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. (ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (x : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (x : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (x : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (x : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. (ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. (ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(L : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (J : mat_Point)) (E : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ s : mat_Point. ((mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((((cong (K : mat_Point)) (x : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ==> (return : bool))) ==> ((ex (\ s : mat_Point. ((mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ s : mat_Point. ((mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H22 : mat_Point)) (H22 : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(eq (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (M : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (H22 : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))) (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (K : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (K : mat_Point)) (M : mat_Point))) ((mat_or ((eq (H22 : mat_Point)) (M : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (K : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (M : mat_Point)) (K : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (L : mat_Point)) (F : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (F : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (mat_O : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (mat_O : mat_Point)) (D : mat_Point))) ((mat_or (((betS (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (K : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(((tS (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tS (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ t : mat_Point. ((mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (L : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))) ==> (return : bool))) ==> ((ex (\ t : mat_Point. ((mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ t : mat_Point. ((mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (L : mat_Point)) (t : mat_Point))) ((mat_or ((eq (L : mat_Point)) (F : mat_Point))) ((mat_or ((eq (t : mat_Point)) (F : mat_Point))) ((mat_or (((betS (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_or (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) (((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (t : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (G : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (t : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `mat_not ((neq (t : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (L : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ j : mat_Point. ((mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (x : mat_Point)) (L : mat_Point))) ==> (return : bool))) ==> ((ex (\ j : mat_Point. ((mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ j : mat_Point. ((mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(j : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (K : mat_Point)) (R : mat_Point))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (x : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (x : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (x : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (X : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (X : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (x : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (x : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (x : mat_Point)))))))) ==> (ex (\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (Z : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (Z : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)))))) ==> (ex (\ U : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (U : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (F : mat_Point)) (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((((oS (S : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((oS (F : mat_Point)) (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (x : mat_Point)) (K : mat_Point)) (R : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (K : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (K : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(j : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__paste4
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (mat_O : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ j : mat_Point. ((mat_and (((betS (F : mat_Point)) (j : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (j : mat_Point)) (L : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__diagonalsmeet
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)) ==> (! y : mat_Point. (((eq (t : mat_Point)) (y : mat_Point)) ==> (((betS (L : mat_Point)) (y : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((betS (L : mat_Point)) (X : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (t : mat_Point)) (G : mat_Point))) ==> ((eq (t : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (t : mat_Point)) (G : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (t : mat_Point)) (G : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (t : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))) (((col (H22 : mat_Point)) (L : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (t : mat_Point)) (G : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (t : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point))) ((mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point))) ((mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (G : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (G : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point))) ((mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point))) ((mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (G : mat_Point)) (t : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (t : mat_Point)) (G : mat_Point))) ((mat_and (((col (t : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (H22 : mat_Point))) (((col (t : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point))) ((mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point))) ((mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point))) ((mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point))) ((mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (G : mat_Point)) (t : mat_Point)) (L : mat_Point))) ((mat_and (((col (t : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (t : mat_Point)) (G : mat_Point))) (((col (t : mat_Point)) (G : mat_Point)) (L : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (G : mat_Point)) (t : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (L : mat_Point)) (G : mat_Point)) (t : mat_Point)) ==> mat_false) ==> (((col (L : mat_Point)) (G : mat_Point)) (t : mat_Point))` 
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (L : mat_Point)) (G : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (L : mat_Point)) (G : mat_Point)) (t : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (L : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (L : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (L : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_and (((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (t : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_and (((col (t : mat_Point)) (F : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (t : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (t : mat_Point))) (((col (F : mat_Point)) (t : mat_Point)) (L : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (t : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (F : mat_Point))) ((mat_or ((eq (t : mat_Point)) (F : mat_Point))) ((mat_or (((betS (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_or (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) (((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (t : mat_Point)) (F : mat_Point))) ((mat_or (((betS (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_or (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) (((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (t : mat_Point)) (L : mat_Point)) (F : mat_Point))) ((mat_or (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) (((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (t : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) (((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (t : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (F : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))) ((mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))) (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ t : mat_Point. ((mat_and (((betS (L : mat_Point)) (t : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (t : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((tS (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (K : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (K : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (K : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H22 : mat_Point)) (H22 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)) ==> ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)) ==> ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)))) ((((oS (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (H22 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((par (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((((par (H22 : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_O : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (mat_O : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (mat_O : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (mat_O : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (mat_O : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))) (((col (D : mat_Point)) (mat_O : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (mat_O : mat_Point)) (D : mat_Point))) ((mat_or (((betS (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (mat_O : mat_Point)) (D : mat_Point))) ((mat_or (((betS (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (mat_O : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (mat_O : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (mat_O : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (mat_O : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (F : mat_Point))) (((betS (K : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (H22 : mat_Point))) (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (L : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and ((((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and ((((par (L : mat_Point)) (F : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((((par (F : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (L : mat_Point)) (F : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (L : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (L : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (L : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (L : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (L : mat_Point)) (F : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((neq (M : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (L : mat_Point)) (M : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (L : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and (((col (L : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((mat_and (((col (G : mat_Point)) (F : mat_Point)) (L : mat_Point))) (((col (F : mat_Point)) (L : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (L : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (L : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (L : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__Playfair
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (M : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (M : mat_Point)) (K : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (K : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (L : mat_Point)) (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and ((((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (L : mat_Point)) (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (L : mat_Point)) (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and ((((par (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((((par (L : mat_Point)) (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (L : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))) (((col (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (M : mat_Point))) ((mat_or ((eq (H22 : mat_Point)) (M : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H22 : mat_Point)) (M : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) (((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H22 : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((((par (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((((par (G : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((par (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) (L : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (L : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    proposition__30
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (L : mat_Point)) (M : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (L : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((((par (M : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((((par (L : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (M : mat_Point)) (L : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (L : mat_Point)) (M : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_or (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (L : mat_Point)) (M : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (H22 : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))) (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H22 : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))) (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point))) (((betS (G : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H22 : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H22 : mat_Point)) (H22 : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (L : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (L : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (M : mat_Point)) (L : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (L : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (L : mat_Point)) (M : mat_Point))) ((neq (L : mat_Point)) (H22 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (L : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (M : mat_Point))) ((mat_and ((neq (G : mat_Point)) (M : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (M : mat_Point)) (H22 : mat_Point))) ((neq (M : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((neq (H22 : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__14
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) (((betS (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H22 : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__RTsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((rT (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__RTcongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((rT (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H86 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H86 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H86 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H86 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H86 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H86 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((mat_and (mat_not ((((meet (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)))) ((((oS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (K : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ s : mat_Point. ((mat_and (((betS (H22 : mat_Point)) (K : mat_Point)) (s : mat_Point))) ((((cong (K : mat_Point)) (s : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (H22 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((par (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) ((((par (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (L : mat_Point)) (H22 : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (J : mat_Point)) (E : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (e : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (e : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((midpoint (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) ==> (((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((midpoint (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) ==> (((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (e : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((midpoint (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. (ex (\ L : mat_Point. (ex (\ e : mat_Point. ((mat_and ((((pG (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((((tS (M : mat_Point)) (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__44
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (H22 : mat_Point))) (((nCol (G : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)) ==> ((((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (H22 : mat_Point)) (K : mat_Point)) (F : mat_Point)) (J : mat_Point)) (E : mat_Point)) (N : mat_Point))) ((((oS (S : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    proposition__42B
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (E : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H22 : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H22 : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (H22 : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (H22 : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H22 : mat_Point)) (S : mat_Point)) (K : mat_Point))) (((nCol (S : mat_Point)) (K : mat_Point)) (H22 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H22 : mat_Point)) (K : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H22 : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (H22 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (H22 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (H22 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H22 : mat_Point))) ((mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (H22 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (R : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_or (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_or (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_or (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (R : mat_Point)) (K : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (K : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (S : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((nCol (S : mat_Point)) (R : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (K : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H22 : mat_Point)) (K : mat_Point)) (R : mat_Point))) ((mat_and (((col (H22 : mat_Point)) (R : mat_Point)) (K : mat_Point))) ((mat_and (((col (R : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((mat_and (((col (K : mat_Point)) (R : mat_Point)) (H22 : mat_Point))) (((col (R : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (K : mat_Point)) (H22 : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (K : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (K : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (K : mat_Point)) (R : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (R : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (R : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (H22 : mat_Point))) ((mat_or ((eq (K : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) (((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (K : mat_Point)) (P : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) (((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (P : mat_Point)) (H22 : mat_Point))) ((mat_or (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) (((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) (((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (P : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (H22 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (H22 : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H22 : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H22 : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H22 : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (m : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (H22 : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (K : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (m : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H22 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H22 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H22 : mat_Point))) ((((cong (K : mat_Point)) (H22 : mat_Point)) (P : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `ex (\ H21 : mat_Point. ((mat_and (((betS (P : mat_Point)) (K : mat_Point)) (H21 : mat_Point))) ((((cong (K : mat_Point)) (H21 : mat_Point)) (P : mat_Point)) (K : mat_Point))))`
                                                                 ))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(neq (P : mat_Point)) (K : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(neq (P : mat_Point)) (K : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (SPEC `(P : mat_Point)` 
                                                                 (SPEC `(K : mat_Point)` 
                                                                  (lemma__inequalitysymmetric
                                                                  ))
                                                                ) (ASSUME `(neq (K : mat_Point)) (P : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (K : mat_Point)) (P : mat_Point))) ((mat_and ((neq (R : mat_Point)) (K : mat_Point))) ((neq (R : mat_Point)) (P : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (K : mat_Point)) (P : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (R : mat_Point)) (K : mat_Point))) ((neq (R : mat_Point)) (P : mat_Point))` 
                                                                   (SPEC `(neq (K : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (K : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (K : mat_Point))) ((neq (R : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (K : mat_Point))) ((neq (R : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (K : mat_Point)) (P : mat_Point))) ((mat_and ((neq (R : mat_Point)) (K : mat_Point))) ((neq (R : mat_Point)) (P : mat_Point)))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(P : mat_Point)` 
                                                                  (SPEC `(K : mat_Point)` 
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                 ) (ASSUME `((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point)`
                                                                 )))))
                                                        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point))`
                                                  ))))
                                            ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (R : mat_Point)) (K : mat_Point)) (P : mat_Point))) ((((cong (K : mat_Point)) (P : mat_Point)) (B : mat_Point)) (m : mat_Point))))`
                                            ))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(m : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(K : mat_Point)` 
                                                 (SPEC `(R : mat_Point)` 
                                                  (lemma__extension))))
                                              ) (ASSUME `(neq (R : mat_Point)) (K : mat_Point)`
                                              )
                                             ) (ASSUME `(neq (B : mat_Point)) (m : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and ((neq (m : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                               (SPEC `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                (SPEC `(neq (m : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (m : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                                     (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (B : mat_Point)) (m : mat_Point)` 
                                                       (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                        (ASSUME `(neq (B : mat_Point)) (m : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (m : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(m : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__betweennotequal)))
                                              ) (ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                              )))))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                          (SPEC `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                           (conj))
                                         ) (ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                         )
                                        ) (ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                        )))
                                   ) (MP  
                                      (DISCH `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point))` 
                                           (SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                            (DISCH `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                 (SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                   (ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (D : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (D : mat_Point)) (m : mat_Point)))`
                                        ))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(m : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(m : mat_Point)` 
                                             (lemma__congruenceflip))))
                                         ) (ASSUME `(((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                         ))))))
                             ) (ASSUME `(mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point))`
                             ))))
                       ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))`
                       ))
                     ) (MP  
                        (SPEC `(D : mat_Point)` 
                         (SPEC `(B : mat_Point)` (proposition__10))
                        ) (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`)))
                   ) (MP  
                      (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                          (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                           (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                            (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                             (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                     (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))`
                        ))
                      ) (MP  
                         (SPEC `(D : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(C : mat_Point)` (lemma__NCdistinct)))
                         ) (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                         )))))))))))))))))))))
 ;;


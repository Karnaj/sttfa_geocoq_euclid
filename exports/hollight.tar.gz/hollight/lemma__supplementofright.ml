(*lemma__supplementofright :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. ((((((supp A) B) C) D) F) ==> ((((per A) B) C) ==> ((mat_and (((per F) B) D)) (((per D) B) F))))))))`*)
let lemma__supplementofright =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
      (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
         (MP  
          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))) ==> ((mat_and (((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((per (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
           (DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
            (MP  
             (DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
              (MP  
               (DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `((per (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (DISCH `((per (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                      (MP  
                       (MP  
                        (SPEC `((per (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                         (SPEC `((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                          (conj))
                        ) (ASSUME `((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                        )
                       ) (ASSUME `((per (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                       ))
                     ) (MP  
                        (MP  
                         (SPEC `((per (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                           (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                             (MP  
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(F : mat_Point)` (lemma__8__2)))
                              ) (ASSUME `((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                              ))))
                        ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                        )))
                   ) (MP  
                      (MP  
                       (SPEC `((per (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                         (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `(D : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(F : mat_Point)` (lemma__8__3))))
                             ) (ASSUME `((per (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )
                            ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                            ))))
                      ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                      )))
                 ) (MP  
                    (MP  
                     (SPEC `((per (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                       (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                         (MP  
                          (MP  
                           (MP  
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(F : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (lemma__collinearright))))
                            ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )
                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                           )) (ASSUME `(neq (F : mat_Point)) (B : mat_Point)`
                          ))))
                    ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                    )))
               ) (MP  
                  (MP  
                   (SPEC `(neq (F : mat_Point)) (B : mat_Point)` 
                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                     (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                       (MP  
                        (SPEC `(F : mat_Point)` 
                         (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric)
                         )) (ASSUME `(neq (B : mat_Point)) (F : mat_Point)`))
                      ))
                  ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                  )))
             ) (MP  
                (MP  
                 (SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                   (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                     (MP  
                      (DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                          (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                           (SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                            (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                (SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                   (ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                   )))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))`
                        ))
                      ) (MP  
                         (SPEC `(F : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                         ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                         )))))
                ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                ))))
          ) (MP  
             (MP  
              (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))` 
               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (and__ind)))
              ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                  (MP  
                   (SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror)
                    )
                   ) (MP  
                      (SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                       (SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                        (or__intror))
                      ) (MP  
                         (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                          (SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                             (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                 (or__introl))
                               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                               ))))))))
             ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
             )))
        ) (MP  
           (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
            (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
             (MP  
              (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                   (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                     (MP  
                      (MP  
                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                        (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (conj))
                       ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                       )
                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                      ))))
                ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                ))
              ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
              )))
           ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
           )))))))))
 ;;


(*lemma__lessthanbetween :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (((((lt A) B) A) C) ==> ((((out A) B) C) ==> (((betS A) B) C)))))`*)
let lemma__lessthanbetween =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
    (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
       (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
        (MP  
         (MP  
          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
            (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(M : mat_Point)` 
             (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
              (MP  
               (MP  
                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                   (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                      (MP  
                       (DISCH `((out (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (DISCH `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                          (MP  
                           (DISCH `((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(eq (M : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )
                               ) (MP  
                                  (MP  
                                   (MP  
                                    (MP  
                                     (MP  
                                      (MP  
                                       (CONV_CONV_rule `((eq (M : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (M : mat_Point)) ==> ((((out (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                        (SPEC `(M : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                           (SPEC `\ M0 : mat_Point. ((((betS (A : mat_Point)) (M0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (M0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (M0 : mat_Point)) ==> ((((out (A : mat_Point)) (M0 : mat_Point)) (C : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (M0 : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                            (SPEC `(B : mat_Point)` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (eq__ind__r))))
                                          ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 ))))))))
                                       ) (ASSUME `(eq (M : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                      )
                                     ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                     )
                                    ) (ASSUME `(neq (A : mat_Point)) (M : mat_Point)`
                                    )
                                   ) (ASSUME `((out (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (ASSUME `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (MP  
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(M : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__layoffunique))))
                                  ) (ASSUME `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                  )
                                 ) (ASSUME `((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                 )
                                ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                )))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` (lemma__ray5)))
                              ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(M : mat_Point)` 
                              (SPEC `(A : mat_Point)` (lemma__ray5)))
                            ) (ASSUME `((out (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(M : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__ray4)))
                           ) (MP  
                              (SPEC `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                               (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                   (or__intror))
                                 ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                 )))
                          ) (ASSUME `(neq (A : mat_Point)) (M : mat_Point)`))
                      )
                     ) (MP  
                        (DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                            (SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                             (SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                    (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                     (ASSUME `(neq (A : mat_Point)) (M : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                          ))
                        ) (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(M : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__betweennotequal)
                             ))
                           ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                           ))))))
               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))`
               ))))
         ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
         )))
      ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
      ))))))
 ;;


(*lemma__ray5 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((out A) B) C) ==> (((out A) C) B))))`*)
let lemma__ray5 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
      (MP  
       (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
          (ASSUME `((out (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`)
         ) (MP  
            (MP  
             (SPEC `(B : mat_Point)` 
              (SPEC `(C : mat_Point)` (SPEC `(A : mat_Point)` (lemma__ray4)))
             ) (MP  
                (MP  
                 (MP  
                  (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                     (or__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                     (MP  
                      (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (or__intror))
                      ) (MP  
                         (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                          (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                           (or__intror))
                         ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                         ))))
                 ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                    (MP  
                     (MP  
                      (MP  
                       (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                          (or__ind)))
                       ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (or__intror))
                           ) (MP  
                              (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                               (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                (or__introl))
                              ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                              ))))
                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (or__introl))
                          ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                          )))
                     ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                     )))
                ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                ))
            ) (MP  
               (MP  
                (MP  
                 (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                  (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                   (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                    (or__ind)))
                 ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                    (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`))
                ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                   (MP  
                    (MP  
                     (MP  
                      (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                         (or__ind)))
                      ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                         (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`))
                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`))
                    ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                    )))
               ) (ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
               ))))
       ) (MP  
          (SPEC `(C : mat_Point)` 
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (lemma__raystrict)))
          ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          )))
     ) (MP  
        (SPEC `(C : mat_Point)` 
         (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__ray1)))
        ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
    ))))
 ;;


(*proposition__11 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((betS A) C) B) ==> (ex (\ X : mat_Point. (((per A) C) X))))))`*)
let proposition__11 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
    (MP  
     (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
      (MP  
       (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
        (MP  
         (MP  
          (SPEC `ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
            (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(E : mat_Point)` 
             (DISCH `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
              (MP  
               (MP  
                (SPEC `ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))` 
                 (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                      (MP  
                       (DISCH `ex (\ F : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                        (MP  
                         (MP  
                          (SPEC `ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))` 
                           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (x : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                            (SPEC `\ F : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                          ) (GEN `(F : mat_Point)` 
                             (DISCH `(mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))` 
                                 (SPEC `((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                  (SPEC `((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                   (DISCH `((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(((eq (C : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
                                            (DISCH `mat_not ((eq (C : mat_Point)) (F : mat_Point))` 
                                             (MP  
                                              (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))))))) ==> (ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
                                                   (DISCH `((per (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                    (MP  
                                                     (SPEC `(F : mat_Point)` 
                                                      (CONV_CONV_rule `! x : mat_Point. ((((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (ex (\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                       (SPEC `\ X : mat_Point. (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__intro))))
                                                     ) (ASSUME `((per (A : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                     )))
                                                  ) (MP  
                                                     (SPEC `(E : mat_Point)` 
                                                      (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))))))))` 
                                                       (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__intro))))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))` 
                                                          (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                           (conj))
                                                         ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                         )
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                             (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                              (conj))
                                                            ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (MP  
                                                              (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (F : mat_Point))) ==> ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))` 
                                                               (MP  
                                                                (SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                  (conj))
                                                                ) (ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                ))
                                                              ) (ASSUME `mat_not ((eq (C : mat_Point)) (F : mat_Point))`
                                                              ))))))
                                                ) (MP  
                                                   (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                        (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                              (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(E : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (lemma__congruenceflip
                                                          ))))
                                                      ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                      ))))
                                              ) (MP  
                                                 (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (lemma__doublereverse
                                                        ))))
                                                    ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                    )))))
                                           ) (DISCH `(eq (C : mat_Point)) (F : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `(((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                       (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (col__nCol__False
                                                             )))
                                                          ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                          )
                                                         ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                         )))
                                                      ) (ASSUME `((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                      ))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                           (SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                            (SPEC `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                             (DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(F : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (CONV_CONV_rule `((eq (C : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))))))` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))))))))` 
                                                              (SPEC `\ C0 : mat_Point. ((((betS (A : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (C0 : mat_Point)) ==> ((((betS (A : mat_Point)) (C0 : mat_Point)) (E : mat_Point)) ==> (((((cong (C0 : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((col (A : mat_Point)) (C0 : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)))))))` 
                                                               (SPEC `(F : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__ind__r)
                                                                )))
                                                             ) (DISCH `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                (DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                 (DISCH `((betS (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                  (DISCH `(((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                   (DISCH `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                          ) (ASSUME `(eq (C : mat_Point)) (F : mat_Point)`
                                                          )
                                                         ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )
                                                        ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                     ))))
                                               ) (MP  
                                                  (SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                      (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                         (SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                            (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                              )))))))))
                                         ) (MP  
                                            (DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                 (SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                       (SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                        (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                         (ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(F : mat_Point)` 
                                                 (SPEC `(F : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__congruenceflip))))
                                               ) (ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (DISCH `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                              (SPEC `(((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                               (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                (DISCH `(((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                 (ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                            ))
                                          ) (MP  
                                             (SPEC `(A : mat_Point)` 
                                              (SPEC `(F : mat_Point)` 
                                               (SPEC `(F : mat_Point)` 
                                                (SPEC `(E : mat_Point)` 
                                                 (lemma__doublereverse))))
                                             ) (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                             ))))
                                     ) (MP  
                                        (CONV_CONV_rule `(((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                           (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                            (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                             (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                              (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                              ))))
                                        ) (ASSUME `((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                        )))))
                               ) (ASSUME `(mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                               ))))
                         ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((triangle (A : mat_Point)) (E : mat_Point)) (F : mat_Point))))`
                         ))
                       ) (MP  
                          (SPEC `(E : mat_Point)` 
                           (SPEC `(A : mat_Point)` (proposition__01))
                          ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`))
                      )
                     ) (MP  
                        (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                            (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                             (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                              (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                  (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                     (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                          ))
                        ) (MP  
                           (SPEC `(E : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__betweennotequal)
                             ))
                           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                           ))))))
               ) (ASSUME `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
               ))))
         ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
         ))
       ) (MP  
          (MP  
           (SPEC `(C : mat_Point)` 
            (SPEC `(A : mat_Point)` 
             (SPEC `(C : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__extension))))
           ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)
          ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)))
     ) (MP  
        (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
         (MP  
          (MP  
           (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
            (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
             (SPEC `(neq (C : mat_Point)) (B : mat_Point)` (and__ind)))
           ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
              (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` (and__ind)))
                 ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                    (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                     (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)))
                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                ))))
          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
          ))
        ) (MP  
           (SPEC `(B : mat_Point)` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
           )))))))
 ;;


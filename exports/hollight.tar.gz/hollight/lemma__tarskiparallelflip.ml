(*lemma__tarskiparallelflip :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((tP A) B) C) D) ==> ((mat_and ((((tP B) A) C) D)) ((mat_and ((((tP A) B) D) C)) ((((tP B) A) D) C)))))))`*)
let lemma__tarskiparallelflip =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
       (MP  
        (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
         (MP  
          (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
           (MP  
            (CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
             (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
              (MP  
               (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `(((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                   (DISCH `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                    (MP  
                     (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                      (MP  
                       (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                          (MP  
                           (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                              (DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `(((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                 (DISCH `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> ((mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                    (DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))) ==> (return : bool)))` 
                                           (SPEC `\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__ind))))
                                         ) (GEN `(P : mat_Point)` 
                                            (DISCH `ex (\ P0 : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ P0 : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool)))` 
                                                 (SPEC `\ P0 : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__ind))))
                                               ) (GEN `(Q : mat_Point)` 
                                                  (DISCH `ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (return : bool)))` 
                                                       (SPEC `\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__ind))))
                                                     ) (GEN `(R : mat_Point)` 
                                                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                            (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                  (SPEC `(mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))`
                                                          ))))
                                                    ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))`
                                                    ))))
                                              ) (ASSUME `ex (\ P0 : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))`
                                              ))))
                                        ) (ASSUME `ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))`
                                        ))
                                      ) (MP  
                                         (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                          (MP  
                                           (SPEC `ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                            (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))` 
                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                  (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `ex (\ Q : mat_Point. (ex (\ P : mat_Point. (ex (\ R : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((betS (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (D : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                        (SPEC `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                         (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                          (and__ind)))
                                                       ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                          (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                           (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))`
                                                           )))
                                                      ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))`
                                                )))))
                                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                         ))))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                        (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                           (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                            (conj))
                                          ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                          )
                                         ) (MP  
                                            (MP  
                                             (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                              (SPEC `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                               (conj))
                                             ) (ASSUME `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                             )
                                            ) (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                            ))))))
                                ) (DISCH `(((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `mat_false` 
                                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))) ==> (return : bool)))` 
                                         (SPEC `\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__ind))))
                                       ) (GEN `(T : mat_Point)` 
                                          (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `mat_false` 
                                              (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))` 
                                               (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `mat_false` 
                                                    (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))` 
                                                     (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `mat_false` 
                                                          (SPEC `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                           (SPEC `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)` 
                                                            (DISCH `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `mat_false` 
                                                                (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))`
                                            ))))
                                      ) (ASSUME `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))`
                                      ))
                                    ) (MP  
                                       (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))))))` 
                                        (MP  
                                         (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                                          (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                                                (SPEC `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `((mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))) ==> (((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ==> (((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))))` 
                                                      (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                                                       (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                                         (and__ind))))
                                                     ) (DISCH `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                                        (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                         (ASSUME `(((meet (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                              )))))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                       ))))))
                             ) (MP  
                                (MP  
                                 (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                  (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                        (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                         (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                              (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                (and__ind)))
                                             ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                   )
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                        (conj))
                                                      ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                      )
                                                     ) (MP  
                                                        (MP  
                                                         (CONV_CONV_rule `(((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_and (mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                          (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (SPEC `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                            (conj)))
                                                         ) (DISCH `(((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `mat_false` 
                                                              (MP  
                                                               (SPEC `mat_false` 
                                                                (false__ind)
                                                               ) (ASSUME `mat_false`
                                                               ))
                                                             ) (MP  
                                                                (CONV_CONV_rule `((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                 (ASSUME `mat_not ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                 )
                                                                ) (ASSUME `(((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                ))))
                                                        ) (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                        ))))))
                                            ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                      (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                            (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                              (and__ind)))
                                           ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                              (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                     (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__samesidesymmetric
                                                       ))))
                                                   ) (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                   )))))
                                          ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                              )))
                         ) (MP  
                            (MP  
                             (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                            (and__ind)))
                                         ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                            (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (MP  
                                              (DISCH `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                   (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__samesidesymmetric
                                                     ))))
                                                 ) (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                 )))))
                                        ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                          (and__ind)))
                                       ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                          (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (DISCH `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                 (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__samesidesymmetric)
                                                  )))
                                               ) (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                          )))
                     ) (MP  
                        (MP  
                         (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                          (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                            (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                      (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                       (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                        (and__ind)))
                                     ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                        (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (MP  
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__inequalitysymmetric))
                                          ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                          ))))
                                    ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                        ))))
                  ) (DISCH `(((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (MP  
                      (DISCH `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))` 
                       (MP  
                        (MP  
                         (SPEC `mat_false` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))) ==> (return : bool)))` 
                           (SPEC `\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(T : mat_Point)` 
                            (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `mat_false` 
                                (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))` 
                                 (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `mat_false` 
                                      (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))` 
                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `mat_false` 
                                            (SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                             (SPEC `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)` 
                                              (DISCH `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `mat_false` 
                                                  (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `mat_false` 
                                                        (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                         (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `mat_false` 
                                                              (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (and__ind)))
                                                             ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    ))))))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((mat_and (((col (A : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((col (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (T : mat_Point)) (A : mat_Point))) (((col (T : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(T : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point)`
                                                                  ))))))
                                                            ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))`
                              ))))
                        ) (ASSUME `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))`
                        ))
                      ) (MP  
                         (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))))))` 
                          (MP  
                           (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))` 
                            (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))` 
                                  (SPEC `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (CONV_CONV_rule `((mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))) ==> (((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ==> (((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))))` 
                                        (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))))))` 
                                         (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                           (and__ind))))
                                       ) (DISCH `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                          (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (ASSUME `(((meet (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                )))))
                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                         ))))))
               ) (MP  
                  (MP  
                   (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                    (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                          (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                           (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                  (and__ind)))
                               ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                  (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (conj))
                                     ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                     )
                                    ) (MP  
                                       (MP  
                                        (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                         (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                          (conj))
                                        ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                            (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                              (conj)))
                                           ) (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (MP  
                                               (DISCH `mat_false` 
                                                (MP  
                                                 (SPEC `mat_false` 
                                                  (false__ind)
                                                 ) (ASSUME `mat_false`))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                   (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                   )
                                                  ) (ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                  ))))
                                          ) (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                          ))))))
                              ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                  ))))
            ) (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
               (MP  
                (DISCH `ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `mat_false` 
                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))) ==> (return : bool)))` 
                     (SPEC `\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))))` 
                      (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                   ) (GEN `(T : mat_Point)` 
                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `mat_false` 
                          (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))` 
                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                            (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `mat_false` 
                                (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))` 
                                 (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `mat_false` 
                                      (SPEC `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                        (DISCH `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `mat_false` 
                                            (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `mat_false` 
                                                  (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `mat_false` 
                                                        (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                          (and__ind)))
                                                       ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                          (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                 (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   )))
                                                                ) (MP  
                                                                   (SPEC `(T : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                   ))))))
                                                              ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                              ))
                                                            ) (MP  
                                                               (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (T : mat_Point))) ((mat_and (((col (C : mat_Point)) (T : mat_Point)) (D : mat_Point))) ((mat_and (((col (T : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (T : mat_Point)) (C : mat_Point))) (((col (T : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(T : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)`
                                                                  ))))))
                                                      ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))`
                        ))))
                  ) (ASSUME `ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))`
                  ))
                ) (MP  
                   (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point)))))))` 
                    (MP  
                     (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                      (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                            (SPEC `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                             (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                               (MP  
                                (MP  
                                 (CONV_CONV_rule `((mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))) ==> (((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))) ==> (((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))))` 
                                  (SPEC `ex (\ T : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (T : mat_Point))))))` 
                                   (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                     (and__ind))))
                                 ) (DISCH `mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))` 
                                    (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                     (ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                          )))))
                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                   )))))
          ) (MP  
             (MP  
              (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
               (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
              ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                 (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                     (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                       (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                           (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                            (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                             (and__ind)))
                          ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                             (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (lemma__inequalitysymmetric))
                               ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                               ))))
                         ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                   ))))
             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
             )))
        ) (MP  
           (MP  
            (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
             (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
               (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                (MP  
                 (MP  
                  (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                    (SPEC `(neq (C : mat_Point)) (D : mat_Point)` (and__ind))
                   )
                  ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                      (MP  
                       (MP  
                        (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                           (and__ind)))
                        ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                           (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                              (MP  
                               (MP  
                                (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (SPEC `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                  (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (DISCH `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                          (ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                          )))
                                     ) (ASSUME `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                               ))
                             ) (MP  
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (lemma__samesidesymmetric))))
                                ) (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                )))))
                       ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                       ))))
                 ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                 ))))
           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
           (MP  
            (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                      (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                            (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                              (and__ind)))
                           ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                              (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                 )
                                ) (MP  
                                   (MP  
                                    (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (conj))
                                    ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                    )
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                         (conj))
                                       ) (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                       )
                                      ) (ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                      ))))))
                          ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                    ))))
              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
              ))
            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
            )))
         ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


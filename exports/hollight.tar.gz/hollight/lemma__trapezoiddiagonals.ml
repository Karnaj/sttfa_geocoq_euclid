(*lemma__trapezoiddiagonals :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((((pG A) B) C) D) ==> ((((betS A) E) D) ==> (ex (\ X : mat_Point. ((mat_and (((betS B) X) D)) (((betS C) X) E))))))))))`*)
let lemma__trapezoiddiagonals =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
       (MP  
        (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
             (MP  
              (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
               (MP  
                (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                 (MP  
                  (DISCH `ex (\ M : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((midpoint (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                       (SPEC `\ M : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(M : mat_Point)` 
                        (DISCH `(mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                            (SPEC `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                             (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                              (DISCH `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                               (MP  
                                (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point)))))` 
                                           (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point)))))` 
                                              (DISCH `mat_not (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                                                       (SPEC `\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__ind))))
                                                     ) (GEN `(P : mat_Point)` 
                                                        (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                                                            (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                             (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                              (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point)))))` 
                                                                 (DISCH `mat_not (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                  (MP  
                                                                   (DISCH `ex (\ H' : mat_Point. ((mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ H' : mat_Point. ((mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H' : mat_Point. ((mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H' : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H' : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H' : mat_Point. ((mat_and (((betS (B : mat_Point)) (H' : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (H' : mat_Point)) (E : mat_Point))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                   ) (
                                                                   ASSUME `mat_not (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                   )))))
                                                                ) (DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (P : mat_Point))) ((mat_or ((eq (D : mat_Point)) (P : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (P : mat_Point))) ((mat_or ((eq (D : mat_Point)) (P : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (P : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)`
                                                                    ))))))))
                                                          ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (P : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))`
                                                    ))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(M : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (postulate__Euclid5
                                                                ))))))
                                                          ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                          )
                                                         ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (nCol__notCol)))
                                                        ) (ASSUME `mat_not (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                        ))))
                                                ) (MP  
                                                   (DISCH `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                        (SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                              (SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                (ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(M : mat_Point)` 
                                                        (SPEC `(M : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__congruenceflip
                                                          ))))
                                                      ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                      )))))
                                             ) (DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                    (DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                       (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                          (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                          )
                                                         ) (ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         )))
                                                      ) (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                           (SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__intro))))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                               (conj))
                                                             ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (conj))
                                                                ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                  )))))))
                                                   ) (MP  
                                                      (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                          (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                             (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                              (or__introl))
                                                            ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                            )))))
                                                 ) (MP  
                                                    (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                         (SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                               (SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (lemma__collinearorder
                                                          )))
                                                       ) (ASSUME `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                       )))))))
                                          ) (SPEC `(B : mat_Point)` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (eq__refl))))
                                        ) (MP  
                                           (DISCH `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                (SPEC `(((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                     (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                      (SPEC `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                        (ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(M : mat_Point)` 
                                                (SPEC `(M : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (lemma__congruenceflip))))
                                              ) (ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (CONV_CONV_rule `(((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                          (MP  
                                           (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                             (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `(((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                 (MP  
                                                  (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                      (ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                      ))))
                                                ) (ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                )))))
                                         ) (ASSUME `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                         )))
                                    ) (MP  
                                       (CONV_CONV_rule `(((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                        (MP  
                                         (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                           (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                               (MP  
                                                (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                    (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                    ))))
                                              ) (ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                              )))))
                                       ) (ASSUME `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                       )))
                                  ) (MP  
                                     (CONV_CONV_rule `(((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                      (MP  
                                       (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                         (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                             (MP  
                                              (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                  (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                  ))))
                                            ) (ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                            )))))
                                     ) (ASSUME `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                     )))
                                ) (MP  
                                   (CONV_CONV_rule `(((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                    (MP  
                                     (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                       (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                ))))
                                          ) (ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                          )))))
                                   ) (ASSUME `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                   )))))
                          ) (ASSUME `(mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                          ))))
                    ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
                    ))
                  ) (MP  
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (lemma__diagonalsbisect))))
                     ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                     )))
                ) (MP  
                   (CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point))` 
                    (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                     (MP  
                      (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                           (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(x : mat_Point)` 
                            (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                 (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)))
                                )
                               ) (GEN `(x0 : mat_Point)` 
                                  (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                       (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (ex__ind))))
                                     ) (GEN `(x1 : mat_Point)` 
                                        (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                            (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                             (SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (ex__ind))))
                                           ) (GEN `(x2 : mat_Point)` 
                                              (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                  (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                   (SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (ex__ind))))
                                                 ) (GEN `(x3 : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                         (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                      ))))
                                                ) (ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                ))))
                                          ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                          ))))
                                    ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                    ))))
                              ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                              ))))
                        ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                        ))
                      ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                      )))
                   ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   )))
              ) (MP  
                 (CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                  (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                   (MP  
                    (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                     (MP  
                      (MP  
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                         (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(x : mat_Point)` 
                          (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                               (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(x0 : mat_Point)` 
                                (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                     (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__ind))))
                                   ) (GEN `(x1 : mat_Point)` 
                                      (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                          (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                           (SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__ind))))
                                         ) (GEN `(x2 : mat_Point)` 
                                            (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__ind))))
                                               ) (GEN `(x3 : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                       (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                             (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                   (SPEC `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                    ))))
                                              ) (ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                              ))))
                                        ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                        ))))
                                  ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                  ))))
                            ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                            ))))
                      ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                      ))
                    ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                    )))
                 ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
            ) (MP  
               (CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                 (MP  
                  (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                       (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(x : mat_Point)` 
                        (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                         (MP  
                          (MP  
                           (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                            (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                             (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(x0 : mat_Point)` 
                              (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                               (MP  
                                (MP  
                                 (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                  (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                   (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(x1 : mat_Point)` 
                                    (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                        (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                         (SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__ind))))
                                       ) (GEN `(x2 : mat_Point)` 
                                          (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                              (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                               (SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(x3 : mat_Point)` 
                                                (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                    (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                     (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                            (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                 (SPEC `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                  ))))
                                            ) (ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                            ))))
                                      ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                      ))))
                                ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                ))))
                          ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                          ))))
                    ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                    ))
                  ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                  )))
               ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )))
          ) (MP  
             (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
              (MP  
               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   ))))
             ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
             )))
        ) (MP  
           (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
            (MP  
             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (and__ind)))
             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                 ))))
           ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )))))))))
 ;;


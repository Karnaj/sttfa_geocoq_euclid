(*proposition__05 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((isosceles A) B) C) ==> ((((((congA A) B) C) A) C) B))))`*)
let proposition__05 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
      (MP  
       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
            (DISCH `mat_not (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
             (MP  
              (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
               (MP  
                (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                 (MP  
                  (CONV_CONV_rule `((mat_not ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                    (nNPP))
                  ) (DISCH `mat_not ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `mat_false` 
                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                             (MP  
                              (SPEC `mat_false` 
                               (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `mat_false` 
                                     (SPEC `(mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                      (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `mat_false` 
                                           (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                            (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `mat_false` 
                                                 (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `mat_false` 
                                                       (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                              (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                               (and__ind)))
                                                            ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                               (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                  (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                 ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                   )))))
                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            ))))
                      ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                      ))))
                ) (MP  
                   (MP  
                    (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                      (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (MP  
                          (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(A : mat_Point)` (proposition__04)))))
                            )
                           ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                           )
                          ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                          )
                         ) (ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                         ))))
                   ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                   )))
              ) (MP  
                 (MP  
                  (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                    (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` 
                         (SPEC `(C : mat_Point)` (lemma__ABCequalsCBA)))
                       ) (MP  
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(C : mat_Point)` (nCol__notCol)))
                          ) (ASSUME `mat_not (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                          )))))
                 ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                 ))))
           ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 ))
               ) (MP  
                  (MP  
                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                     (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                             (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(C : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                           )))))
                  ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                  )))))
         ) (MP  
            (CONV_CONV_rule `((mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (and__ind)))
              ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  ))))
            ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
            )))
       ) (MP  
          (MP  
           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
             (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
              (and__ind)))
           ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
               (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(A : mat_Point)` (lemma__congruencesymmetric))))
                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                ))))
          ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
          )))
     ) (MP  
        (CONV_CONV_rule `(((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
         (DISCH `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
          (MP  
           (DISCH `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
            (MP  
             (MP  
              (SPEC `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (and__ind)))
              ) (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (MP  
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                     (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (conj))
                    ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    )
                   ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                   ))))
             ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
             ))
           ) (ASSUME `(mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
           )))
        ) (ASSUME `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
        ))))))
 ;;


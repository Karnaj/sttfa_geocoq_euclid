(*lemma__collinearparallel2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((par A) B) C) D) ==> ((((col C) D) E) ==> ((((col C) D) F) ==> (((neq E) F) ==> ((((par A) B) E) F))))))))))`*)
let lemma__collinearparallel2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
        (DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
         (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
          (MP  
           (DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
            (MP  
             (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
              (MP  
               (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                (MP  
                 (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                    (MP  
                     (DISCH `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                      (MP  
                       (DISCH `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                        (MP  
                         (DISCH `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                          (MP  
                           (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                              (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                              )
                             ) (MP  
                                (DISCH `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                 (MP  
                                  (DISCH `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                   (MP  
                                    (DISCH `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                         (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                           (or__ind)))
                                        ) (DISCH `(eq (E : mat_Point)) (D : mat_Point)` 
                                           (MP  
                                            (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                             (MP  
                                              (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                               (MP  
                                                (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                             (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. ((((col (C : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> (((neq (E0 : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> ((((col (C : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                                                  (SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (lemma__collinearorder
                                                                   )))
                                                                ) (ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (DISCH `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                            (MP  
                                                             (DISCH `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                              (MP  
                                                               (DISCH `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (F : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(eq (C : mat_Point)) (F : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (F : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (C : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((nCol (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((neq (F : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (F : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) ==> ((((col (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((nCol (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. (((((par (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) ==> ((((col (C0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((col (C0 : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((nCol (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) ==> (((neq (C0 : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (C0 : mat_Point)) ==> ((((col (D : mat_Point)) (C0 : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C0 : mat_Point)) (F : mat_Point)) ==> ((((col (C0 : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (C0 : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) ==> ((((col (C0 : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (C0 : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (C0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (x : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (x : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. ((((col (F : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> (((neq (E0 : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (F : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> ((((col (D : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (F : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (F : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> (((col (F : mat_Point)) (D : mat_Point)) (E0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((((nCol (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                   ) (
                                                                   DISCH `((nCol (F : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                 ) (ASSUME `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))`
                                                                 ))
                                                               ) (ASSUME `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))`
                                                               ))
                                                             ) (ASSUME `(mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))`
                                                             ))
                                                           ) (SPEC `(F : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (eq__or__neq))
                                                           )))
                                                      ) (MP  
                                                         (DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                             (SPEC `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                              (SPEC `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(F : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (lemma__collinearorder
                                                               )))
                                                            ) (ASSUME `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                            (SPEC `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                             (DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                  (SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                         (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                          (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                               (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                 (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                  (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__parallelflip
                                                            ))))
                                                        ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                        ))))
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(F : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__collinearparallel
                                                          )))))
                                                     ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                    )
                                                   ) (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (E : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((neq (F : mat_Point)) (D : mat_Point))))))))` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((neq (F : mat_Point)) (D : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((neq (F : mat_Point)) (D : mat_Point))))))))))` 
                                                           (SPEC `\ E0 : mat_Point. ((((col (C : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> (((neq (E0 : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> ((((col (C : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((neq (F : mat_Point)) (D : mat_Point))))))))` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (eq__ind__r))))
                                                          ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                              (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                (DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                 (DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                  (ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                                  )))))))))
                                                       ) (ASSUME `(eq (E : mat_Point)) (D : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                      )
                                                     ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                     )
                                                    ) (ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                    )
                                                   ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                   )
                                                  ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                  )
                                                 ) (ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `((eq (E : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((neq (D : mat_Point)) (F : mat_Point))))))))` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((neq (D : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (D : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((neq (D : mat_Point)) (F : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((neq (D : mat_Point)) (F : mat_Point))))))))))` 
                                                         (SPEC `\ E0 : mat_Point. ((((col (C : mat_Point)) (D : mat_Point)) (E0 : mat_Point)) ==> (((neq (E0 : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (E0 : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> ((((col (C : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) ==> ((((col (C : mat_Point)) (F : mat_Point)) (E0 : mat_Point)) ==> ((neq (D : mat_Point)) (F : mat_Point))))))))` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (eq__ind__r))))
                                                        ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                            (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `((col (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                              (DISCH `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                               (DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                (ASSUME `(neq (D : mat_Point)) (F : mat_Point)`
                                                                )))))))))
                                                     ) (ASSUME `(eq (E : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                    )
                                                   ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                   )
                                                  ) (ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                  )
                                                 ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                 )
                                                ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                )
                                               ) (ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                               ))))
                                       ) (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                            (MP  
                                             (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                    (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                    )
                                                   ) (MP  
                                                      (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                          (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                           (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                            (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                  (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                   (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__parallelflip
                                                             ))))
                                                         ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                         ))))
                                                 ) (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(F : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__collinearparallel
                                                           )))))
                                                      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                     )
                                                    ) (ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                    )))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                   (SPEC `(F : mat_Point)` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (not__nCol__Col))))
                                                  ) (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(F : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (col__nCol__False))
                                                        )
                                                       ) (ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(F : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (lemma__collinear4
                                                               ))))
                                                           ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                           )
                                                          ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                          )
                                                         ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                         ))))))
                                             ) (MP  
                                                (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                    (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                     (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                          (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                            (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                             (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (lemma__parallelflip))
                                                     ))
                                                   ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                   ))))
                                           ) (MP  
                                              (MP  
                                               (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__collinearparallel
                                                     )))))
                                                ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                )
                                               ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                               )
                                              ) (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                              ))))
                                      ) (ASSUME `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                      ))
                                    ) (ASSUME `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                    ))
                                  ) (ASSUME `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                  ))
                                ) (SPEC `(D : mat_Point)` 
                                   (SPEC `(E : mat_Point)` (eq__or__neq)))))
                           ) (MP  
                              (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                   (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                ))
                              ) (MP  
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (lemma__parallelflip))))
                                 ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                 ))))
                         ) (MP  
                            (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                (SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                  (DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                      (SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                       (SPEC `((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                            (SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                             (SPEC `((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                              (DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                  (SPEC `((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                    (DISCH `((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                     (ASSUME `((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((col (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                              ))
                            ) (MP  
                               (SPEC `(F : mat_Point)` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (lemma__collinearorder)))
                               ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                               ))))
                       ) (MP  
                          (CONV_CONV_rule `((((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                           (SPEC `(F : mat_Point)` 
                            (SPEC `(E : mat_Point)` 
                             (SPEC `(C : mat_Point)` (not__nCol__Col))))
                          ) (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (MP  
                              (MP  
                               (SPEC `(F : mat_Point)` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(C : mat_Point)` (col__nCol__False)))
                               ) (ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                               )
                              ) (MP  
                                 (MP  
                                  (MP  
                                   (SPEC `(F : mat_Point)` 
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (lemma__collinear4))))
                                   ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                   )
                                  ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                  )
                                 ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                 ))))))
                     ) (MP  
                        (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                            (SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                             (SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                              (DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                  (SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                   (SPEC `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                        (SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                         (SPEC `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                              (SPEC `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                (DISCH `((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(F : mat_Point)` 
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(C : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                           ))))
                   ) (MP  
                      (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                          (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                           (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                (SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                 (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                      (SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                       (SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                            (SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                              (DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                        ))
                      ) (MP  
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(C : mat_Point)` (lemma__collinearorder)))
                         ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                         ))))
                 ) (MP  
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` (lemma__inequalitysymmetric))
                    ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)))
               ) (MP  
                  (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                       (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                            (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                             (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                   (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                         (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                               (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                 (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))`
                    ))
                  ) (MP  
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                     ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                     ))))
             ) (MP  
                (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                           (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                 (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                   (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   )))
                              ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                  ))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__parallelNC))))
                   ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                   ))))
           ) (MP  
              (SPEC `(F : mat_Point)` 
               (SPEC `(E : mat_Point)` (lemma__inequalitysymmetric))
              ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`))))))))))))
 ;;


(*lemma__8__7 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((per C) B) A) ==> (mat_not (((per A) C) B)))))`*)
let lemma__8__7 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
    (MP  
     (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
      (MP  
       (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                  (SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(E : mat_Point)` 
                   (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                       (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                         (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> (mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                            (DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                             (MP  
                              (DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (DISCH `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                   (MP  
                                    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                     (MP  
                                      (DISCH `((per (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                         (DISCH `mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                          (ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                          ))
                                        ) (DISCH `((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (DISCH `((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                               (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `mat_false` 
                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
                                                    (SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__ind))))
                                                  ) (GEN `(F : mat_Point)` 
                                                     (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                          (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `mat_false` 
                                                               (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__droppedperpendicularunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> (((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (B : mat_Point)) (C : mat_Point)) (F0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (F0 : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (F0 : mat_Point)) (A : mat_Point)) ==> (((((cong (F0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (F0 : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (F0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                 )))
                                              ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                              ))
                                            ) (MP  
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__8__2)))
                                               ) (ASSUME `((per (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                               )))))
                                      ) (MP  
                                         (SPEC `(E : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__8__2)))
                                         ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                         )))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__8__3))))
                                        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        )
                                       ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                       )))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` (lemma__ray4)
                                        ))
                                      ) (MP  
                                         (SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                          (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                             (SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                              (or__intror))
                                            ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                            )))
                                     ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                     )))
                                ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                ))
                              ) (MP  
                                 (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                       (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                           (SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                            (SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                  (SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                          (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                   ))
                                 ) (MP  
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (lemma__collinearorder)))
                                    ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                    )))))
                           ) (MP  
                              (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                               (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                  (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                     (SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                        (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                         (or__intror))
                                       ) (MP  
                                          (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                            (or__introl))
                                          ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                          )))))))))
                     ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                     ))))
               ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
               ))
             ) (MP  
                (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` (lemma__extension))))
                 ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)
                ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)))
           ) (MP  
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric))
              ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)))
         ) (MP  
            (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (B : mat_Point)) (C : mat_Point))` 
             (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
              (MP  
               (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                (MP  
                 (MP  
                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
                    (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(x : mat_Point)` 
                     (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (CONV_CONV_rule `(((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (B : mat_Point)) (C : mat_Point))` 
                                          (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
                                           (MP  
                                            (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__ind))))
                                               ) (GEN `(x0 : mat_Point)` 
                                                  (DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                       (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                        (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                             (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                              (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
                                              ))
                                            ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
                                            )))
                                         ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                         ))))
                                   ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                             ))))
                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                       ))))
                 ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                 ))
               ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
               )))
            ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )))
       ) (MP  
          (SPEC `(A : mat_Point)` 
           (SPEC `(B : mat_Point)` (SPEC `(C : mat_Point)` (lemma__8__2)))
          ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
          )))
     ) (MP  
        (CONV_CONV_rule `(((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
         (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
          (MP  
           (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
            (MP  
             (MP  
              (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
                (SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(x : mat_Point)` 
                 (DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))` 
                  (MP  
                   (MP  
                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                     (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                      (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                       (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                           (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                            (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                             (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                 (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                    (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                    )))
                               ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                         ))))
                   ) (ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))`
                   ))))
             ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
             ))
           ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
           )))
        ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`))
    ))))
 ;;


(*lemma__ray :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. ((((out A) B) P) ==> (((neq P) B) ==> ((mat_not (((betS A) P) B)) ==> (((betS A) B) P))))))`*)
let lemma__ray =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (DISCH `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
    (DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
     (DISCH `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
      (MP  
       (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (CONV_CONV_rule `(((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
          (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(E : mat_Point)` 
                (DISCH `(mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                    (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                     (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                      (DISCH `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                         (MP  
                          (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                               (SPEC `\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(D : mat_Point)` 
                                (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                    (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                           (MP  
                                            (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (P : mat_Point))))) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                               (DISCH `(((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                      (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                                                           (SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__ind))))
                                                         ) (GEN `(F : mat_Point)` 
                                                            (DISCH `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                (SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                 (SPEC `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> ((neq (B : mat_Point)) (P : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (P : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> (((((cong (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (P : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (P : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (x : mat_Point))) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (P : mat_Point))) ==> ((neq (x : mat_Point)) (P : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((out (A : mat_Point)) (B0 : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (B0 : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B0 : mat_Point))) ==> (((neq (A : mat_Point)) (B0 : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (B0 : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (B0 : mat_Point)) (P : mat_Point))) ==> ((neq (B0 : mat_Point)) (P : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (P : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (F : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))) ==> (((neq (P : mat_Point)) (P : mat_Point)) ==> ((((out (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((((cong (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (P : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> (((((cong (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> (((((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (P : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (A : mat_Point)) (F : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ==> (((neq (F : mat_Point)) (F : mat_Point)) ==> ((((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((neq (A : mat_Point)) (F : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((lt (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ==> ((neq (F : mat_Point)) (F : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (x : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((lt (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (x : mat_Point))) ==> ((neq (x : mat_Point)) (x : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. (((neq (A : mat_Point)) (P0 : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point))) ==> (((neq (P0 : mat_Point)) (P0 : mat_Point)) ==> ((((out (A : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> ((((betS (D : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) ==> (((((cong (D : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (D : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point)) (D : mat_Point)) ==> (((((cong (P0 : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> ((((betS (A : mat_Point)) (P0 : mat_Point)) (D : mat_Point)) ==> (((((lt (A : mat_Point)) (P0 : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (P0 : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point))) ==> ((neq (P0 : mat_Point)) (P0 : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (P : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (P : mat_Point)) (P : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (P : mat_Point))`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__connectivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (F : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (P : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((neq (F : mat_Point)) (B : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((neq (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((lt (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((lt (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. ((((out (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> (((neq (P0 : mat_Point)) (B : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point))) ==> ((((betS (E : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((lt (A : mat_Point)) (P0 : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((lt (A : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (P0 : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
                                                        )))
                                                     ) (ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                     ))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(P : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__lessthancongruence
                                                             ))))))
                                                       ) (ASSUME `(((lt (A : mat_Point)) (P : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                      )))
                                                 ) (SPEC `(A : mat_Point)` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (cn__equalityreverse))))
                                               )
                                              ) (MP  
                                                 (SPEC `(B : mat_Point)` 
                                                  (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (P : mat_Point))))))` 
                                                   (SPEC `\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (ex__intro))))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                      (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (conj))
                                                     ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                    ))))
                                            ) (MP  
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (axiom__betweennesssymmetry
                                                  )))
                                               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                               )))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(P : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (lemma__congruencetransitive
                                                    ))))))
                                              ) (ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                             )))
                                        ) (SPEC `(B : mat_Point)` 
                                           (SPEC `(D : mat_Point)` 
                                            (cn__equalityreverse))))))
                                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                  ))))
                            ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
                            ))
                          ) (MP  
                             (MP  
                              (SPEC `(P : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` (lemma__extension)))
                               )
                              ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                              )
                             ) (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (P : mat_Point)))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                               (SPEC `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (P : mat_Point))` 
                                (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                 (DISCH `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (P : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                     (SPEC `(neq (E : mat_Point)) (P : mat_Point)` 
                                      (SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                       (DISCH `(neq (E : mat_Point)) (P : mat_Point)` 
                                        (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                        )))
                                   ) (ASSUME `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (P : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (P : mat_Point)))`
                             ))
                           ) (MP  
                              (SPEC `(P : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(E : mat_Point)` 
                                 (lemma__betweennotequal)))
                              ) (ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                              ))))))
                  ) (ASSUME `(mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
            )))
         ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`)
        )
       ) (MP  
          (SPEC `(P : mat_Point)` 
           (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__ray2)))
          ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
          ))))))))
 ;;


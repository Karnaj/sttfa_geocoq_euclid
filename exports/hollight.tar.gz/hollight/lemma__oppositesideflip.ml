(*lemma__oppositesideflip :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((tS P) A) B) Q) ==> ((((tS P) B) A) Q)))))`*)
let lemma__oppositesideflip =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (GEN `(Q : mat_Point)` 
    (DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
       (DISCH `ex (\ r : mat_Point. ((mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
        (MP  
         (MP  
          (SPEC `(((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> (return : bool))) ==> ((ex (\ r : mat_Point. ((mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))) ==> (return : bool)))` 
            (SPEC `\ r : mat_Point. ((mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(r : mat_Point)` 
             (DISCH `(mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
              (MP  
               (MP  
                (SPEC `(((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                 (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                  (SPEC `((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point)` 
                   (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `(((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                          (MP  
                           (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                            (MP  
                             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))) ==> ((((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                (DISCH `(((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                 (ASSUME `(((tS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                 ))
                               ) (MP  
                                  (SPEC `(r : mat_Point)` 
                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))))` 
                                    (SPEC `\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__intro))))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                       (SPEC `((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point)`
                                      )
                                     ) (MP  
                                        (MP  
                                         (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                          (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                           (conj))
                                         ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                         )
                                        ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                        )))))
                             ) (MP  
                                (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                    (SPEC `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                     (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                      (DISCH `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                          (SPEC `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                           (SPEC `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                            (DISCH `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                (SPEC `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                 (SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                      (SPEC `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (SPEC `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                        (DISCH `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                  ))
                                ) (MP  
                                   (SPEC `(r : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__collinearorder)))
                                   ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                   ))))
                           ) (MP  
                              (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                  (SPEC `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                   (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                    (DISCH `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                        (SPEC `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                         (SPEC `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                              (SPEC `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                               (SPEC `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                    (SPEC `((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                      (DISCH `((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                ))
                              ) (MP  
                                 (SPEC `(P : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (lemma__NCorder)))
                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                 ))))))
                     ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                     ))))
               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
               ))))
         ) (ASSUME `ex (\ r : mat_Point. ((mat_and (((betS (P : mat_Point)) (r : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
         )))
      ) (ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
      ))))))
 ;;


(*lemma__lessthanadditive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((lt A) B) C) D) ==> ((((betS A) B) E) ==> ((((betS C) D) F) ==> (((((cong B) E) D) F) ==> ((((lt A) E) C) F))))))))))`*)
let lemma__lessthanadditive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
        (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
         (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
            (DISCH `ex (\ b : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
             (MP  
              (MP  
               (SPEC `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                 (SPEC `\ b : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(b : mat_Point)` 
                  (DISCH `(mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                   (MP  
                    (MP  
                     (SPEC `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                      (SPEC `(((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (SPEC `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)` 
                        (DISCH `(((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (MP  
                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (b : mat_Point)` 
                           (MP  
                            (DISCH `(neq (C : mat_Point)) (b : mat_Point)` 
                             (MP  
                              (DISCH `(neq (b : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                 (MP  
                                  (DISCH `ex (\ e : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                       (SPEC `\ e : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (ex__ind))))
                                     ) (GEN `(e : mat_Point)` 
                                        (DISCH `(mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                            (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                             (SPEC `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                              (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((betS (e : mat_Point)) (b : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                           (DISCH `mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))` 
                                                            (MP  
                                                             (CONV_CONV_rule `(((eq (F : mat_Point)) (e : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                              (DISCH `mat_not ((eq (F : mat_Point)) (e : mat_Point))` 
                                                               (MP  
                                                                (CONV_CONV_rule `((mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))) ==> mat_false) ==> ((((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                 (DISCH `mat_not (mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))` 
                                                                  (MP  
                                                                   (DISCH `((betS (C : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point))))) ==> ((((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (e : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (nNPP)
                                                                   ) (
                                                                   ASSUME `mat_not (mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))`
                                                                   )))))
                                                                ) (DISCH `mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (e : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (F : mat_Point)) (e : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (e : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__outerconnectivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))`
                                                                    ))))))
                                                             ) (DISCH `(eq (F : mat_Point)) (e : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) ==> (((((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> (((((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> (((((cong (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> (((((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> ((((betS (e : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> (((((cong (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (D : mat_Point)) ==> (((((lt (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> (((((cong (e : mat_Point)) (b : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((((lt (e : mat_Point)) (D : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((((cong (D : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (x : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((lt (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (b : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((lt (x : mat_Point)) (D : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (C : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F0 : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (F0 : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> (((((cong (F0 : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) (D : mat_Point)) ==> (((((lt (F0 : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) (b : mat_Point)) ==> (((((cong (F0 : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> (((((lt (F0 : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> (((((cong (D : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (F0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> (((((cong (b : mat_Point)) (F0 : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (e : mat_Point)) (D : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> ((((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> ((((betS (e : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> ((((cong (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (D : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (x : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> ((((cong (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (C : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F0 : mat_Point)) (e : mat_Point))) ==> (((((cong (b : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((betS (b : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (F0 : mat_Point)) (D : mat_Point)) (b : mat_Point)) ==> ((((cong (F0 : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (e : mat_Point)) (D : mat_Point)) (e : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))) ==> ((((cong (b : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))) ==> ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (e : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (x : mat_Point)) (e : mat_Point))) ==> ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (C : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (C : mat_Point)) (b : mat_Point)) (F0 : mat_Point)) ==> ((mat_not (((betS (b : mat_Point)) (F0 : mat_Point)) (e : mat_Point))) ==> ((((cong (b : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (e : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))`
                                                                    ))))))
                                                          ) (DISCH `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (X : mat_Point)) (b : mat_Point)) (F : mat_Point))))) ==> mat_false` 
                                                                 (DISCH `(((lt (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ q : mat_Point. ((mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point))) ==> (return : bool))) ==> ((ex (\ q : mat_Point. ((mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. ((mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (F : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (q : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((betS (F : mat_Point)) (e : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (F : mat_Point)) (e : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (F : mat_Point)) (e : mat_Point)) (F : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (e : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__betweennessidentity
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (q : mat_Point)) (e : mat_Point)) ==> ((((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)) ==> (((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((neq (b : mat_Point)) (q : mat_Point)) ==> ((((out (b : mat_Point)) (F : mat_Point)) (q : mat_Point)) ==> (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)) ==> (((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((neq (b : mat_Point)) (e : mat_Point)) ==> ((((out (b : mat_Point)) (F : mat_Point)) (e : mat_Point)) ==> (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (e : mat_Point)) ==> ((((betS (b : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> ((((out (b : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ q0 : mat_Point. ((((betS (b : mat_Point)) (q0 : mat_Point)) (F : mat_Point)) ==> (((((cong (b : mat_Point)) (q0 : mat_Point)) (b : mat_Point)) (e : mat_Point)) ==> (((neq (b : mat_Point)) (q0 : mat_Point)) ==> ((((out (b : mat_Point)) (F : mat_Point)) (q0 : mat_Point)) ==> (((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (F : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (q : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (F : mat_Point))) (((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (F : mat_Point))) (((betS (b : mat_Point)) (F : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (F : mat_Point))) ((mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (F : mat_Point))) ((mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (F : mat_Point))) ((mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (F : mat_Point))) ((mat_and ((neq (b : mat_Point)) (q : mat_Point))) ((neq (b : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ q : mat_Point. ((mat_and (((betS (b : mat_Point)) (q : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (q : mat_Point)) (b : mat_Point)) (e : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (b : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   SPEC `(D : mat_Point)` 
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                ) (MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (F : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (X : mat_Point)) (b : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (X : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (F : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                   ))))
                                                              ) (SPEC `(F : mat_Point)` 
                                                                 (SPEC `(b : mat_Point)` 
                                                                  (cn__congruencereflexive
                                                                  ))))))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(F : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(b : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (lemma__3__6b
                                                                ))))
                                                            ) (ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (SPEC `(e : mat_Point)` 
                                                          (SPEC `(b : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (axiom__betweennesssymmetry
                                                            )))
                                                         ) (ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                         )))
                                                    ) (SPEC `(D : mat_Point)` 
                                                       (SPEC `(e : mat_Point)` 
                                                        (cn__congruencereflexive
                                                        ))))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(e : mat_Point)` 
                                                         (SPEC `(b : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (cn__sumofparts
                                                              ))))))
                                                        ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (b : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                       )
                                                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(E : mat_Point)` 
                                                    (SPEC `(e : mat_Point)` 
                                                     (SPEC `(b : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__congruencesymmetric
                                                       ))))
                                                   ) (ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                   )))))
                                          ) (ASSUME `(mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                          ))))
                                    ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                    ))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(b : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (lemma__extension))))
                                      ) (ASSUME `(neq (C : mat_Point)) (b : mat_Point)`
                                      )
                                     ) (ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                     )))
                                ) (MP  
                                   (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                       (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                        (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                         (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                             (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                (ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                     ))
                                   ) (MP  
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (lemma__betweennotequal)))
                                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                      ))))
                              ) (MP  
                                 (SPEC `(b : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (lemma__inequalitysymmetric))
                                 ) (ASSUME `(neq (C : mat_Point)) (b : mat_Point)`
                                 )))
                            ) (MP  
                               (DISCH `(mat_and ((neq (b : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (C : mat_Point)) (b : mat_Point)` 
                                   (SPEC `(mat_and ((neq (C : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                    (SPEC `(neq (b : mat_Point)) (D : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (b : mat_Point)) (D : mat_Point)` 
                                     (DISCH `(mat_and ((neq (C : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (C : mat_Point)) (b : mat_Point)` 
                                         (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(neq (C : mat_Point)) (b : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (C : mat_Point)) (b : mat_Point)` 
                                           (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                            (ASSUME `(neq (C : mat_Point)) (b : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (C : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (b : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                 ))
                               ) (MP  
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(b : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (lemma__betweennotequal)))
                                  ) (ASSUME `((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point)`
                                  ))))
                          ) (MP  
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(b : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__congruencesymmetric))))
                             ) (ASSUME `(((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                             )))))
                    ) (ASSUME `(mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                    ))))
              ) (ASSUME `ex (\ b : mat_Point. ((mat_and (((betS (C : mat_Point)) (b : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
              )))
           ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )))))))))))
 ;;


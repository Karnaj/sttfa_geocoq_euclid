(*lemma__collinearitypreserved :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. ((((col A) B) C) ==> (((((cong A) B) a) b) ==> (((((cong A) C) a) c) ==> (((((cong B) C) b) c) ==> (((col a) b) c))))))))))`*)
let lemma__collinearitypreserved =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
        (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
         (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
          (MP  
           (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
            (MP  
             (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
              (MP  
               (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                (MP  
                 (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                  (MP  
                   (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                    (MP  
                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                      (MP  
                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                              (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                               (MP  
                                (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                 (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                 )
                                ) (MP  
                                   (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                    (MP  
                                     (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                      (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                          (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                           (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                            (or__ind)))
                                         ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                              (MP  
                                               (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(((neq (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                  (DISCH `mat_not ((neq (a : mat_Point)) (b : mat_Point))` 
                                                   (MP  
                                                    (DISCH `(eq (a : mat_Point)) (b : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                       (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                        (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                          (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `(eq (a : mat_Point)) (b : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (SPEC `(b : mat_Point)` 
                                                        (SPEC `(a : mat_Point)` 
                                                         (cn__stability))
                                                       ) (ASSUME `mat_not ((neq (a : mat_Point)) (b : mat_Point))`
                                                       ))))
                                                 ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(neq (A : mat_Point)) (A : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                        (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                           (ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                                           )
                                                          ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                          )))
                                                       ) (MP  
                                                          (DISCH `mat_false` 
                                                           (MP  
                                                            (DISCH `mat_false` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (eq__refl)))
                                                            ) (ASSUME `mat_false`
                                                            ))
                                                          ) (MP  
                                                             (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                (ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                                                )
                                                               ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                               ))
                                                             ) (SPEC `(A : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__refl)))
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(b : mat_Point)` 
                                                            (SPEC `(a : mat_Point)` 
                                                             (axiom__nocollapse
                                                             ))))
                                                         ) (ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                        )))))
                                               ) (MP  
                                                  (SPEC `(b : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (SPEC `(a : mat_Point)` 
                                                      (lemma__congruencesymmetric
                                                      ))))
                                                  ) (ASSUME `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                  )))
                                             ) (MP  
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)))))))))` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (x : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)))))))))))` 
                                                           (SPEC `\ A0 : mat_Point. ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((((cong (B : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (A0 : mat_Point)) (A0 : mat_Point)) (a : mat_Point)) (b : mat_Point)))))))))` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (eq__ind__r))))
                                                          ) (DISCH `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                              (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                               (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                   (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                   ))))))))))
                                                       ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                    )
                                                   ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                   )
                                                  ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                ))))
                                        ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (MP  
                                              (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                 (or__ind)))
                                              ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `(((neq (a : mat_Point)) (c : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                       (DISCH `mat_not ((neq (a : mat_Point)) (c : mat_Point))` 
                                                        (MP  
                                                         (DISCH `(eq (a : mat_Point)) (c : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                            (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                             (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                               (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                (or__intror))
                                                              ) (MP  
                                                                 (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                  (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                   (or__introl
                                                                   ))
                                                                 ) (ASSUME `(eq (a : mat_Point)) (c : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (SPEC `(c : mat_Point)` 
                                                             (SPEC `(a : mat_Point)` 
                                                              (cn__stability)
                                                             )
                                                            ) (ASSUME `mat_not ((neq (a : mat_Point)) (c : mat_Point))`
                                                            ))))
                                                      ) (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (A : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                             (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                (ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                                                )
                                                               ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                               )))
                                                            ) (MP  
                                                               (DISCH `mat_false` 
                                                                (MP  
                                                                 (DISCH `mat_false` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                   ))
                                                                 ) (ASSUME `mat_false`
                                                                 ))
                                                               ) (MP  
                                                                  (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                  ) (
                                                                  SPEC `(A : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__refl)
                                                                  )))))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(c : mat_Point)` 
                                                                 (SPEC `(a : mat_Point)` 
                                                                  (axiom__nocollapse
                                                                  ))))
                                                              ) (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                             )))))
                                                    ) (MP  
                                                       (SPEC `(c : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(a : mat_Point)` 
                                                           (lemma__congruencesymmetric
                                                           ))))
                                                       ) (ASSUME `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)))))))))` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (C : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (x : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point)))))))))))` 
                                                                (SPEC `\ A0 : mat_Point. ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((((cong (B : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (A0 : mat_Point)) (A0 : mat_Point)) (a : mat_Point)) (c : mat_Point)))))))))` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__ind__r
                                                                   ))))
                                                               ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                   (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                             )
                                                            ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                     ))))
                                             ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                     (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                      (or__ind)))
                                                   ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `(((neq (b : mat_Point)) (c : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                            (DISCH `mat_not ((neq (b : mat_Point)) (c : mat_Point))` 
                                                             (MP  
                                                              (DISCH `(eq (b : mat_Point)) (c : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                 (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                  (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (b : mat_Point)) (c : mat_Point)`
                                                                   )))))
                                                              ) (MP  
                                                                 (SPEC `(c : mat_Point)` 
                                                                  (SPEC `(b : mat_Point)` 
                                                                   (cn__stability
                                                                   ))
                                                                 ) (ASSUME `mat_not ((neq (b : mat_Point)) (c : mat_Point))`
                                                                 ))))
                                                           ) (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                  (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                  )))))
                                                         ) (MP  
                                                            (SPEC `(c : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(b : mat_Point)` 
                                                                (lemma__congruencesymmetric
                                                                ))))
                                                            ) (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (x : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> (((((cong (B0 : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((cong (B0 : mat_Point)) (B0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                             )
                                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                          ))))
                                                  ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                         (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (or__ind)))
                                                        ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                               (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                  (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                   (or__intror
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(c : mat_Point)` 
                                                                   (SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                  ) (
                                                                  ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                )
                                                               ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                               ))))
                                                       ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                              (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (or__ind)))
                                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                   )))))))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                            ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                   (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                   (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                   (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                   (SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                   (SPEC `((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                   (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                  )))))))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                   ))))
                                                           ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                           )))
                                                      ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                      )))
                                                 ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                 )))
                                            ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                            )))
                                       ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                       ))
                                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                     ))
                                   ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                   ))))
                             ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             ))
                           ) (MP  
                              (MP  
                               (SPEC `(a : mat_Point)` 
                                (SPEC `(b : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (lemma__congruencetransitive))))))
                               ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                               )
                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (lemma__congruencesymmetric))))
                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                            )))
                       ) (SPEC `(B : mat_Point)` 
                          (SPEC `(A : mat_Point)` (cn__equalityreverse))))
                     ) (MP  
                        (MP  
                         (SPEC `(a : mat_Point)` 
                          (SPEC `(b : mat_Point)` 
                           (SPEC `(b : mat_Point)` 
                            (SPEC `(a : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (lemma__congruencetransitive))))))
                         ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                         )
                        ) (ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                        )))
                   ) (SPEC `(b : mat_Point)` 
                      (SPEC `(a : mat_Point)` (cn__equalityreverse))))
                 ) (MP  
                    (MP  
                     (SPEC `(b : mat_Point)` 
                      (SPEC `(c : mat_Point)` 
                       (SPEC `(c : mat_Point)` 
                        (SPEC `(b : mat_Point)` 
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (lemma__congruencetransitive))))))
                     ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                     )
                    ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                    )))
               ) (SPEC `(c : mat_Point)` 
                  (SPEC `(b : mat_Point)` (cn__equalityreverse))))
             ) (MP  
                (MP  
                 (SPEC `(c : mat_Point)` 
                  (SPEC `(b : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(C : mat_Point)` (lemma__congruencetransitive)))
                    )))
                 ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )
                ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                )))
           ) (SPEC `(B : mat_Point)` 
              (SPEC `(C : mat_Point)` (cn__equalityreverse)))))))))))))
 ;;


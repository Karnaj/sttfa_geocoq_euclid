(*lemma__supplementinequality :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! f : mat_Point. ((((((supp A) B) C) D) F) ==> ((((((supp a) b) c) d) f) ==> (((((((ltA a) b) c) A) B) C) ==> ((((((ltA D) B) F) d) b) f)))))))))))))`*)
let lemma__supplementinequality =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (GEN `(a : mat_Point)` 
      (GEN `(b : mat_Point)` 
       (GEN `(c : mat_Point)` 
        (GEN `(d : mat_Point)` 
         (GEN `(f : mat_Point)` 
          (DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
           (DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
            (DISCH `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (DISCH `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
               (MP  
                (MP  
                 (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool)))` 
                   (SPEC `\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(P : mat_Point)` 
                    (DISCH `ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))` 
                     (MP  
                      (MP  
                       (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool)))` 
                         (SPEC `\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(Q : mat_Point)` 
                          (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (return : bool)))` 
                               (SPEC `\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(R : mat_Point)` 
                                (DISCH `(mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                    (SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                     (SPEC `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                      (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                          (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                           (SPEC `((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                            (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                 (SPEC `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                       (MP  
                                                        (DISCH `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                             (MP  
                                                              (DISCH `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                 (DISCH `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                  (MP  
                                                                   (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (R : mat_Point)) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (B : mat_Point)) (R : mat_Point)) ==> mat_false) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (F : mat_Point)) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (R : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((ltA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (f : mat_Point)) (b : mat_Point)) (d : mat_Point)) (F : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (R : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> mat_false) ==> ((((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (d : mat_Point)) (b : mat_Point)) (f : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (d : mat_Point)) (f : mat_Point))) ((mat_and (((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (d : mat_Point)) (f : mat_Point))) ((mat_and (((col (b : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((mat_and (((col (f : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (f : mat_Point)) (b : mat_Point))) (((col (f : mat_Point)) (b : mat_Point)) (d : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (R : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (f : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (Q : mat_Point))) (((col (D : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (f : mat_Point)) (b : mat_Point)) (d : mat_Point)) (F : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (f : mat_Point)) (b : mat_Point)) (d : mat_Point)) (F : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (x : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point))))) ==> (ex (\ V : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (Q : mat_Point)) (M : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (B : mat_Point))) ((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (M : mat_Point))) ((mat_or ((eq (F : mat_Point)) (R : mat_Point))) ((mat_or ((eq (M : mat_Point)) (R : mat_Point))) ((mat_or (((betS (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_or (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (R : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((neq (F : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((neq (F : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((neq (F : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((neq (F : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (R : mat_Point))) ((mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((neq (F : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (M : mat_Point))) (((col (R : mat_Point)) (M : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (M : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (F : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((col (M : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (R : mat_Point))) ((mat_or ((eq (M : mat_Point)) (R : mat_Point))) ((mat_or (((betS (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_or (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (R : mat_Point))) ((mat_or (((betS (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_or (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_or (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (B : mat_Point))) ((mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (B : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (f : mat_Point)) (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__supplements
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (R : mat_Point))) ==> (((out (B : mat_Point)) (R : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (R : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((betS (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (R : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                   ))))
                                                                ) (DISCH `((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))) ((mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (P : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (F : mat_Point)) (B : mat_Point))) ((neq (F : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (F : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (F : mat_Point))) (((col (P : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))))
                                                              ) (MP  
                                                                 (DISCH `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                  (MP  
                                                                   (DISCH `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (P : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((supp (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((nCol (P : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> ((((((supp (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((((supp (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (A0 : mat_Point)) (P : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((((supp (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                                   ))
                                                                 ) (ASSUME `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                  (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                  (MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                             )))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                              (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                (MP  
                                                                 (SPEC `(Q : mat_Point)` 
                                                                  (SPEC `(R : mat_Point)` 
                                                                   (SPEC `(P : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                 ) (ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                           )))
                                                      ) (MP  
                                                         (CONV_CONV_rule `(((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                          (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                           (MP  
                                                            (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                 (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                  (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))`
                                                              ))
                                                            ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))`
                                                            )))
                                                         ) (ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (SPEC `(R : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (nCol__notCol)))
                                                       ) (MP  
                                                          (SPEC `(R : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (nCol__not__Col)
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(R : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(c : mat_Point)` 
                                                                 (SPEC `(b : mat_Point)` 
                                                                  (SPEC `(a : mat_Point)` 
                                                                   (lemma__equalanglesNC
                                                                   ))))))
                                                             ) (ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                             )))))))
                                              ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))`
                                  ))))
                            ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))`
                            ))))
                      ) (ASSUME `ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))`
                      ))))
                ) (ASSUME `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))`
                ))
              ) (MP  
                 (CONV_CONV_rule `((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                  (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))` 
                   (MP  
                    (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                         (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(x : mat_Point)` 
                          (DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                              (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                               (SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(x0 : mat_Point)` 
                                (DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                    (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool)))` 
                                     (SPEC `\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)))))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__ind))))
                                   ) (GEN `(x1 : mat_Point)` 
                                      (DISCH `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                          (SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)))` 
                                           (SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                            (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))` 
                                                 (SPEC `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                  (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                      (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                       (SPEC `((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                        (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                         (MP  
                                                          (SPEC `(x : mat_Point)` 
                                                           (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                            (SPEC `\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__intro))))
                                                          ) (MP  
                                                             (SPEC `(x1 : mat_Point)` 
                                                              (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                               (SPEC `\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__intro))
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(x0 : mat_Point)` 
                                                                 (CONV_CONV_rule `! x2 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x2 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))))) ==> (ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))` 
                                                                  (SPEC `\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)`
                                                                   )))))))))
                                                    ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))`
                                        ))))
                                  ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))))))`
                                  ))))
                            ) (ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))`
                            ))))
                      ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))`
                      ))
                    ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))))`
                    )))
                 ) (ASSUME `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))))))))))))))
 ;;


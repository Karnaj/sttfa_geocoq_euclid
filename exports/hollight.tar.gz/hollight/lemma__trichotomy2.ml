(*lemma__trichotomy2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((lt A) B) C) D) ==> (mat_not ((((lt C) D) A) B))))))`*)
let lemma__trichotomy2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
       (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
        (MP  
         (MP  
          (SPEC `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
            (SPEC `\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(E : mat_Point)` 
             (DISCH `(mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
              (MP  
               (MP  
                (SPEC `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                 (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                   (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                        (DISCH `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                         (ASSUME `mat_not ((((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                         ))
                       ) (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((((lt (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                              (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `mat_false` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(F : mat_Point)` 
                                    (DISCH `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `mat_false` 
                                        (SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (MP  
                                            (DISCH `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (DISCH `mat_not ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                               (MP  
                                                (CONV_CONV_rule `((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                 (ASSUME `mat_not ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                 )
                                                ) (ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                ))
                                              ) (MP  
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(F : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (lemma__partnotequalwhole
                                                    )))
                                                 ) (ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(F : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (lemma__3__6b))))
                                                ) (ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                )
                                               ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                )))
                             ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                             ))
                           ) (MP  
                              (MP  
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (lemma__lessthancongruence))))))
                               ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                               )
                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                              )))))
                     ) (MP  
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (lemma__congruencesymmetric))))
                        ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                        )))))
               ) (ASSUME `(mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
               ))))
         ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
         )))
      ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
      ))))))
 ;;


(*lemma__betweennesspreserved :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong A) B) a) b) ==> (((((cong A) C) a) c) ==> (((((cong B) C) b) c) ==> ((((betS A) B) C) ==> (((betS a) b) c))))))))))`*)
let lemma__betweennesspreserved =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
        (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
         (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
            (MP  
             (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
              (MP  
               (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                  (MP  
                   (DISCH `ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                    (MP  
                     (MP  
                      (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                        (SPEC `\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(d : mat_Point)` 
                         (DISCH `(mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                             (SPEC `(((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                              (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                               (DISCH `(((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                (MP  
                                 (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (b : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                          (MP  
                                           (DISCH `(((cong (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `(((neq (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                              (DISCH `mat_not ((neq (c : mat_Point)) (d : mat_Point))` 
                                               (MP  
                                                (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                 (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                 )
                                                ) (MP  
                                                   (SPEC `(c : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `(((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (d : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (x : mat_Point))))` 
                                                      (SPEC `\ X : mat_Point. (((betS (a : mat_Point)) (b : mat_Point)) (X : mat_Point))` 
                                                       (SPEC `(d : mat_Point)` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (eq__ind__r))))
                                                     ) (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                     ))
                                                   ) (MP  
                                                      (CONV_CONV_rule `(mat_not ((neq (c : mat_Point)) (d : mat_Point))) ==> ((eq (c : mat_Point)) (d : mat_Point))` 
                                                       (SPEC `(eq (c : mat_Point)) (d : mat_Point)` 
                                                        (nNPP))
                                                      ) (ASSUME `mat_not ((neq (c : mat_Point)) (d : mat_Point))`
                                                      )))))
                                             ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                (MP  
                                                 (DISCH `(neq (C : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                    (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                       (ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                      )))
                                                   ) (MP  
                                                      (DISCH `mat_false` 
                                                       (MP  
                                                        (DISCH `mat_false` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (eq__refl)))
                                                        ) (ASSUME `mat_false`
                                                        ))
                                                      ) (MP  
                                                         (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                            (ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                           ))
                                                         ) (SPEC `(C : mat_Point)` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (eq__refl))))))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(d : mat_Point)` 
                                                        (SPEC `(c : mat_Point)` 
                                                         (axiom__nocollapse))
                                                       ))
                                                     ) (ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((cong (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                    )))))
                                           ) (MP  
                                              (SPEC `(d : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(c : mat_Point)` 
                                                  (lemma__congruencesymmetric
                                                  ))))
                                              ) (ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(c : mat_Point)` 
                                                  (SPEC `(d : mat_Point)` 
                                                   (SPEC `(b : mat_Point)` 
                                                    (SPEC `(a : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (axiom__5__line)))))
                                                    )))
                                                 ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                               )
                                              ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                            )))
                                       ) (MP  
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(d : mat_Point)` 
                                            (SPEC `(b : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (lemma__congruencesymmetric))))
                                          ) (ASSUME `(((cong (b : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(c : mat_Point)` 
                                          (SPEC `(b : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(d : mat_Point)` 
                                              (SPEC `(b : mat_Point)` 
                                               (cn__congruencetransitive)))))
                                          )
                                         ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                         )
                                        ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(c : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(b : mat_Point)` 
                                          (lemma__congruencesymmetric))))
                                      ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                      )))
                                 ) (MP  
                                    (SPEC `(c : mat_Point)` 
                                     (SPEC `(d : mat_Point)` 
                                      (SPEC `(b : mat_Point)` 
                                       (SPEC `(b : mat_Point)` 
                                        (lemma__congruencesymmetric))))
                                    ) (ASSUME `(((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                    )))))
                           ) (ASSUME `(mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                           ))))
                     ) (ASSUME `ex (\ d : mat_Point. ((mat_and (((betS (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                     ))
                   ) (MP  
                      (MP  
                       (SPEC `(c : mat_Point)` 
                        (SPEC `(b : mat_Point)` 
                         (SPEC `(a : mat_Point)` (lemma__localextension)))
                       ) (ASSUME `(neq (a : mat_Point)) (b : mat_Point)`)
                      ) (ASSUME `(neq (b : mat_Point)) (c : mat_Point)`)))
                 ) (MP  
                    (MP  
                     (SPEC `(c : mat_Point)` 
                      (SPEC `(b : mat_Point)` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` (axiom__nocollapse))))
                     ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)
                    ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                    )))
               ) (MP  
                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                               (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                               )))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                    ))
                  ) (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                     ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     ))))
             ) (MP  
                (MP  
                 (SPEC `(b : mat_Point)` 
                  (SPEC `(a : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (axiom__nocollapse))))
                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                )))
           ) (MP  
              (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
               (MP  
                (MP  
                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                   (SPEC `(neq (B : mat_Point)) (C : mat_Point)` (and__ind)))
                 ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                    (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                        (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                          (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                           (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                      ))))
                ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                ))
              ) (MP  
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))))))))))))
 ;;


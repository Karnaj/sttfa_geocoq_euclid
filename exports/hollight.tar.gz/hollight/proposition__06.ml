(*proposition__06 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> (((((((congA A) B) C) A) C) B) ==> ((((cong A) B) A) C)))))`*)
let proposition__06 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
     (MP  
      (DISCH `mat_not ((((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
       (MP  
        (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
            (DISCH `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
             (MP  
              (CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
               (DISCH `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                    (MP  
                     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                          (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                          )
                         ) (MP  
                            (MP  
                             (MP  
                              (MP  
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (lemma__trichotomy1))))
                               ) (ASSUME `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                               )
                              ) (ASSUME `mat_not ((((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                              )
                             ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                             )
                            ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                            )))
                       ) (MP  
                          (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                              (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                               (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                     (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                         (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                            ))
                          ) (MP  
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (lemma__angledistinct))))))
                             ) (ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             ))))
                     ) (MP  
                        (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                   (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                       (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                          ))
                        ) (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__angledistinct))))))
                           ) (ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                           ))))
                   ) (MP  
                      (MP  
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(A : mat_Point)` (proposition__06a)))
                       ) (ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                       )
                      ) (ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )))
                 ) (MP  
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (lemma__equalanglessymmetric))))))
                    ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                    ))))
              ) (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` (nCol__notCol)))
                 ) (ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                 ))))
           ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 ))
               ) (MP  
                  (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                       (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                             (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                         (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                           (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                    ))
                  ) (MP  
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                     ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                     )))))))
        ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
        ))
      ) (MP  
         (MP  
          (SPEC `(C : mat_Point)` 
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (proposition__06a)))
          ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          )
         ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
         )))))))
 ;;


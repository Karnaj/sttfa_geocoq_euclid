(*lemma__subtractequals :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS A) B) C) ==> ((((betS A) D) E) ==> (((((cong B) C) D) E) ==> ((((betS A) C) E) ==> (((betS A) B) D)))))))))`*)
let lemma__subtractequals =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
       (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
        (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
           (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
            (MP  
             (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
              (DISCH `mat_not (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
               (MP  
                (CONV_CONV_rule `((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                  (nNPP))
                ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                   (MP  
                    (DISCH `mat_false` 
                     (MP  
                      (SPEC `mat_false` (false__ind)) (ASSUME `mat_false`))
                    ) (MP  
                       (CONV_CONV_rule `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> mat_false` 
                        (ASSUME `mat_not (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                        )
                       ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                       ))))))
             ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                (MP  
                 (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                  (MP  
                   (DISCH `(eq (B : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                          (MP  
                           (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                (MP  
                                 (DISCH `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(eq (C : mat_Point)) (E : mat_Point)` 
                                    (MP  
                                     (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `((eq (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                        (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                        )
                                       ) (ASSUME `(eq (C : mat_Point)) (E : mat_Point)`
                                       ))
                                     ) (MP  
                                        (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                            (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                             (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                              (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                  (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                     (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                          ))
                                        ) (MP  
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__betweennotequal)))
                                           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                           ))))
                                   ) (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__layoffunique))))
                                        ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        )
                                       ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` (lemma__ray4))
                                      )
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                         (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                             (or__intror))
                                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                    ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` (lemma__ray4)))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                       (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                          (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                           (or__intror))
                                         ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                         )))
                                  ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                  )))
                             ) (MP  
                                (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                     (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                             (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                  ))
                                ) (MP  
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__betweennotequal)))
                                   ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                   ))))
                           ) (MP  
                              (MP  
                               (MP  
                                (MP  
                                 (MP  
                                  (MP  
                                   (MP  
                                    (MP  
                                     (CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))` 
                                      (SPEC `(B : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point)))))))))))` 
                                         (SPEC `\ B0 : mat_Point. ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (B0 : mat_Point)) (E : mat_Point)))))))))` 
                                          (SPEC `(D : mat_Point)` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (eq__ind__r))))
                                        ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                            (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                             (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                              (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                 (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                 ))))))))))
                                     ) (ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                     )
                                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )
                                   ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                   )
                                  ) (ASSUME `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                  )
                                 ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                 )
                                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                )
                               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                               )
                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                              )))
                         ) (MP  
                            (MP  
                             (MP  
                              (MP  
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` (cn__sumofparts))
                                   ))))
                               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                               )
                              ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                              )
                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )
                            ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                            )))
                       ) (MP  
                          (MP  
                           (MP  
                            (MP  
                             (MP  
                              (MP  
                               (MP  
                                (CONV_CONV_rule `((eq (B : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))` 
                                 (SPEC `(B : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))))` 
                                    (SPEC `\ B0 : mat_Point. ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point))) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (D : mat_Point))))))))` 
                                     (SPEC `(D : mat_Point)` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (eq__ind__r))))
                                   ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                       (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                        (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                         (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                           (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                           )))))))))
                                ) (ASSUME `(eq (B : mat_Point)) (D : mat_Point)`
                                )
                               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                               )
                              ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                              )
                             ) (ASSUME `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                             )
                            ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                            )
                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                           )
                          ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                          )))
                     ) (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
                   ) (MP  
                      (MP  
                       (MP  
                        (MP  
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` (axiom__connectivity))))
                         ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                         )
                        ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                        )
                       ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                       )
                      ) (ASSUME `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                      )))
                 ) (MP  
                    (MP  
                     (SPEC `(E : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (lemma__3__6b))))
                     ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )
                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                    ))))))
          ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
               (MP  
                (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (MP  
                    (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> mat_false` 
                       (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                              (MP  
                               (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                  (MP  
                                   (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                        (DISCH `(((lt (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                           (MP  
                                            (DISCH `(((lt (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                             (MP  
                                              (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                       (ASSUME `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       )
                                                      ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (lemma__trichotomy2
                                                           ))))
                                                       ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__lessthancongruence
                                                            ))))))
                                                      ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(E : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(D : mat_Point)` 
                                                       (lemma__congruencesymmetric
                                                       ))))
                                                   ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__lessthantransitive
                                                        ))))))
                                                  ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((lt (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(E : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(E : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (lemma__lessthancongruence
                                                      ))))))
                                                ) (ASSUME `(((lt (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                               )))
                                          ) (SPEC `(D : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (cn__equalityreverse)))))
                                       ) (MP  
                                          (SPEC `(B : mat_Point)` 
                                           (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (E : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (B : mat_Point))))))` 
                                            (SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__intro))))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                               (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (conj))
                                              ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                             ))))
                                     ) (SPEC `(B : mat_Point)` 
                                        (SPEC `(E : mat_Point)` 
                                         (cn__congruencereflexive))))
                                   ) (MP  
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (axiom__betweennesssymmetry)))
                                      ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (lemma__3__6b))))
                                     ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )
                                    ) (ASSUME `((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(A : mat_Point)` (lemma__3__6a))
                                     ))
                                   ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                   )
                                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(A : mat_Point)` (lemma__3__6a))))
                                 ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                 )
                                ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (lemma__lessthancongruence))))))
                               ) (ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                               )
                              ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                              )))
                         ) (SPEC `(E : mat_Point)` 
                            (SPEC `(B : mat_Point)` (cn__equalityreverse)))))
                      ) (MP  
                         (SPEC `(C : mat_Point)` 
                          (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                           (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__intro))))
                         ) (MP  
                            (MP  
                             (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                               (conj))
                             ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                             )
                            ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            ))))
                    ) (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` (cn__congruencereflexive))))
                  ) (MP  
                     (MP  
                      (SPEC `(E : mat_Point)` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (lemma__3__6a))))
                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )
                     ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                     )))
                ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                ))
              ) (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__3__6b))))
                  ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                  )
                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))))))))))))
 ;;


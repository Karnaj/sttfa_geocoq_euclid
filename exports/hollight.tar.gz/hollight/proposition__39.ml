(*proposition__39 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((triangle A) B) C) ==> ((((triangle D) B) C) ==> (((((oS A) D) B) C) ==> (((((((eT A) B) C) D) B) C) ==> (((neq A) D) ==> ((((par A) D) B) C)))))))))`*)
let proposition__39 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
               (MP  
                (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `(((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                    (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                           (MP  
                            (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                               (MP  
                                (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                        (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                           (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                              (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                             (DISCH `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                              (MP  
                                                               (CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (nNPP))
                                                               ) (DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                            ) (DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                               (MP  
                                                                (CONV_CONV_rule `(((((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                 (DISCH `mat_not ((((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(((((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__26A
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angletrichotomy2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    proposition__39A
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__39A
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((out (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__angletrichotomy2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((((congA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                   ) (
                                                                   DISCH `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((par (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> ((((par (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    proposition__39A
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                ) (DISCH `(((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__39A
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (lemma__ray4
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                  (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                   (or__intror
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                             ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (lemma__ray4))
                                                             )
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                  )))
                                                           ) (ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (lemma__ray4)))
                                                          ) (MP  
                                                             (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                              (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                  (or__introl
                                                                  ))
                                                                ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                )))
                                                         ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (lemma__ray4)))
                                                        ) (MP  
                                                           (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                              )))
                                                       ) (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (lemma__ray4)))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                              (or__introl))
                                                            ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                            )))
                                                     ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__ray4)))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                        (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                            (or__introl))
                                                          ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                          )))
                                                   ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                   ))))
                                             ) (SPEC `(B : mat_Point)` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (eq__refl)))))
                                          ) (SPEC `(D : mat_Point)` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (eq__refl)))))
                                       ) (SPEC `(C : mat_Point)` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (eq__refl)))))
                                    ) (SPEC `(A : mat_Point)` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (eq__refl))))
                                  ) (MP  
                                     (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                          (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                      (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (lemma__NCdistinct)))
                                        ) (ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        ))))
                                ) (MP  
                                   (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                        (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                             (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                    (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (lemma__NCdistinct)))
                                      ) (ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                      ))))
                              ) (MP  
                                 (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                     (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                           (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                       (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                        (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                         (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                              (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                               (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                (ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                   ))
                                 ) (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (lemma__NCdistinct)))
                                    ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    ))))
                            ) (MP  
                               (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                    (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                     (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                      (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                              (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))`
                                 ))
                               ) (MP  
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(D : mat_Point)` 
                                     (lemma__NCdistinct)))
                                  ) (ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  ))))
                          ) (MP  
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (lemma__inequalitysymmetric))
                             ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                               (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                            (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                  (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                          (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))))))`
                             ))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(D : mat_Point)` (lemma__NCdistinct)))
                              ) (ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              ))))
                      ) (MP  
                         (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                             (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                               (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                        (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                 ))))
                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                           ))
                         ) (MP  
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )))))
                   ) (ASSUME `((triangle (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   )))
                ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                ))
              ) (MP  
                 (DISCH `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                     (SPEC `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                      (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                       (DISCH `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                           (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                              )))
                         ) (ASSUME `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                   ))
                 ) (MP  
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(A : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(C : mat_Point)` (lemma__samesidesymmetric))))
                    ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                    ))))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(A : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` (lemma__samesideflip))))
               ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )))
          ) (MP  
             (DISCH `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
              (MP  
               (MP  
                (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                  (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (and__ind)))
                ) (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (DISCH `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                         (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                          (ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                          )))
                     ) (ASSUME `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                     ))))
               ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
               ))
             ) (MP  
                (SPEC `(D : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` (lemma__samesidesymmetric))))
                ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                ))))))))))))
 ;;


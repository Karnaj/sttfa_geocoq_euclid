(*lemma__equalanglestransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((((congA A) B) C) D) E) F) ==> (((((((congA D) E) F) P) Q) R) ==> ((((((congA A) B) C) P) Q) R)))))))))))`*)
let lemma__equalanglestransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(R : mat_Point)` 
         (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
           (MP  
            (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
               (MP  
                (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                 (MP  
                  (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                     (MP  
                      (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                         (MP  
                          (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                           (MP  
                            (DISCH `ex (\ U : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                 (SPEC `\ U : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)))
                                )
                               ) (GEN `(U : mat_Point)` 
                                  (DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                      (SPEC `(((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                       (SPEC `((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point)` 
                                        (DISCH `(((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (DISCH `ex (\ V : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                               (SPEC `\ V : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(V : mat_Point)` 
                                                (DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                    (SPEC `(((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point)` 
                                                      (DISCH `(((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (E : mat_Point)) (U : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (E : mat_Point)) (V : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                               (MP  
                                                                (DISCH `ex (\ u : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (U : mat_Point))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                   ) (
                                                                   GEN `(u : mat_Point)` 
                                                                   (DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (V : mat_Point))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) ==> ((eq (C : mat_Point)) (C : mat_Point)))) ==> (((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))) ==> ((eq (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point)))) ==> (((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))) ==> ((eq (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) ((((((congA (E : mat_Point)) (V : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (V : mat_Point)) (Q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (E : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. (((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. (((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (x10 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (x10 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x9 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (x9 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x8 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (x8 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x7 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x7 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x4 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x3 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (U0 : mat_Point)) (Q : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V0 : mat_Point)) (Q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U0 : mat_Point)) (E : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V0 : mat_Point)) (E : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (v : mat_Point))) ((((cong (Q : mat_Point)) (v : mat_Point)) (E : mat_Point)) (V : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (V : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `ex (\ u : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((((cong (Q : mat_Point)) (u : mat_Point)) (E : mat_Point)) (U : mat_Point))))`
                                                                  ))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(neq (E : mat_Point)) (U : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                            ) (MP  
                                                               (SPEC `(R : mat_Point)` 
                                                                (SPEC `(Q : mat_Point)` 
                                                                 (SPEC `(P : mat_Point)` 
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                               ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (SPEC `(V : mat_Point)` 
                                                              (SPEC `(F : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (lemma__raystrict
                                                                )))
                                                             ) (ASSUME `((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (SPEC `(U : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(E : mat_Point)` 
                                                              (lemma__raystrict
                                                              )))
                                                           ) (ASSUME `((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point)`
                                                           )))))
                                                  ) (ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((cong (E : mat_Point)) (V : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                            ))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(F : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (lemma__layoff))))
                                              ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                              )
                                             ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                             )))))
                                    ) (ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                    ))))
                              ) (ASSUME `ex (\ U : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (U : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                              ))
                            ) (MP  
                               (MP  
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(E : mat_Point)` (lemma__layoff))))
                                ) (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                )
                               ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                               )))
                          ) (MP  
                             (SPEC `(Q : mat_Point)` 
                              (SPEC `(P : mat_Point)` 
                               (lemma__inequalitysymmetric))
                             ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                               (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                                (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                 (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                     (SPEC `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                                      (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                       (DISCH `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                           (SPEC `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                            (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                             (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                 (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                  (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                       (SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                        (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                         (DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                          (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))`
                             ))
                           ) (MP  
                              (SPEC `(R : mat_Point)` 
                               (SPEC `(Q : mat_Point)` 
                                (SPEC `(P : mat_Point)` 
                                 (SPEC `(F : mat_Point)` 
                                  (SPEC `(E : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (lemma__angledistinct))))))
                              ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                              ))))
                      ) (MP  
                         (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                               (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                      (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                       (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                        (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                 ))))
                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                           ))
                         ) (MP  
                            (SPEC `(F : mat_Point)` 
                             (SPEC `(E : mat_Point)` 
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (lemma__angledistinct))))))
                            ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                            ))))
                    ) (MP  
                       (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                           (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                            (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                             (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                 (SPEC `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                                  (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                   (DISCH `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                       (SPEC `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                        (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                         (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                             (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                              (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                               (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                   (SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                    (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                     (DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                      (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))`
                                     ))))
                               ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))`
                               ))))
                         ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))`
                         ))
                       ) (MP  
                          (SPEC `(R : mat_Point)` 
                           (SPEC `(Q : mat_Point)` 
                            (SPEC `(P : mat_Point)` 
                             (SPEC `(F : mat_Point)` 
                              (SPEC `(E : mat_Point)` 
                               (SPEC `(D : mat_Point)` (lemma__angledistinct)
                               )))))
                          ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                          ))))
                  ) (MP  
                     (SPEC `(E : mat_Point)` 
                      (SPEC `(D : mat_Point)` (lemma__inequalitysymmetric))
                     ) (ASSUME `(neq (D : mat_Point)) (E : mat_Point)`)))
                ) (MP  
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
                   ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
              ) (MP  
                 (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))` 
                  (MP  
                   (MP  
                    (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                     (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                      (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                       (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                           (SPEC `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                            (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                             (DISCH `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                 (SPEC `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                  (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                   (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                       (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                        (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                         (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                             (SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                              (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                               (DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                (ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))`
                                     ))))
                               ) (ASSUME `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))`
                               ))))
                         ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))))`
                         ))))
                   ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))))))`
                   ))
                 ) (MP  
                    (SPEC `(R : mat_Point)` 
                     (SPEC `(Q : mat_Point)` 
                      (SPEC `(P : mat_Point)` 
                       (SPEC `(F : mat_Point)` 
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(D : mat_Point)` (lemma__angledistinct))))))
                    ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                    ))))
            ) (MP  
               (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                (MP  
                 (MP  
                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                   (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind))
                   )
                  ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                     (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                         (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                           (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                               (SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                      (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                       (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                            (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                             (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                              (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                       ))))
                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                 ))
               ) (MP  
                  (SPEC `(F : mat_Point)` 
                   (SPEC `(E : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__angledistinct))))))
                  ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                  ))))))))))))))
 ;;


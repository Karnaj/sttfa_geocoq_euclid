(*out :  |- `out = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS X) A) C)) (((betS X) A) B)))))))`*)
let out =

 new_basic_definition `out = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))`
 ;;

let _ = (new_defs := ("out",out)::!new_defs);;

(*lt :  |- `lt = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS C) X) D)) ((((cong C) X) A) B))))))))`*)
let lt =

 new_basic_definition `lt = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))`
 ;;

let _ = (new_defs := ("lt",lt)::!new_defs);;

(*midpoint :  |- `midpoint = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and (((betS A) B) C)) ((((cong A) B) B) C)))))`*)
let midpoint =

 new_basic_definition `midpoint = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
 ;;

let _ = (new_defs := ("midpoint",midpoint)::!new_defs);;

(*congA :  |- `congA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out B) A) U)) ((mat_and (((out B) C) V)) ((mat_and (((out b) a) u)) ((mat_and (((out b) c) v)) ((mat_and ((((cong B) U) b) u)) ((mat_and ((((cong B) V) b) v)) ((mat_and ((((cong U) V) u) v)) (((nCol A) B) C))))))))))))))))))))))`*)
let congA =

 new_basic_definition `congA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))))))))))`
 ;;

let _ = (new_defs := ("congA",congA)::!new_defs);;

(*adjacentAngle :  |- `adjacentAngle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. ((mat_and ((eq B) E)) ((mat_and (((betS A) B) F)) (((out B) D) C)))))))))`*)
let adjacentAngle =

 new_basic_definition `adjacentAngle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. ((mat_and ((eq (B : mat_Point)) (E : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((out (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("adjacentAngle",adjacentAngle)::!new_defs);;

(*vA :  |- `vA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. ((mat_and ((eq B) E)) ((mat_and (((betS A) B) D)) (((betS C) B) F)))))))))`*)
let vA =

 new_basic_definition `vA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. ((mat_and ((eq (B : mat_Point)) (E : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("vA",vA)::!new_defs);;

(*supp :  |- `supp = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ F : mat_Point. ((mat_and (((out B) C) D)) (((betS A) B) F)))))))`*)
let supp =

 new_basic_definition `supp = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ F : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))`
 ;;

let _ = (new_defs := ("supp",supp)::!new_defs);;

(*per :  |- `per = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS A) B) X)) ((mat_and ((((cong A) B) X) B)) ((mat_and ((((cong A) C) X) C)) ((neq B) C)))))))))`*)
let per =

 new_basic_definition `per = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("per",per)::!new_defs);;

(*perp__at :  |- `perp__at = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((col P) Q) C)) ((mat_and (((col A) B) C)) ((mat_and (((col A) B) X)) (((per X) C) P)))))))))))`*)
let perp__at =

 new_basic_definition `perp__at = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (ex (\ X : mat_Point. ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((per (X : mat_Point)) (C : mat_Point)) (P : mat_Point))))))))))))`
 ;;

let _ = (new_defs := ("perp__at",perp__at)::!new_defs);;

(*perp :  |- `perp = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (ex (\ X : mat_Point. (((((perp__at P) Q) A) B) X)))))))`*)
let perp =

 new_basic_definition `perp = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (ex (\ X : mat_Point. (((((perp__at (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))))`
 ;;

let _ = (new_defs := ("perp",perp)::!new_defs);;

(*inAngle :  |- `inAngle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ P : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out B) A) X)) ((mat_and (((out B) C) Y)) (((betS X) P) Y)))))))))))`*)
let inAngle =

 new_basic_definition `inAngle = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ P : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (X : mat_Point)) (P : mat_Point)) (Y : mat_Point))))))))))))`
 ;;

let _ = (new_defs := ("inAngle",inAngle)::!new_defs);;

(*oS :  |- `oS = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col A) B) U)) ((mat_and (((col A) B) V)) ((mat_and (((betS P) U) X)) ((mat_and (((betS Q) V) X)) ((mat_and (((nCol A) B) P)) (((nCol A) B) Q))))))))))))))))`*)
let oS =

 new_basic_definition `oS = (\ P : mat_Point. (\ Q : mat_Point. (\ A : mat_Point. (\ B : mat_Point. (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))))))))`
 ;;

let _ = (new_defs := ("oS",oS)::!new_defs);;

(*iO :  |- `iO = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and (((betS A) B) C)) ((mat_and (((betS A) B) D)) ((mat_and (((betS A) C) D)) (((betS B) C) D))))))))`*)
let iO =

 new_basic_definition `iO = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))))))))`
 ;;

let _ = (new_defs := ("iO",iO)::!new_defs);;

(*isosceles :  |- `isosceles = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and (((triangle A) B) C)) ((((cong A) B) A) C)))))`*)
let isosceles =

 new_basic_definition `isosceles = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
 ;;

let _ = (new_defs := ("isosceles",isosceles)::!new_defs);;

(*cut :  |- `cut = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. ((mat_and (((betS A) E) B)) ((mat_and (((betS C) E) D)) ((mat_and (((nCol A) B) C)) (((nCol A) B) D)))))))))`*)
let cut =

 new_basic_definition `cut = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("cut",cut)::!new_defs);;

(*ltA :  |- `ltA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS U) X) V)) ((mat_and (((out E) D) U)) ((mat_and (((out E) F) V)) ((((((congA A) B) C) D) E) X))))))))))))))))`*)
let ltA =

 new_basic_definition `ltA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))))))))))))`
 ;;

let _ = (new_defs := ("ltA",ltA)::!new_defs);;

(*tG :  |- `tG = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS A) B) X)) ((mat_and ((((cong B) X) C) D)) ((((lt E) F) A) X)))))))))))`*)
let tG =

 new_basic_definition `tG = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (X : mat_Point))))))))))))`
 ;;

let _ = (new_defs := ("tG",tG)::!new_defs);;

(*tT :  |- `tT = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (\ G : mat_Point. (\ H : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS E) F) X)) ((mat_and ((((cong F) X) G) H)) ((((((tG A) B) C) D) E) X)))))))))))))`*)
let tT =

 new_basic_definition `tT = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (\ G : mat_Point. (\ H : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))))))`
 ;;

let _ = (new_defs := ("tT",tT)::!new_defs);;

(*rT :  |- `rT = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp X) Y) U) V) Z)) ((mat_and ((((((congA A) B) C) X) Y) U)) ((((((congA D) E) F) V) Y) Z)))))))))))))))))))`*)
let rT =

 new_basic_definition `rT = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))))))))))`
 ;;

let _ = (new_defs := ("rT",rT)::!new_defs);;

(*meet :  |- `meet = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq A) B)) ((mat_and ((neq C) D)) ((mat_and (((col A) B) X)) (((col C) D) X))))))))))`*)
let meet =

 new_basic_definition `meet = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))))))))`
 ;;

let _ = (new_defs := ("meet",meet)::!new_defs);;

(*cR :  |- `cR = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS A) X) B)) (((betS C) X) D))))))))`*)
let cR =

 new_basic_definition `cR = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))`
 ;;

let _ = (new_defs := ("cR",cR)::!new_defs);;

(*tP :  |- `tP = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((neq A) B)) ((mat_and ((neq C) D)) ((mat_and (mat_not ((((meet A) B) C) D))) ((((oS C) D) A) B))))))))`*)
let tP =

 new_basic_definition `tP = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))`
 ;;

let _ = (new_defs := ("tP",tP)::!new_defs);;

(*par :  |- `par = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq A) B)) ((mat_and ((neq C) D)) ((mat_and (((col A) B) U)) ((mat_and (((col A) B) V)) ((mat_and ((neq U) V)) ((mat_and (((col C) D) u)) ((mat_and (((col C) D) v)) ((mat_and ((neq u) v)) ((mat_and (mat_not ((((meet A) B) C) D))) ((mat_and (((betS U) X) v)) (((betS u) X) V)))))))))))))))))))))))))`*)
let par =

 new_basic_definition `par = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))))))))`
 ;;

let _ = (new_defs := ("par",par)::!new_defs);;

(*sumA :  |- `sumA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (\ P : mat_Point. (\ Q : mat_Point. (\ R : mat_Point. (ex (\ X : mat_Point. ((mat_and ((((((congA A) B) C) P) Q) X)) ((mat_and ((((((congA D) E) F) X) Q) R)) (((betS P) X) R))))))))))))))`*)
let sumA =

 new_basic_definition `sumA = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ E : mat_Point. (\ F : mat_Point. (\ P : mat_Point. (\ Q : mat_Point. (\ R : mat_Point. (ex (\ X : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (X : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (X : mat_Point)) (R : mat_Point)))))))))))))))`
 ;;

let _ = (new_defs := ("sumA",sumA)::!new_defs);;

(*pG :  |- `pG = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((((par A) B) C) D)) ((((par A) D) B) C))))))`*)
let pG =

 new_basic_definition `pG = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
 ;;

let _ = (new_defs := ("pG",pG)::!new_defs);;

(*sQ :  |- `sQ = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((((cong A) B) C) D)) ((mat_and ((((cong A) B) B) C)) ((mat_and ((((cong A) B) D) A)) ((mat_and (((per D) A) B)) ((mat_and (((per A) B) C)) ((mat_and (((per B) C) D)) (((per C) D) A)))))))))))`*)
let sQ =

 new_basic_definition `sQ = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))))))))`
 ;;

let _ = (new_defs := ("sQ",sQ)::!new_defs);;

(*rE :  |- `rE = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and (((per D) A) B)) ((mat_and (((per A) B) C)) ((mat_and (((per B) C) D)) ((mat_and (((per C) D) A)) ((((cR A) C) B) D)))))))))`*)
let rE =

 new_basic_definition `rE = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))`
 ;;

let _ = (new_defs := ("rE",rE)::!new_defs);;

(*rC :  |- `rC = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (\ d : mat_Point. ((mat_and ((((rE A) B) C) D)) ((mat_and ((((rE a) b) c) d)) ((mat_and ((((cong A) B) a) b)) ((((cong B) C) b) c))))))))))))`*)
let rC =

 new_basic_definition `rC = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (\ d : mat_Point. ((mat_and ((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))`
 ;;

let _ = (new_defs := ("rC",rC)::!new_defs);;

(*eR :  |- `eR = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (\ d : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ x : mat_Point. (ex (\ z : mat_Point. (ex (\ u : mat_Point. (ex (\ w : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((((((rC A) B) C) D) X) Y) Z) U)) ((mat_and ((((((((rC a) b) c) d) x) Y) z) u)) ((mat_and (((betS x) Y) Z)) ((mat_and (((betS X) Y) z)) (((betS W) U) w)))))))))))))))))))))))))))))))`*)
let eR =

 new_basic_definition `eR = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. (\ D : mat_Point. (\ a : mat_Point. (\ b : mat_Point. (\ c : mat_Point. (\ d : mat_Point. (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ x : mat_Point. (ex (\ z : mat_Point. (ex (\ u : mat_Point. (ex (\ w : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((((((rC (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)) (U : mat_Point))) ((mat_and ((((((((rC (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (z : mat_Point)) (u : mat_Point))) ((mat_and (((betS (x : mat_Point)) (Y : mat_Point)) (Z : mat_Point))) ((mat_and (((betS (X : mat_Point)) (Y : mat_Point)) (z : mat_Point))) (((betS (W : mat_Point)) (U : mat_Point)) (w : mat_Point))))))))))))))))))))))))))))))))`
 ;;

let _ = (new_defs := ("eR",eR)::!new_defs);;

(*equilateral :  |- `equilateral = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and ((((cong A) B) B) C)) ((((cong B) C) C) A)))))`*)
let equilateral =

 new_basic_definition `equilateral = (\ A : mat_Point. (\ B : mat_Point. (\ C : mat_Point. ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))))))`
 ;;

let _ = (new_defs := ("equilateral",equilateral)::!new_defs);;


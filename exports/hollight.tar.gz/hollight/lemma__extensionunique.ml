(*lemma__extensionunique :  |- `! A : mat_Point. (! B : mat_Point. (! E : mat_Point. (! F : mat_Point. ((((betS A) B) E) ==> ((((betS A) B) F) ==> (((((cong B) E) B) F) ==> ((eq E) F)))))))`*)
let lemma__extensionunique =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(E : mat_Point)` 
   (GEN `(F : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
      (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
       (MP  
        (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
         (MP  
          (DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
           (MP  
            (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
             (MP  
              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (MP  
                (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                 (MP  
                  (DISCH `(((cong (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                   (MP  
                    (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `(((neq (E : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((eq (E : mat_Point)) (F : mat_Point))` 
                       (DISCH `mat_not ((neq (E : mat_Point)) (F : mat_Point))` 
                        (MP  
                         (CONV_CONV_rule `((mat_not ((eq (E : mat_Point)) (F : mat_Point))) ==> mat_false) ==> ((eq (E : mat_Point)) (F : mat_Point))` 
                          (SPEC `(eq (E : mat_Point)) (F : mat_Point)` (nNPP)
                          )
                         ) (DISCH `mat_not ((eq (E : mat_Point)) (F : mat_Point))` 
                            (MP  
                             (DISCH `mat_false` 
                              (MP  
                               (SPEC `mat_false` (false__ind)
                               ) (ASSUME `mat_false`))
                             ) (MP  
                                (CONV_CONV_rule `(mat_not ((eq (E : mat_Point)) (F : mat_Point))) ==> mat_false` 
                                 (ASSUME `mat_not ((neq (E : mat_Point)) (F : mat_Point))`
                                 )
                                ) (ASSUME `mat_not ((eq (E : mat_Point)) (F : mat_Point))`
                                ))))))
                      ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                         (MP  
                          (DISCH `(neq (E : mat_Point)) (E : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> mat_false` 
                             (DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                (ASSUME `(neq (E : mat_Point)) (E : mat_Point)`
                                )
                               ) (ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                               )))
                            ) (MP  
                               (DISCH `mat_false` 
                                (MP  
                                 (DISCH `mat_false` 
                                  (SPEC `(E : mat_Point)` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)
                                   ))) (ASSUME `mat_false`))
                               ) (MP  
                                  (DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                     (ASSUME `(neq (E : mat_Point)) (E : mat_Point)`
                                     )
                                    ) (ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                    ))
                                  ) (SPEC `(E : mat_Point)` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (eq__refl))))))
                          ) (MP  
                             (MP  
                              (SPEC `(E : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(F : mat_Point)` 
                                 (SPEC `(E : mat_Point)` (axiom__nocollapse))
                                ))
                              ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                              )
                             ) (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                             )))))
                    ) (MP  
                       (SPEC `(F : mat_Point)` 
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(E : mat_Point)` 
                           (lemma__congruencesymmetric))))
                       ) (ASSUME `(((cong (E : mat_Point)) (E : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                       )))
                  ) (MP  
                     (MP  
                      (MP  
                       (MP  
                        (MP  
                         (MP  
                          (SPEC `(E : mat_Point)` 
                           (SPEC `(F : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(E : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` (axiom__5__line)))))
                             )))
                          ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                          )
                         ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                         )
                        ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                        )
                       ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                       )
                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                      )
                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                     )))
                ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                ))
              ) (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
            ) (SPEC `(E : mat_Point)` 
               (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
          ) (MP  
             (SPEC `(F : mat_Point)` 
              (SPEC `(E : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(B : mat_Point)` (lemma__congruencesymmetric))))
             ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
             )))
        ) (SPEC `(E : mat_Point)` 
           (SPEC `(B : mat_Point)` (cn__congruencereflexive))))))))))
 ;;


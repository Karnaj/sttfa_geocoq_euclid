(*lemma__ray3 :  |- `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! V : mat_Point. ((((out B) C) D) ==> ((((out B) C) V) ==> (((out B) D) V))))))`*)
let lemma__ray3 =

 GEN `(B : mat_Point)` 
 (GEN `(C : mat_Point)` 
  (GEN `(D : mat_Point)` 
   (GEN `(V : mat_Point)` 
    (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (DISCH `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
      (MP  
       (CONV_CONV_rule `(((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))` 
        (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
         (MP  
          (MP  
           (SPEC `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
             (SPEC `\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(E : mat_Point)` 
              (DISCH `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                  (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `(((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))` 
                       (DISCH `ex (\ H5 : mat_Point. ((mat_and (((betS (H5 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H5 : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                        (MP  
                         (MP  
                          (SPEC `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ H6 : mat_Point. ((mat_and (((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                            (SPEC `\ H6 : mat_Point. ((mat_and (((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                          ) (GEN `(H6 : mat_Point)` 
                             (DISCH `(mat_and (((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                                 (SPEC `((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                   (DISCH `((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))` 
                                      (DISCH `mat_not (mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)))` 
                                       (MP  
                                        (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (D : mat_Point))))) ==> (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))` 
                                         (DISCH `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                                          (ASSUME `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)`
                                          ))
                                        ) (MP  
                                           (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                            (MP  
                                             (SPEC `(E : mat_Point)` 
                                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
                                               (SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__intro))))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                   (conj))
                                                 ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                 )
                                                ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                )))
                                           ) (MP  
                                              (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                               (nNPP)
                                              ) (ASSUME `mat_not (mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)))`
                                              )))))
                                     ) (DISCH `mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))` 
                                        (MP  
                                         (CONV_CONV_rule `((((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point)) ==> mat_false) ==> mat_false` 
                                          (DISCH `mat_not (((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point))` 
                                           (MP  
                                            (CONV_CONV_rule `((((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point)) ==> mat_false) ==> mat_false` 
                                             (DISCH `mat_not (((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point))` 
                                              (MP  
                                               (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                (MP  
                                                 (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (H6 : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(eq (H6 : mat_Point)) (E : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `(((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> mat_false` 
                                                        (ASSUME `mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))`
                                                        )
                                                       ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                       ))
                                                     ) (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (CONV_CONV_rule `((eq (H6 : mat_Point)) (E : mat_Point)) ==> ((((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> ((((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point))) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (H6 : mat_Point)) ==> (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)))))))` 
                                                              (SPEC `(H6 : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> ((((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)))))))))` 
                                                                 (SPEC `\ H16 : mat_Point. ((((betS (H16 : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> ((((betS (H16 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (B : mat_Point)) (E : mat_Point)) (H16 : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (H16 : mat_Point)) (E : mat_Point))) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) ==> (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)))))))` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                ) (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                   (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                                    ))))))))
                                                             ) (ASSUME `(eq (H6 : mat_Point)) (E : mat_Point)`
                                                             )
                                                            ) (ASSUME `((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                            )
                                                           ) (ASSUME `((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `mat_not (((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point))`
                                                          )
                                                         ) (ASSUME `mat_not (((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point))`
                                                         )
                                                        ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (H6 : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(H6 : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (lemma__outerconnectivity
                                                             ))))
                                                         ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (H6 : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                        )
                                                       ) (ASSUME `mat_not (((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point))`
                                                       )
                                                      ) (ASSUME `mat_not (((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point))`
                                                      )))
                                                 ) (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(H6 : mat_Point)` 
                                                       (axiom__betweennesssymmetry
                                                       )))
                                                    ) (ASSUME `((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (axiom__betweennesssymmetry
                                                     )))
                                                  ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  ))))
                                            ) (DISCH `((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point)` 
                                               (MP  
                                                (DISCH `((betS (E : mat_Point)) (H6 : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `(((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> mat_false` 
                                                     (ASSUME `mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))`
                                                     )
                                                    ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                    ))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(V : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(H6 : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (lemma__3__7a))))
                                                      ) (ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (B : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(E : mat_Point)` 
                                                    (SPEC `(H6 : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (axiom__betweennesssymmetry
                                                      )))
                                                   ) (ASSUME `((betS (B : mat_Point)) (H6 : mat_Point)) (E : mat_Point)`
                                                   ))))))
                                         ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point)` 
                                            (MP  
                                             (DISCH `((betS (H6 : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                              (MP  
                                               (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)) ==> mat_false` 
                                                  (ASSUME `mat_not (((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point))`
                                                  )
                                                 ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                 ))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `(V : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (SPEC `(H6 : mat_Point)` 
                                                       (lemma__3__6a))))
                                                   ) (ASSUME `((betS (H6 : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                   )
                                                  ) (ASSUME `((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point)`
                                                  )))
                                             ) (MP  
                                                (SPEC `(H6 : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (axiom__betweennesssymmetry
                                                   )))
                                                ) (ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (H6 : mat_Point)`
                                                )))))))))
                               ) (ASSUME `(mat_and (((betS (H6 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H6 : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                               ))))
                         ) (ASSUME `ex (\ H5 : mat_Point. ((mat_and (((betS (H5 : mat_Point)) (B : mat_Point)) (V : mat_Point))) (((betS (H5 : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                         )))
                      ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                      ))))
                ) (ASSUME `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                ))))
          ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
          )))
       ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`)))
    ))))
 ;;


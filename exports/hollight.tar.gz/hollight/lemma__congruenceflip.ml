(*lemma__congruenceflip :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((cong A) B) C) D) ==> ((mat_and ((((cong B) A) D) C)) ((mat_and ((((cong B) A) C) D)) ((((cong A) B) D) C)))))))`*)
let lemma__congruenceflip =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
       (MP  
        (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
           (MP  
            (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
             (MP  
              (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
               (MP  
                (MP  
                 (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (conj))
                 ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                 )
                ) (MP  
                   (MP  
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                     (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (conj))
                    ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                    )
                   ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                   )))
              ) (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(B : mat_Point)` (lemma__congruencetransitive))
                      ))))
                  ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                  )
                 ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(D : mat_Point)` 
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__congruencetransitive))))
                  ))
                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                )
               ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
               )))
          ) (MP  
             (MP  
              (SPEC `(D : mat_Point)` 
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(B : mat_Point)` (lemma__congruencetransitive))))))
              ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
              )
             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
             )))
        ) (SPEC `(D : mat_Point)` 
           (SPEC `(C : mat_Point)` (cn__equalityreverse))))
      ) (SPEC `(A : mat_Point)` 
         (SPEC `(B : mat_Point)` (cn__equalityreverse))))))))
 ;;


(*lemma__congruencesymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((cong B) C) A) D) ==> ((((cong A) D) B) C)))))`*)
let lemma__congruencesymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
         )
        ) (MP  
           (MP  
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(D : mat_Point)` 
                 (SPEC `(A : mat_Point)` (cn__congruencetransitive))))))
            ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
            )
           ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           )))
      ) (SPEC `(C : mat_Point)` 
         (SPEC `(B : mat_Point)` (cn__congruencereflexive))))))))
 ;;

